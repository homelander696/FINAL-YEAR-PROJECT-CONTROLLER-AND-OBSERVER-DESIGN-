import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { connectDB } from './config/db.js';
import companiesRouter from './routes/companies.js';
import listsRouter from './routes/lists.js';
import savedSearchesRouter from './routes/savedSearches.js';
import enrichmentRouter from './routes/enrichment.js';

await connectDB();

const app = express();
const PORT = process.env.PORT || 5000;
const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';

app.use(cors({ origin: frontendUrl, credentials: true }));
app.use(express.json());

app.use('/api/companies', companiesRouter);
app.use('/api/lists', listsRouter);
app.use('/api/saved-searches', savedSearchesRouter);
app.use('/api/enrichment', enrichmentRouter);

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
