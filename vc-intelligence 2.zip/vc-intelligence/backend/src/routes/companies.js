import express from 'express';
import Company from '../models/Company.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const { q, stage, sector, sort = 'updatedAt', order = 'desc', page = 1, limit = 10 } = req.query;
    const filter = {};
    if (q) {
      const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      filter.$or = [
        { name: re },
        { description: re },
        { sector: re },
        { tags: re },
      ];
    }
    if (stage) filter.stage = stage;
    if (sector) filter.sector = sector;
    const skip = (Math.max(1, parseInt(page, 10)) - 1) * Math.min(50, Math.max(1, parseInt(limit, 10)));
    const limitNum = Math.min(50, Math.max(1, parseInt(limit, 10)));
    const sortObj = { [sort]: order === 'asc' ? 1 : -1 };
    const [companies, total] = await Promise.all([
      Company.find(filter).sort(sortObj).skip(skip).limit(limitNum).lean(),
      Company.countDocuments(filter),
    ]);
    res.json({ companies, total, page: parseInt(page, 10), limit: limitNum });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const company = await Company.findById(req.params.id).lean();
    if (!company) return res.status(404).json({ error: 'Company not found' });
    res.json(company);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/:id/notes', async (req, res) => {
  try {
    const company = await Company.findByIdAndUpdate(
      req.params.id,
      { $push: { notes: { text: req.body.text } }, updatedAt: new Date() },
      { new: true }
    );
    if (!company) return res.status(404).json({ error: 'Company not found' });
    res.json(company);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
