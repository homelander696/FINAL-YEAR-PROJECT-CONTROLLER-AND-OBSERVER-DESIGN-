import express from 'express';
import List from '../models/List.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const lists = await List.find().populate('companyIds', 'name website sector stage').lean();
    res.json(lists);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const list = await List.create({ name: req.body.name || 'New list', companyIds: [] });
    res.status(201).json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const list = await List.findById(req.params.id).populate('companyIds').lean();
    if (!list) return res.status(404).json({ error: 'List not found' });
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.patch('/:id', async (req, res) => {
  try {
    const { name, companyIds } = req.body;
    const update = { updatedAt: new Date() };
    if (name !== undefined) update.name = name;
    if (companyIds !== undefined) update.companyIds = companyIds;
    const list = await List.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!list) return res.status(404).json({ error: 'List not found' });
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/:id/companies/:companyId', async (req, res) => {
  try {
    const list = await List.findByIdAndUpdate(
      req.params.id,
      { $addToSet: { companyIds: req.params.companyId }, updatedAt: new Date() },
      { new: true }
    ).populate('companyIds');
    if (!list) return res.status(404).json({ error: 'List not found' });
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id/companies/:companyId', async (req, res) => {
  try {
    const list = await List.findByIdAndUpdate(
      req.params.id,
      { $pull: { companyIds: req.params.companyId }, updatedAt: new Date() },
      { new: true }
    ).populate('companyIds');
    if (!list) return res.status(404).json({ error: 'List not found' });
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const list = await List.findByIdAndDelete(req.params.id);
    if (!list) return res.status(404).json({ error: 'List not found' });
    res.json({ deleted: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
