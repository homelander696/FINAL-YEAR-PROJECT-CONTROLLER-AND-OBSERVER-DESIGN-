import express from 'express';
import { enrichCompany, getEnrichment } from '../services/enrichment.js';

const router = express.Router();

router.get('/:companyId', async (req, res) => {
  try {
    const data = await getEnrichment(req.params.companyId);
    if (!data) return res.status(404).json({ error: 'No enrichment yet. Click Enrich to fetch.' });
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/:companyId', async (req, res) => {
  try {
    const data = await enrichCompany(req.params.companyId);
    res.json(data);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
