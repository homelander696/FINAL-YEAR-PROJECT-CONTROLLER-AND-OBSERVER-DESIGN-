import express from 'express';
import SavedSearch from '../models/SavedSearch.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const searches = await SavedSearch.find().sort({ createdAt: -1 }).lean();
    res.json(searches);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', async (req, res) => {
  try {
    const search = await SavedSearch.create({
      name: req.body.name || 'Saved search',
      query: req.body.query,
      filters: req.body.filters || {},
    });
    res.status(201).json(search);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const search = await SavedSearch.findByIdAndDelete(req.params.id);
    if (!search) return res.status(404).json({ error: 'Saved search not found' });
    res.json({ deleted: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
