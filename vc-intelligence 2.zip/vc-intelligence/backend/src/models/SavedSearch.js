import mongoose from 'mongoose';

const savedSearchSchema = new mongoose.Schema({
  name: { type: String, required: true },
  query: String,
  filters: mongoose.Schema.Types.Mixed,
  createdAt: { type: Date, default: Date.now },
});

export default mongoose.model('SavedSearch', savedSearchSchema);
