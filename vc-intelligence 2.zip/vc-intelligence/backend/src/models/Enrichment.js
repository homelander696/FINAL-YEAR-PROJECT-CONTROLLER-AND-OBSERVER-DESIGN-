import mongoose from 'mongoose';

const sourceSchema = new mongoose.Schema({
  url: String,
  scrapedAt: { type: Date, default: Date.now },
});

const enrichmentSchema = new mongoose.Schema({
  companyId: { type: mongoose.Schema.Types.ObjectId, ref: 'Company', required: true, unique: true },
  summary: String,
  whatTheyDo: [String],
  keywords: [String],
  derivedSignals: [String],
  sources: [sourceSchema],
  enrichedAt: { type: Date, default: Date.now },
});

enrichmentSchema.index({ companyId: 1 });

export default mongoose.model('Enrichment', enrichmentSchema);
