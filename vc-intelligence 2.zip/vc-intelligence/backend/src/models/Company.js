import mongoose from 'mongoose';

const noteSchema = new mongoose.Schema({
  text: String,
  createdAt: { type: Date, default: Date.now },
});

const companySchema = new mongoose.Schema({
  name: { type: String, required: true },
  website: String,
  description: String,
  stage: String,
  sector: String,
  tags: [String],
  notes: [noteSchema],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

export default mongoose.model('Company', companySchema);
