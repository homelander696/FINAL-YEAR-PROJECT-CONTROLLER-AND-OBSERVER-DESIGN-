import * as cheerio from 'cheerio';
import OpenAI from 'openai';
import Enrichment from '../models/Enrichment.js';
import Company from '../models/Company.js';

const openai = process.env.OPENAI_API_KEY ? new OpenAI() : null;

async function fetchAndParse(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10000);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { 'User-Agent': 'VC-Intelligence-Scout/1.0 (research)' },
    });
    clearTimeout(timeout);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const html = await res.text();
    const $ = cheerio.load(html);
    $('script, style, nav, footer, header').remove();
    const text = $('body').text().replace(/\s+/g, ' ').trim().slice(0, 15000);
    return { url, text };
  } catch (e) {
    clearTimeout(timeout);
    throw e;
  }
}

function extractWithLLM(text) {
  if (!openai) {
    return {
      summary: 'Enable OPENAI_API_KEY for AI extraction.',
      whatTheyDo: ['Add OPENAI_API_KEY to .env to get real extraction.'],
      keywords: ['api', 'key', 'required'],
      derivedSignals: ['LLM extraction disabled'],
    };
  }
  const system = `You are a VC analyst. Extract from the following webpage text. Reply with valid JSON only, no markdown:
{
  "summary": "1-2 sentence summary",
  "whatTheyDo": ["bullet 1", "bullet 2", ...],
  "keywords": ["keyword1", ...],
  "derivedSignals": ["signal 1", "signal 2", ...]
}
Keep whatTheyDo to 3-6 bullets, keywords 5-10, derivedSignals 2-4 (e.g. "Careers page present", "Recent blog post", "Changelog present").`;

  return openai.chat.completions
    .create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: text.slice(0, 12000) },
      ],
      response_format: { type: 'json_object' },
    })
    .then((r) => JSON.parse(r.choices[0].message.content));
}

export async function enrichCompany(companyId) {
  const company = await Company.findById(companyId);
  if (!company) throw new Error('Company not found');
  const website = company.website || '';
  if (!website) throw new Error('Company has no website URL');
  let baseUrl = website.startsWith('http') ? website : `https://${website}`;
  const sources = [];
  const texts = [];
  try {
    const main = await fetchAndParse(baseUrl);
    sources.push({ url: main.url, scrapedAt: new Date() });
    texts.push(main.text);
  } catch (e) {
    console.warn('Main page fetch failed:', e.message);
  }
  const combined = texts.join('\n\n');
  if (!combined.trim()) {
    throw new Error('Could not fetch any content from the URL');
  }
  const extracted = await extractWithLLM(combined);
  const doc = await Enrichment.findOneAndUpdate(
    { companyId },
    {
      companyId,
      summary: extracted.summary,
      whatTheyDo: extracted.whatTheyDo || [],
      keywords: extracted.keywords || [],
      derivedSignals: extracted.derivedSignals || [],
      sources,
      enrichedAt: new Date(),
    },
    { upsert: true, new: true }
  );
  return doc;
}

export async function getEnrichment(companyId) {
  return Enrichment.findOne({ companyId });
}
