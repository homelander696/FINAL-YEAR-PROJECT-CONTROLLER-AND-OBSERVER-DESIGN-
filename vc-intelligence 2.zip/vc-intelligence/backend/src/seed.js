import 'dotenv/config';
import mongoose from 'mongoose';
import Company from './models/Company.js';

const MOCK_COMPANIES = [
  { name: 'Nexus AI', website: 'https://openai.com', description: 'AI research and products', stage: 'Series B', sector: 'AI/ML', tags: ['AI', 'LLM', 'enterprise'] },
  { name: 'Stripe', website: 'https://stripe.com', description: 'Payments infrastructure for the internet', stage: 'Series I', sector: 'Fintech', tags: ['payments', 'API', 'global'] },
  { name: 'Vercel', website: 'https://vercel.com', description: 'Frontend cloud for developers', stage: 'Series D', sector: 'DevTools', tags: ['frontend', 'serverless', 'nextjs'] },
  { name: 'Notion', website: 'https://notion.so', description: 'All-in-one workspace', stage: 'Series C', sector: 'Productivity', tags: ['docs', 'wiki', 'collaboration'] },
  { name: 'Figma', website: 'https://figma.com', description: 'Collaborative interface design', stage: 'Acquired', sector: 'Design', tags: ['design', 'collaboration', 'UI'] },
  { name: 'Linear', website: 'https://linear.app', description: 'Issue tracking and project management', stage: 'Series B', sector: 'DevTools', tags: ['project-mgmt', 'engineering'] },
  { name: 'Retool', website: 'https://retool.com', description: 'Build internal tools fast', stage: 'Series C', sector: 'DevTools', tags: ['low-code', 'internal-tools'] },
  { name: 'Ramp', website: 'https://ramp.com', description: 'Corporate cards and spend management', stage: 'Series D', sector: 'Fintech', tags: ['fintech', 'spend', 'cards'] },
  { name: 'Plaid', website: 'https://plaid.com', description: 'Financial data connectivity', stage: 'Public', sector: 'Fintech', tags: ['open-banking', 'data'] },
  { name: 'Deel', website: 'https://deel.com', description: 'Global payroll and compliance', stage: 'Series D', sector: 'HR Tech', tags: ['remote', 'payroll', 'compliance'] },
];

async function seed() {
  const uri = process.env.MONGODB_URI || 'mongodb://localhost:27017/vc-intelligence';
  await mongoose.connect(uri);
  await Company.deleteMany({});
  await Company.insertMany(MOCK_COMPANIES);
  console.log('Seeded', MOCK_COMPANIES.length, 'companies');
  await mongoose.disconnect();
}

seed().catch((e) => { console.error(e); process.exit(1); });
