# VC Intelligence — Precision Scout

A MERN-stack VC discovery interface: search companies, view profiles, enrich from public websites (AI scrape + extract), manage lists, and save searches.

**See [run_project.md](./run_project.md) for setup and how to run the project.**

## Stack

- **Backend**: Node, Express, MongoDB (Mongoose)
- **Frontend**: React, Vite, React Router
- **Enrichment**: Server-side fetch + Cheerio + OpenAI (optional)

## Features

- **Companies**: Search, filters (stage/sector), sortable table, pagination
- **Company profile**: Overview, Enrich (live scrape + LLM extraction), notes, save to list
- **Lists**: Create lists, add/remove companies, export CSV/JSON
- **Saved searches**: Save and re-run searches
