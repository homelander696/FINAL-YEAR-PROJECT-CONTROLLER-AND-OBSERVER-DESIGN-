# VC Intelligence — Run & setup guide

This project is a **MERN** (MongoDB, Express, React, Node) VC sourcing interface with live enrichment: discover companies, open profiles, enrich from public websites, save to lists, and re-run saved searches.

---

## Prerequisites

- **Node.js** 18+ and npm (or yarn)
- **MongoDB** running locally (e.g. `mongod`) or a remote URI (e.g. MongoDB Atlas)

---

## 1. Backend

### Install and env

```bash
cd vc-intelligence/backend
npm install
```

Copy env and set values:

```bash
cp .env.example .env
```

Edit `.env`:

| Variable         | Description                          |
|------------------|--------------------------------------|
| `PORT`           | Server port (default `5000`)         |
| `MONGODB_URI`    | MongoDB connection string            |
| `OPENAI_API_KEY` | OpenAI key for enrichment (optional) |
| `FRONTEND_URL`   | Frontend origin for CORS (e.g. `http://localhost:5173`) |

### Seed the database

```bash
npm run seed
```

This inserts mock companies (Stripe, Vercel, Notion, etc.) into the DB.

### Start the server

```bash
npm run dev
```

Backend runs at **http://localhost:5000**. Health check: http://localhost:5000/api/health

---

## 2. Frontend

In a **second terminal**:

```bash
cd vc-intelligence/frontend
npm install
npm run dev
```

Frontend runs at **http://localhost:5173**. Vite proxies `/api` to the backend.

---

## 3. Use the app

1. **Companies** — Search, filter (stage/sector), sort, paginate. Click a company for the profile.
2. **Company profile** — Overview, **Enrich** (scrapes company website and extracts summary, bullets, keywords, signals; requires `OPENAI_API_KEY`), add notes, save to list.
3. **Lists** — Create lists, open a list to add/remove companies and **export CSV/JSON**.
4. **Saved searches** — Save current query + filters and re-run from the Saved page.

---

## 4. Enrichment (optional)

- **Enrich** on a company profile calls the backend `/api/enrichment/:companyId` (POST).
- Backend fetches the company’s `website` URL, scrapes it, and uses OpenAI to extract:
  - Summary (1–2 sentences)
  - What they do (3–6 bullets)
  - Keywords (5–10)
  - Derived signals (2–4)
- Results are cached per company. Sources (URLs + timestamps) are shown on the profile.
- If `OPENAI_API_KEY` is not set, enrichment still runs but returns a placeholder message.

---

## 5. Scripts summary

| Where      | Command       | Purpose                |
|-----------|----------------|------------------------|
| `backend` | `npm run dev`  | Start API with watch   |
| `backend` | `npm run start`| Start API (production) |
| `backend` | `npm run seed` | Seed mock companies    |
| `frontend`| `npm run dev`  | Start Vite dev server  |
| `frontend`| `npm run build`| Production build       |
| `frontend`| `npm run preview` | Preview build       |

---

## 6. Deploy

- **Backend**: Deploy to a Node host (e.g. Railway, Render, Fly.io). Set `MONGODB_URI`, `OPENAI_API_KEY`, and `FRONTEND_URL` to your frontend URL.
- **Frontend**: Build with `npm run build` and deploy the `dist` folder to Vercel or Netlify. Set the API base URL if not using the same host (e.g. `VITE_API_URL` and use it in `api.js` instead of `/api`).

---

## 7. Troubleshooting

- **CORS errors** — Ensure `FRONTEND_URL` in backend `.env` matches the origin you use (e.g. `http://localhost:5173`).
- **MongoDB connection failed** — Start MongoDB locally or use a valid `MONGODB_URI` (e.g. Atlas connection string).
- **Enrich fails** — Company must have a `website` set. Use public URLs only; ensure `OPENAI_API_KEY` is set for real extraction.
