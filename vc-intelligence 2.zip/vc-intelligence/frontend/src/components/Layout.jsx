import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Building2, List, Bookmark, Search } from 'lucide-react';

const nav = [
  { to: '/companies', label: 'Companies', icon: Building2 },
  { to: '/lists', label: 'Lists', icon: List },
  { to: '/saved', label: 'Saved searches', icon: Bookmark },
];

export default function Layout({ children }) {
  const navigate = useNavigate();
  const [globalQuery, setGlobalQuery] = useState('');

  const handleGlobalSearch = (e) => {
    e.preventDefault();
    if (globalQuery.trim()) navigate(`/companies?q=${encodeURIComponent(globalQuery.trim())}`);
  };

  return (
    <div style={styles.wrapper}>
      <aside style={styles.sidebar}>
        <Link to="/" style={styles.logo}>
          <LayoutDashboard size={24} />
          <span>VC Scout</span>
        </Link>
        <form onSubmit={handleGlobalSearch} style={styles.searchForm}>
          <Search size={18} style={styles.searchIcon} />
          <input
            type="search"
            placeholder="Search companies..."
            value={globalQuery}
            onChange={(e) => setGlobalQuery(e.target.value)}
            style={styles.searchInput}
          />
        </form>
        <nav style={styles.nav}>
          {nav.map(({ to, label, icon: Icon }) => (
            <NavLink key={to} to={to} style={styles.navLink} className={({ isActive }) => 'nav-link' + (isActive ? ' active' : '')}>
              <Icon size={20} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
      </aside>
      <main style={styles.main}>{children}</main>
    </div>
  );
}

const styles = {
  wrapper: { display: 'flex', minHeight: '100vh' },
  sidebar: {
    width: 260,
    background: 'var(--surface)',
    borderRight: '1px solid var(--border)',
    padding: '1rem 0',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '0 1.25rem',
    fontSize: '1.125rem',
    fontWeight: 600,
    color: 'var(--text)',
  },
  searchForm: { position: 'relative', padding: '0 0.75rem' },
  searchIcon: { position: 'absolute', left: '1.25rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' },
  searchInput: {
    width: '100%',
    padding: '0.5rem 0.5rem 0.5rem 2.25rem',
    background: 'var(--bg)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    color: 'var(--text)',
    fontSize: '0.875rem',
  },
  nav: { display: 'flex', flexDirection: 'column', gap: '2px' },
  navLink: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '0.6rem 1.25rem',
    color: 'var(--text-muted)',
    fontSize: '0.9375rem',
  },
  main: { flex: 1, padding: '1.5rem 2rem', overflow: 'auto' },
};
