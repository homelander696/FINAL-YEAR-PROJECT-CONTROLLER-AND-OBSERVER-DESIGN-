const BASE = '/api';

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

export const api = {
  companies: {
    list: (params) => request('/companies?' + new URLSearchParams(params).toString()),
    get: (id) => request(`/companies/${id}`),
    addNote: (id, text) => request(`/companies/${id}/notes`, { method: 'POST', body: JSON.stringify({ text }) }),
  },
  lists: {
    list: () => request('/lists'),
    get: (id) => request(`/lists/${id}`),
    create: (name) => request('/lists', { method: 'POST', body: JSON.stringify({ name }) }),
    update: (id, body) => request(`/lists/${id}`, { method: 'PATCH', body: JSON.stringify(body) }),
    addCompany: (listId, companyId) => request(`/lists/${listId}/companies/${companyId}`, { method: 'POST' }),
    removeCompany: (listId, companyId) => request(`/lists/${listId}/companies/${companyId}`, { method: 'DELETE' }),
    delete: (id) => request(`/lists/${id}`, { method: 'DELETE' }),
  },
  savedSearches: {
    list: () => request('/saved-searches'),
    create: (body) => request('/saved-searches', { method: 'POST', body: JSON.stringify(body) }),
    delete: (id) => request(`/saved-searches/${id}`, { method: 'DELETE' }),
  },
  enrichment: {
    get: (companyId) => request(`/enrichment/${companyId}`),
    run: (companyId) => request(`/enrichment/${companyId}`, { method: 'POST' }),
  },
};
