import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react';

const SORT_OPTIONS = [
  { value: 'updatedAt', label: 'Updated' },
  { value: 'name', label: 'Name' },
  { value: 'stage', label: 'Stage' },
  { value: 'sector', label: 'Sector' },
];

export default function Companies() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [data, setData] = useState({ companies: [], total: 0, page: 1, limit: 10 });
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState(searchParams.get('q') || '');
  const [stage, setStage] = useState(searchParams.get('stage') || '');
  const [sector, setSector] = useState(searchParams.get('sector') || '');
  const [sort, setSort] = useState(searchParams.get('sort') || 'updatedAt');
  const [order, setOrder] = useState(searchParams.get('order') || 'desc');
  const page = parseInt(searchParams.get('page') || '1', 10);
  const limit = parseInt(searchParams.get('limit') || '10', 10);

  useEffect(() => {
    const params = { page, limit, sort, order };
    if (q) params.q = q;
    if (stage) params.stage = stage;
    if (sector) params.sector = sector;
    setSearchParams(params, { replace: true });
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = { page, limit, sort, order };
    if (q) params.q = q;
    if (stage) params.stage = stage;
    if (sector) params.sector = sector;
    api.companies.list(params)
      .then(setData)
      .catch((e) => setData({ companies: [], total: 0, page: 1, limit: 10 }))
      .finally(() => setLoading(false));
  }, [page, limit, sort, order, q, stage, sector]);

  const handleSearch = (e) => {
    e.preventDefault();
    setSearchParams({ ...Object.fromEntries(searchParams), page: '1', q: q || undefined });
  };

  const toggleOrder = () => setSearchParams({ ...Object.fromEntries(searchParams), order: order === 'desc' ? 'asc' : 'desc' });
  const setSortField = (s) => setSearchParams({ ...Object.fromEntries(searchParams), sort: s, page: '1' });
  const totalPages = Math.ceil(data.total / limit) || 1;

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>Companies</h1>
      <form onSubmit={handleSearch} style={styles.filters}>
        <input
          type="search"
          placeholder="Search..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Stage"
          value={stage}
          onChange={(e) => setStage(e.target.value)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Sector"
          value={sector}
          onChange={(e) => setSector(e.target.value)}
          style={styles.input}
        />
        <select value={sort} onChange={(e) => setSortField(e.target.value)} style={styles.select}>
          {SORT_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <button type="button" onClick={toggleOrder} style={styles.btn}>{order === 'desc' ? '↓' : '↑'}</button>
        <button type="submit" style={styles.btnPrimary}>Search</button>
      </form>

      {loading ? (
        <p style={styles.muted}>Loading...</p>
      ) : (
        <>
          <div style={styles.tableWrap}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Name</th>
                  <th style={styles.th}>Stage</th>
                  <th style={styles.th}>Sector</th>
                  <th style={styles.th}>Website</th>
                </tr>
              </thead>
              <tbody>
                {data.companies.map((c) => (
                  <tr key={c._id}>
                    <td style={styles.td}>
                      <Link to={`/companies/${c._id}`} style={styles.link}>{c.name}</Link>
                    </td>
                    <td style={styles.td}>{c.stage || '—'}</td>
                    <td style={styles.td}>{c.sector || '—'}</td>
                    <td style={styles.td}>
                      {c.website ? (
                        <a href={c.website.startsWith('http') ? c.website : `https://${c.website}`} target="_blank" rel="noopener noreferrer">
                          <ExternalLink size={14} />
                        </a>
                      ) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={styles.pagination}>
            <span style={styles.muted}>{data.total} results</span>
            <div style={styles.pagButtons}>
              <button
                disabled={page <= 1}
                onClick={() => setSearchParams({ ...Object.fromEntries(searchParams), page: String(page - 1) })}
                style={styles.pagBtn}
              >
                <ChevronLeft size={18} />
              </button>
              <span style={styles.pagInfo}>Page {page} of {totalPages}</span>
              <button
                disabled={page >= totalPages}
                onClick={() => setSearchParams({ ...Object.fromEntries(searchParams), page: String(page + 1) })}
                style={styles.pagBtn}
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

const styles = {
  page: { maxWidth: 1100 },
  title: { fontSize: '1.5rem', fontWeight: 600, marginBottom: '1rem' },
  filters: { display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginBottom: '1.5rem' },
  input: {
    padding: '0.5rem 0.75rem',
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    color: 'var(--text)',
    minWidth: 120,
  },
  select: {
    padding: '0.5rem 0.75rem',
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    color: 'var(--text)',
  },
  btn: { padding: '0.5rem 0.75rem', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', color: 'var(--text)' },
  btnPrimary: { padding: '0.5rem 1rem', background: 'var(--accent)', border: 'none', borderRadius: 'var(--radius)', color: 'white', fontWeight: 500 },
  tableWrap: { overflow: 'auto', border: '1px solid var(--border)', borderRadius: 'var(--radius)' },
  table: { width: '100%', borderCollapse: 'collapse' },
  th: { textAlign: 'left', padding: '0.75rem 1rem', background: 'var(--surface)', borderBottom: '1px solid var(--border)', fontSize: '0.8125rem', fontWeight: 600 },
  td: { padding: '0.75rem 1rem', borderBottom: '1px solid var(--border)' },
  link: { color: 'var(--accent)', fontWeight: 500 },
  muted: { color: 'var(--text-muted)', fontSize: '0.875rem' },
  pagination: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem' },
  pagButtons: { display: 'flex', alignItems: 'center', gap: '0.5rem' },
  pagBtn: { padding: '0.35rem', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', color: 'var(--text)' },
  pagInfo: { fontSize: '0.875rem', color: 'var(--text-muted)' },
};
