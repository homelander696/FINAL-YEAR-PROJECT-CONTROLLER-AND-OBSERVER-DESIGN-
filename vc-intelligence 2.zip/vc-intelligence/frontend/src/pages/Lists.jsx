import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { Plus, List } from 'lucide-react';

export default function Lists() {
  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [newName, setNewName] = useState('');

  useEffect(() => {
    api.lists.list().then(setLists).finally(() => setLoading(false));
  }, []);

  const createList = (e) => {
    e.preventDefault();
    if (!newName.trim()) return;
    api.lists.create(newName.trim()).then((list) => {
      setLists((prev) => [list, ...prev]);
      setNewName('');
    });
  };

  if (loading) return <p style={styles.muted}>Loading...</p>;

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>Lists</h1>
      <form onSubmit={createList} style={styles.form}>
        <input
          type="text"
          placeholder="New list name"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          style={styles.input}
        />
        <button type="submit" style={styles.btn}>
          <Plus size={18} /> Create list
        </button>
      </form>
      <ul style={styles.list}>
        {lists.map((list) => (
          <li key={list._id} style={styles.item}>
            <Link to={`/lists/${list._id}`} style={styles.link}>
              <List size={20} />
              <span>{list.name}</span>
              <span style={styles.count}>{list.companyIds?.length || 0} companies</span>
            </Link>
          </li>
        ))}
      </ul>
      {lists.length === 0 && <p style={styles.muted}>No lists yet. Create one above.</p>}
    </div>
  );
}

const styles = {
  page: { maxWidth: 600 },
  title: { fontSize: '1.5rem', fontWeight: 600, marginBottom: '1rem' },
  form: { display: 'flex', gap: '0.5rem', marginBottom: '1.5rem' },
  input: {
    flex: 1,
    padding: '0.5rem 0.75rem',
    background: 'var(--surface)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius)',
    color: 'var(--text)',
  },
  btn: { display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1rem', background: 'var(--accent)', border: 'none', borderRadius: 'var(--radius)', color: 'white', fontWeight: 500 },
  list: { listStyle: 'none', margin: 0, padding: 0 },
  item: { borderBottom: '1px solid var(--border)' },
  link: { display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0.75rem 0', color: 'var(--text)' },
  count: { marginLeft: 'auto', color: 'var(--text-muted)', fontSize: '0.875rem' },
  muted: { color: 'var(--text-muted)', fontSize: '0.875rem' },
};
