import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api';
import { Download, Trash2, ExternalLink } from 'lucide-react';

export default function ListDetail() {
  const { id } = useParams();
  const [list, setList] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.lists.get(id).then(setList).catch(() => setList(null)).finally(() => setLoading(false));
  }, [id]);

  const removeCompany = (companyId) => {
    api.lists.removeCompany(id, companyId).then(setList);
  };

  const exportCSV = () => {
    if (!list?.companyIds?.length) return;
    const headers = ['Name', 'Website', 'Sector', 'Stage'];
    const rows = list.companyIds.map((c) => [c.name, c.website || '', c.sector || '', c.stage || ''].map((v) => `"${String(v).replace(/"/g, '""')}"`).join(','));
    const blob = new Blob([headers.join(',') + '\n' + rows.join('\n')], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${list.name.replace(/\s+/g, '-')}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const exportJSON = () => {
    if (!list) return;
    const blob = new Blob([JSON.stringify(list, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${list.name.replace(/\s+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  if (loading || !list) return <div style={styles.muted}>{loading ? 'Loading...' : 'List not found.'}</div>;

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <h1 style={styles.title}>{list.name}</h1>
        <div style={styles.actions}>
          <button onClick={exportCSV} style={styles.btn} title="Export CSV"><Download size={18} /> CSV</button>
          <button onClick={exportJSON} style={styles.btn} title="Export JSON"><Download size={18} /> JSON</button>
        </div>
      </div>
      <p style={styles.muted}>{list.companyIds?.length || 0} companies</p>
      <ul style={styles.list}>
        {(list.companyIds || []).map((c) => (
          <li key={c._id} style={styles.item}>
            <Link to={`/companies/${c._id}`} style={styles.link}>{c.name}</Link>
            <span style={styles.meta}>{c.sector} · {c.stage}</span>
            {c.website && (
              <a href={c.website.startsWith('http') ? c.website : `https://${c.website}`} target="_blank" rel="noopener noreferrer" style={styles.icon}><ExternalLink size={14} /></a>
            )}
            <button type="button" onClick={() => removeCompany(c._id)} style={styles.removeBtn} title="Remove from list"><Trash2 size={14} /></button>
          </li>
        ))}
      </ul>
      {(!list.companyIds || list.companyIds.length === 0) && <p style={styles.muted}>No companies in this list. Add from company profiles.</p>}
    </div>
  );
}

const styles = {
  page: { maxWidth: 700 },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' },
  title: { fontSize: '1.5rem', fontWeight: 600, margin: 0 },
  actions: { display: 'flex', gap: '0.5rem' },
  btn: { display: 'inline-flex', alignItems: 'center', gap: '0.35rem', padding: '0.4rem 0.75rem', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', color: 'var(--text)', fontSize: '0.875rem' },
  list: { listStyle: 'none', margin: '1rem 0 0', padding: 0 },
  item: { display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.6rem 0', borderBottom: '1px solid var(--border)' },
  link: { flex: 1, color: 'var(--accent)', fontWeight: 500 },
  meta: { color: 'var(--text-muted)', fontSize: '0.875rem' },
  icon: { color: 'var(--text-muted)' },
  removeBtn: { padding: '0.25rem', background: 'transparent', border: 'none', color: 'var(--text-muted)' },
  muted: { color: 'var(--text-muted)', fontSize: '0.875rem' },
};
