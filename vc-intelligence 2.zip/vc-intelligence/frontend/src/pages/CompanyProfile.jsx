import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api';
import { ExternalLink, Sparkles, Plus, List, Loader2 } from 'lucide-react';

export default function CompanyProfile() {
  const { id } = useParams();
  const [company, setCompany] = useState(null);
  const [enrichment, setEnrichment] = useState(null);
  const [lists, setLists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [enriching, setEnriching] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [addingToListId, setAddingToListId] = useState(null);

  useEffect(() => {
    Promise.all([
      api.companies.get(id),
      api.enrichment.get(id).catch(() => null),
      api.lists.list(),
    ]).then(([c, e, l]) => {
      setCompany(c);
      setEnrichment(e);
      setLists(l);
    }).catch(() => setCompany(null)).finally(() => setLoading(false));
  }, [id]);

  const handleEnrich = () => {
    setEnriching(true);
    api.enrichment.run(id)
      .then(setEnrichment)
      .finally(() => setEnriching(false));
  };

  const handleAddNote = (e) => {
    e.preventDefault();
    if (!noteText.trim()) return;
    api.companies.addNote(id, noteText.trim()).then(setCompany);
    setNoteText('');
  };

  const addToList = (listId) => {
    setAddingToListId(listId);
    api.lists.addCompany(listId, id).finally(() => setAddingToListId(null));
  };

  if (loading || !company) return <div style={styles.muted}>{loading ? 'Loading...' : 'Company not found.'}</div>;

  const websiteUrl = company.website?.startsWith('http') ? company.website : company.website ? `https://${company.website}` : null;

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>{company.name}</h1>
          <div style={styles.meta}>
            {company.stage && <span style={styles.badge}>{company.stage}</span>}
            {company.sector && <span style={styles.badge}>{company.sector}</span>}
            {websiteUrl && (
              <a href={websiteUrl} target="_blank" rel="noopener noreferrer" style={styles.website}>
                <ExternalLink size={16} /> Website
              </a>
            )}
          </div>
        </div>
        <button onClick={handleEnrich} disabled={enriching} style={styles.enrichBtn}>
          {enriching ? <Loader2 size={18} className="spin" /> : <Sparkles size={18} />}
          {enriching ? 'Enriching...' : 'Enrich'}
        </button>
      </div>

      {company.description && <p style={styles.desc}>{company.description}</p>}
      {company.tags?.length > 0 && <p style={styles.tags}>{company.tags.join(' · ')}</p>}

      {enrichment && (
        <section style={styles.section}>
          <h2 style={styles.sectionTitle}>Enrichment</h2>
          <p style={styles.summary}>{enrichment.summary}</p>
          {enrichment.whatTheyDo?.length > 0 && (
            <>
              <h3 style={styles.subTitle}>What they do</h3>
              <ul style={styles.bullets}>{enrichment.whatTheyDo.map((b, i) => <li key={i}>{b}</li>)}</ul>
            </>
          )}
          {enrichment.keywords?.length > 0 && (
            <p style={styles.keywords}><strong>Keywords:</strong> {enrichment.keywords.join(', ')}</p>
          )}
          {enrichment.derivedSignals?.length > 0 && (
            <p style={styles.signals}><strong>Signals:</strong> {enrichment.derivedSignals.join(' · ')}</p>
          )}
          {enrichment.sources?.length > 0 && (
            <div style={styles.sources}>
              <h3 style={styles.subTitle}>Sources</h3>
              <ul style={styles.sourceList}>
                {enrichment.sources.map((s, i) => (
                  <li key={i}>
                    <a href={s.url} target="_blank" rel="noopener noreferrer">{s.url}</a>
                    <span style={styles.muted}> — {new Date(s.scrapedAt).toISOString()}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      )}

      <section style={styles.section}>
        <h2 style={styles.sectionTitle}>Save to list</h2>
        <div style={styles.listChips}>
          {lists.map((list) => (
            <Link key={list._id} to={`/lists/${list._id}`} style={styles.listChip}>
              {list.name}
              <button
                type="button"
                onClick={(e) => { e.preventDefault(); addToList(list._id); }}
                disabled={addingToListId === list._id}
                style={styles.addBtn}
                title="Add to list"
              >
                <Plus size={14} />
              </button>
            </Link>
          ))}
        </div>
        {lists.length === 0 && <p style={styles.muted}>Create a list from <Link to="/lists">Lists</Link> first.</p>}
      </section>

      <section style={styles.section}>
        <h2 style={styles.sectionTitle}>Notes</h2>
        <form onSubmit={handleAddNote} style={styles.noteForm}>
          <textarea
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="Add a note..."
            rows={2}
            style={styles.textarea}
          />
          <button type="submit" style={styles.btn}>Add note</button>
        </form>
        <ul style={styles.notes}>
          {(company.notes || []).map((n, i) => (
            <li key={i} style={styles.note}>
              <span style={styles.muted}>{new Date(n.createdAt).toLocaleString()}</span>
              <p style={styles.noteText}>{n.text}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

const styles = {
  page: { maxWidth: 720 },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '1rem', marginBottom: '1rem' },
  title: { fontSize: '1.5rem', fontWeight: 600, margin: 0 },
  meta: { display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.5rem', flexWrap: 'wrap' },
  badge: { padding: '0.25rem 0.5rem', background: 'var(--surface)', borderRadius: 'var(--radius)', fontSize: '0.8125rem' },
  website: { display: 'inline-flex', alignItems: 'center', gap: '0.25rem', color: 'var(--accent)', fontSize: '0.875rem' },
  enrichBtn: { display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1rem', background: 'var(--accent)', border: 'none', borderRadius: 'var(--radius)', color: 'white', fontWeight: 500 },
  desc: { color: 'var(--text-muted)', marginBottom: '0.5rem' },
  tags: { fontSize: '0.875rem', color: 'var(--text-muted)', marginBottom: '1.5rem' },
  section: { marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid var(--border)' },
  sectionTitle: { fontSize: '1rem', fontWeight: 600, marginBottom: '0.75rem' },
  subTitle: { fontSize: '0.875rem', fontWeight: 600, marginTop: '0.75rem', marginBottom: '0.25rem' },
  summary: { marginBottom: '0.5rem' },
  bullets: { margin: '0.25rem 0 0 1rem', padding: 0 },
  keywords: { fontSize: '0.875rem', marginTop: '0.5rem' },
  signals: { fontSize: '0.875rem', marginTop: '0.25rem' },
  sources: { marginTop: '1rem' },
  sourceList: { margin: 0, paddingLeft: '1.25rem', fontSize: '0.8125rem' },
  listChips: { display: 'flex', flexWrap: 'wrap', gap: '0.5rem' },
  listChip: { display: 'inline-flex', alignItems: 'center', gap: '0.25rem', padding: '0.35rem 0.6rem', background: 'var(--surface)', borderRadius: 'var(--radius)', color: 'var(--text)', fontSize: '0.875rem' },
  addBtn: { padding: '2px', background: 'transparent', border: 'none', color: 'var(--accent)', borderRadius: 4 },
  noteForm: { marginBottom: '0.75rem' },
  textarea: { width: '100%', padding: '0.5rem', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', color: 'var(--text)', resize: 'vertical', fontFamily: 'inherit' },
  btn: { marginTop: '0.5rem', padding: '0.4rem 0.75rem', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', color: 'var(--text)' },
  notes: { listStyle: 'none', margin: 0, padding: 0 },
  note: { padding: '0.5rem 0', borderBottom: '1px solid var(--border)' },
  noteText: { margin: '0.25rem 0 0', fontSize: '0.9375rem' },
  muted: { color: 'var(--text-muted)', fontSize: '0.875rem' },
};
