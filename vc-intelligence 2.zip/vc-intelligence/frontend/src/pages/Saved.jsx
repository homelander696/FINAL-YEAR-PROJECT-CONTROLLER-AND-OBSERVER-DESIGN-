import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api';
import { Bookmark, Trash2 } from 'lucide-react';

export default function Saved() {
  const [searches, setSearches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState('');
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState('');

  useEffect(() => {
    api.savedSearches.list().then(setSearches).finally(() => setLoading(false));
  }, []);

  const saveSearch = (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    let filtersObj = {};
    try {
      if (filters.trim()) filtersObj = JSON.parse(filters);
    } catch (_) {}
    api.savedSearches.create({ name: name.trim(), query: query.trim() || undefined, filters: filtersObj }).then((s) => {
      setSearches((prev) => [s, ...prev]);
      setName('');
      setQuery('');
      setFilters('');
    });
  };

  const deleteSearch = (searchId) => {
    api.savedSearches.delete(searchId).then(() => setSearches((prev) => prev.filter((s) => s._id !== searchId)));
  };

  const runSearch = (s) => {
    const params = new URLSearchParams();
    if (s.query) params.set('q', s.query);
    if (s.filters?.stage) params.set('stage', s.filters.stage);
    if (s.filters?.sector) params.set('sector', s.filters.sector);
    return `/companies?${params.toString()}`;
  };

  if (loading) return <p style={styles.muted}>Loading...</p>;

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>Saved searches</h1>
      <form onSubmit={saveSearch} style={styles.form}>
        <input type="text" placeholder="Search name" value={name} onChange={(e) => setName(e.target.value)} style={styles.input} />
        <input type="text" placeholder="Query (optional)" value={query} onChange={(e) => setQuery(e.target.value)} style={styles.input} />
        <input type="text" placeholder='Filters JSON e.g. {"stage":"Series B"}' value={filters} onChange={(e) => setFilters(e.target.value)} style={styles.input} />
        <button type="submit" style={styles.btn}><Bookmark size={18} /> Save search</button>
      </form>
      <ul style={styles.list}>
        {searches.map((s) => (
          <li key={s._id} style={styles.item}>
            <Link to={runSearch(s)} style={styles.link}>{s.name}</Link>
            {s.query && <span style={styles.meta}>“{s.query}”</span>}
            <button type="button" onClick={() => deleteSearch(s._id)} style={styles.delBtn} title="Delete"><Trash2 size={14} /></button>
          </li>
        ))}
      </ul>
      {searches.length === 0 && <p style={styles.muted}>No saved searches. Save one above to re-run later.</p>}
    </div>
  );
}

const styles = {
  page: { maxWidth: 600 },
  title: { fontSize: '1.5rem', fontWeight: 600, marginBottom: '1rem' },
  form: { display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1.5rem' },
  input: { padding: '0.5rem 0.75rem', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', color: 'var(--text)' },
  btn: { display: 'inline-flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem 1rem', background: 'var(--accent)', border: 'none', borderRadius: 'var(--radius)', color: 'white', fontWeight: 500, alignSelf: 'flex-start' },
  list: { listStyle: 'none', margin: 0, padding: 0 },
  item: { display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.6rem 0', borderBottom: '1px solid var(--border)' },
  link: { flex: 1, color: 'var(--accent)' },
  meta: { color: 'var(--text-muted)', fontSize: '0.875rem' },
  delBtn: { padding: '0.25rem', background: 'transparent', border: 'none', color: 'var(--text-muted)' },
  muted: { color: 'var(--text-muted)', fontSize: '0.875rem' },
};
