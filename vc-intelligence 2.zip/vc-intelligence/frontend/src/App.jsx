import { Routes, Route, useNavigate } from 'react-router-dom';
import Layout from './components/Layout';
import Companies from './pages/Companies';
import CompanyProfile from './pages/CompanyProfile';
import Lists from './pages/Lists';
import ListDetail from './pages/ListDetail';
import Saved from './pages/Saved';

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Companies />} />
        <Route path="/companies" element={<Companies />} />
        <Route path="/companies/:id" element={<CompanyProfile />} />
        <Route path="/lists" element={<Lists />} />
        <Route path="/lists/:id" element={<ListDetail />} />
        <Route path="/saved" element={<Saved />} />
      </Routes>
    </Layout>
  );
}
