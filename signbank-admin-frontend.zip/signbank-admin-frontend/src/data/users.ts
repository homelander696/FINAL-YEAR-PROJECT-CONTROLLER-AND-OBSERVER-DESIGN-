export type AdminUser = {
  id: string
  name: string
  email: string
  role: 'Operator' | 'Viewer'
  mappedGestures: string
}

export const users: AdminUser[] = [
  {
    id: '1',
    name: 'Bob Operator',
    email: 'bob@signbank.com',
    role: 'Operator',
    mappedGestures: 'Check balance(One finger)',
  },
  {
    id: '2',
    name: 'Alice Operator',
    email: 'alice@signbank.com',
    role: 'Operator',
    mappedGestures: 'View Transaction(Open Palm)',
  },
  {
    id: '3',
    name: 'System Operator',
    email: 'admin@signbank.com',
    role: 'Viewer',
    mappedGestures: 'Default',
  },
]
