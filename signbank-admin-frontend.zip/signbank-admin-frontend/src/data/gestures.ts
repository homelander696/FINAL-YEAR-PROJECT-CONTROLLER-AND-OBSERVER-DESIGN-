export type GestureRow = {
  label: string
  gestureId: string
  gestureName: string
  symbol: string
}

export const gestures: GestureRow[] = [
  { label: '1', gestureId: 'G001', gestureName: 'One Finger', symbol: '☝️' },
  { label: '4', gestureId: 'G004', gestureName: 'Closed middle Two Finger', symbol: '🤘' },
  { label: '6', gestureId: 'G006', gestureName: 'Thumbs up', symbol: '👍' },
  { label: '7', gestureId: 'G007', gestureName: 'Thumbs down', symbol: '👎' },
  { label: '9', gestureId: 'G009', gestureName: 'Middle Two closed', symbol: '🤟' },
]
