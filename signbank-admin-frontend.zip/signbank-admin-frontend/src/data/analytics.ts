export const analyticsStats = [
  {
    id: 'ops',
    label: 'Total Operations',
    value: '8,234',
    iconTone: 'green' as const,
    icon: 'hash' as const,
  },
  {
    id: 'rate',
    label: 'Recognition Rate',
    value: '98.5%',
    iconTone: 'blue' as const,
    icon: 'check' as const,
  },
  {
    id: 'active',
    label: 'Active Operators',
    value: '12',
    iconTone: 'purple' as const,
    icon: 'users' as const,
  },
  {
    id: 'peak',
    label: 'Peak Activity',
    value: '14:00 PM',
    iconTone: 'amber' as const,
    icon: 'pulse' as const,
  },
]

export type OperationsPoint = { time: string; operations: number }

export const operationsOverTime: OperationsPoint[] = [
  { time: '08:00', operations: 120 },
  { time: '09:00', operations: 240 },
  { time: '10:00', operations: 350 },
  { time: '11:00', operations: 280 },
  { time: '12:00', operations: 180 },
  { time: '13:00', operations: 220 },
  { time: '14:00', operations: 430 },
]
