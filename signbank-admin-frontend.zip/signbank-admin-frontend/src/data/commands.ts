export type CommandRow = {
  commandId: string
  commandName: string
  commandDescription: string
  pageId: string
  pageName: string
}

export const commands: CommandRow[] = [
  {
    commandId: 'C001',
    commandName: 'Check Balance',
    commandDescription: 'used to Check the Balance of the Operator',
    pageId: 'P001',
    pageName: 'Operator Dashboard',
  },
  {
    commandId: 'C002',
    commandName: 'Logout',
    commandDescription: 'Used to logout',
    pageId: 'P001',
    pageName: 'Operator Dashboard',
  },
  {
    commandId: 'C003',
    commandName: 'Back',
    commandDescription: 'Used to go back',
    pageId: 'P002',
    pageName: 'Operator Balance',
  },
  {
    commandId: 'C004',
    commandName: 'View Logs',
    commandDescription: 'Used to navigate to the View log page',
    pageId: 'P003',
    pageName: 'Viewer dashboard',
  },
  {
    commandId: 'C005',
    commandName: 'View Analytics',
    commandDescription: 'Used to navigate to the View Analytics page',
    pageId: 'P003',
    pageName: 'Viewer dashboard',
  },
  {
    commandId: 'C006',
    commandName: 'Logout',
    commandDescription: 'Used to logout',
    pageId: 'P003',
    pageName: 'Viewer dashboard',
  },
  {
    commandId: 'C007',
    commandName: 'Back',
    commandDescription: 'Used to go back',
    pageId: 'P004',
    pageName: 'Viewer logs',
  },
  {
    commandId: 'C008',
    commandName: 'Back',
    commandDescription: 'Used to go back',
    pageId: 'P005',
    pageName: 'Viewer Analytics',
  },
]
