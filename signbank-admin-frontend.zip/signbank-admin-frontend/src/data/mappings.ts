export type MappingRow = {
  command: string
  gesture: string
  gestureSymbol: string
}

export type PageMappingSection = {
  sectionTitle: string
  rows: MappingRow[]
}

export const operatorMappings: PageMappingSection[] = [
  {
    sectionTitle: 'Operator DashBoard',
    rows: [
      {
        command: 'Check Balance',
        gesture: 'Two Fingers',
        gestureSymbol: '✌️',
      },
      { command: 'Logout', gesture: 'Fist', gestureSymbol: '✊' },
    ],
  },
  {
    sectionTitle: 'Operator Balance Page',
    rows: [{ command: 'Back', gesture: 'Fist', gestureSymbol: '✊' }],
  },
]

export const viewerMappings: PageMappingSection[] = [
  {
    sectionTitle: 'Viewer DashBoard',
    rows: [
      {
        command: 'Recent Gesture Logs',
        gesture: 'One Finger',
        gestureSymbol: '☝️',
      },
      {
        command: 'Analytics',
        gesture: 'Two Finger',
        gestureSymbol: '✌️',
      },
      { command: 'Logout', gesture: 'Fist', gestureSymbol: '✊' },
    ],
  },
  {
    sectionTitle: 'Viewer Log Page',
    rows: [{ command: 'Back', gesture: 'Fist', gestureSymbol: '✊' }],
  },
  {
    sectionTitle: 'Viewer analytics Page',
    rows: [{ command: 'Back', gesture: 'Fist', gestureSymbol: '✊' }],
  },
]
