import type { LucideIcon } from 'lucide-react'
import { Link } from 'react-router-dom'

const toneClasses: Record<
  'mint' | 'sky' | 'lavender',
  { tile: string; circle: string }
> = {
  mint: {
    tile: 'bg-emerald-100 hover:bg-emerald-200/80',
    circle: 'bg-emerald-500',
  },
  sky: { tile: 'bg-sky-100 hover:bg-sky-200/80', circle: 'bg-sky-500' },
  lavender: {
    tile: 'bg-violet-100 hover:bg-violet-200/80',
    circle: 'bg-violet-500',
  },
}

export function DashboardTile({
  to,
  label,
  icon: Icon,
  tone,
}: {
  to: string
  label: string
  icon: LucideIcon
  tone: keyof typeof toneClasses
}) {
  const t = toneClasses[tone]
  return (
    <Link
      to={to}
      className={`flex items-center gap-4 rounded-xl border border-transparent p-5 shadow-sm transition ${t.tile}`}
    >
      <div
        className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full text-white ${t.circle}`}
      >
        <Icon className="h-6 w-6" strokeWidth={1.75} />
      </div>
      <span className="text-base font-medium text-neutral-900">{label}</span>
    </Link>
  )
}
