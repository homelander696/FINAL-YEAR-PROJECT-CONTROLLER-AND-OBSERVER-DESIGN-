export function RoleBadge({ role }: { role: string }) {
  return (
    <span className="inline-flex rounded-full bg-[var(--color-primary)] px-3 py-1 text-xs font-medium text-white">
      {role}
    </span>
  )
}
