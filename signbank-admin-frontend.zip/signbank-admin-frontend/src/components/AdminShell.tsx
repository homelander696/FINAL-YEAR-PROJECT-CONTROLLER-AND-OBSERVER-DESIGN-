import type { ReactNode } from 'react'

type Variant = 'default' | 'gradient'

export function AdminShell({
  children,
  variant = 'default',
  className = '',
}: {
  children: ReactNode
  variant?: Variant
  className?: string
}) {
  const bg =
    variant === 'gradient'
      ? 'min-h-screen bg-gradient-to-b from-sky-100/80 to-white'
      : 'min-h-screen bg-[var(--color-page-bg)]'

  return (
    <div className={`${bg} font-sans text-neutral-900 ${className}`}>
      {children}
    </div>
  )
}
