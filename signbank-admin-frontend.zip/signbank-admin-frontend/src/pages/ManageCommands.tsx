import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { DataTable } from '../components/DataTable'
import { PrimaryButton } from '../components/PrimaryButton'
import { commands } from '../data/commands'

export function ManageCommands() {
  return (
    <AdminShell>
      <div className="mx-auto max-w-7xl px-6 py-8">
        <AdminPageHeader
          breadcrumb="Admin - Manage Commands"
          title="Manage Commands"
          subtitle="View and edit command"
          right={<PrimaryButton>+ Add Commands</PrimaryButton>}
        />
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
          <DataTable
            className="rounded-none border-0 shadow-none"
            rows={commands}
            getRowKey={(r) => r.commandId}
            columns={[
              { id: 'cid', header: 'Command id', cell: (r) => r.commandId },
              {
                id: 'cname',
                header: 'Command name',
                cell: (r) => r.commandName,
              },
              {
                id: 'desc',
                header: 'Command description',
                cell: (r) => r.commandDescription,
              },
              {
                id: 'pid',
                header: (
                  <span className="inline-flex items-center gap-1.5">
                    <span
                      className="inline-block h-1.5 w-1.5 rounded-full bg-red-500"
                      aria-hidden
                    />
                    Page id
                  </span>
                ),
                cell: (r) => r.pageId,
              },
              {
                id: 'pname',
                header: 'Page name',
                cell: (r) => r.pageName,
              },
            ]}
            onEdit={(r) => console.log('edit', r)}
            onDelete={(r) => console.log('delete', r)}
          />
        </div>
      </div>
    </AdminShell>
  )
}
