import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { DataTable } from '../components/DataTable'
import { PrimaryButton } from '../components/PrimaryButton'
import { RoleBadge } from '../components/RoleBadge'
import { users } from '../data/users'

export function ManageUsers() {
  return (
    <AdminShell>
      <div className="mx-auto max-w-6xl px-6 py-8">
        <AdminPageHeader
          breadcrumb="Admin - Manage users"
          title="Manage Users"
          subtitle="View and edit user details, and their mapped Gestures."
          right={<PrimaryButton>+ Add User</PrimaryButton>}
        />
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
          <DataTable
            className="rounded-none border-0 shadow-none"
            rows={users}
            getRowKey={(r) => r.id}
            columns={[
              {
                id: 'name',
                header: 'Name & email',
                cell: (r) => (
                  <div>
                    <div className="font-semibold text-neutral-900">{r.name}</div>
                    <div className="text-sm text-neutral-500">{r.email}</div>
                  </div>
                ),
              },
              {
                id: 'role',
                header: 'Role',
                cell: (r) => <RoleBadge role={r.role} />,
              },
              {
                id: 'gestures',
                header: 'Mapped gestures & commands',
                cell: (r) => r.mappedGestures,
              },
            ]}
            onEdit={(r) => console.log('edit', r)}
            onDelete={(r) => console.log('delete', r)}
          />
        </div>
      </div>
    </AdminShell>
  )
}
