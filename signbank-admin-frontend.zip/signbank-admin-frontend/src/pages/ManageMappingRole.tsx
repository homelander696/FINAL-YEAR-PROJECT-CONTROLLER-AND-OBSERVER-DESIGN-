import { Navigate, useParams } from 'react-router-dom'
import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import {
  operatorMappings,
  viewerMappings,
  type PageMappingSection,
} from '../data/mappings'

function SectionTable({ section }: { section: PageMappingSection }) {
  return (
    <div className="rounded-xl border border-neutral-300 bg-white p-4 shadow-sm">
      <h3 className="mb-4 text-center text-base font-semibold text-neutral-900">
        {section.sectionTitle}
      </h3>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[400px] border-collapse border border-neutral-300 text-sm">
          <thead>
            <tr className="bg-[#d9d9d9]">
              <th className="border border-neutral-300 px-3 py-3 text-center font-bold text-neutral-900">
                Command
              </th>
              <th className="border border-neutral-300 px-3 py-3 text-center font-bold text-neutral-900">
                Gesture
              </th>
              <th className="border border-neutral-300 px-3 py-3 text-center font-bold text-neutral-900">
                Gesture Symbol
              </th>
            </tr>
          </thead>
          <tbody>
            {section.rows.map((row) => (
              <tr key={`${section.sectionTitle}-${row.command}`} className="bg-neutral-100">
                <td className="border border-neutral-300 px-3 py-3 text-neutral-800">
                  {row.command}
                </td>
                <td className="border border-neutral-300 px-3 py-3 text-center font-semibold text-neutral-900">
                  {row.gesture}
                </td>
                <td className="border border-neutral-300 px-3 py-3 text-center text-2xl">
                  {row.gestureSymbol}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export function ManageMappingRole() {
  const { role } = useParams<{ role: string }>()
  if (role !== 'operator' && role !== 'viewer') {
    return <Navigate to="/admin/mapping" replace />
  }
  const sections = role === 'operator' ? operatorMappings : viewerMappings
  const roleTitle = role === 'operator' ? 'Operator' : 'Viewer'

  return (
    <AdminShell>
      <div className="mx-auto max-w-4xl px-6 py-10">
        <AdminPageHeader
          breadcrumb="Admin - Manage mappings"
          title="Manage Mapping"
          subtitle="View and edit mapped Gestures."
        />
        <div className="rounded-2xl border border-neutral-300 bg-white p-8 shadow-sm">
          <h2 className="mb-8 text-center text-2xl font-bold text-neutral-900">
            {roleTitle}
          </h2>
          <div className="space-y-8">
            {sections.map((section) => (
              <SectionTable key={section.sectionTitle} section={section} />
            ))}
          </div>
        </div>
      </div>
    </AdminShell>
  )
}
