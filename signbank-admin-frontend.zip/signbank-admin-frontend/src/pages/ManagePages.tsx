import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { DataTable } from '../components/DataTable'
import { PrimaryButton } from '../components/PrimaryButton'
import { pages } from '../data/pages'

export function ManagePages() {
  return (
    <AdminShell>
      <div className="mx-auto max-w-6xl px-6 py-8">
        <AdminPageHeader
          breadcrumb="Admin - Manage Pages"
          title="Manage Pages"
          subtitle="View and edit Pages."
          right={<PrimaryButton>+ Add Pages</PrimaryButton>}
        />
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
          <DataTable
            className="rounded-none border-0 shadow-none"
            rows={pages}
            getRowKey={(r) => r.pageId}
            columns={[
              {
                id: 'pid',
                header: 'Page id',
                headerClassName: 'text-neutral-500 font-semibold normal-case',
                cell: (r) => (
                  <span className="text-neutral-500">{r.pageId}</span>
                ),
              },
              {
                id: 'pname',
                header: 'Page Name',
                cell: (r) => (
                  <span className="font-semibold text-neutral-900">
                    {r.pageName}
                  </span>
                ),
              },
              {
                id: 'rid',
                header: 'Role id',
                headerClassName: 'text-neutral-500 font-semibold normal-case',
                cell: (r) => (
                  <span className="text-neutral-500">{r.roleId}</span>
                ),
              },
            ]}
            onEdit={(r) => console.log('edit', r)}
            onDelete={(r) => console.log('delete', r)}
          />
        </div>
      </div>
    </AdminShell>
  )
}
