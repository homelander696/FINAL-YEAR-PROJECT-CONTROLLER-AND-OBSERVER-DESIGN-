import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { DataTable } from '../components/DataTable'
import { PrimaryButton } from '../components/PrimaryButton'
import { gestures } from '../data/gestures'

export function ManageGestures() {
  return (
    <AdminShell>
      <div className="mx-auto max-w-6xl px-6 py-8">
        <AdminPageHeader
          breadcrumb="Admin - Manage Gestures"
          title="Manage Gestures"
          subtitle="View and edit Gestures."
          right={<PrimaryButton>+ Add gestures</PrimaryButton>}
        />
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
          <DataTable
            className="rounded-none border-0 shadow-none"
            rows={gestures}
            getRowKey={(r) => r.gestureId}
            columns={[
              { id: 'label', header: 'Label', cell: (r) => r.label },
              { id: 'gid', header: 'Gesture id', cell: (r) => r.gestureId },
              {
                id: 'name',
                header: 'Gesture name',
                cell: (r) => r.gestureName,
              },
              {
                id: 'sym',
                header: 'Gesture symbol',
                cell: (r) => (
                  <span className="text-lg" title={r.gestureName}>
                    {r.symbol}
                  </span>
                ),
                cellClassName: 'text-center sm:text-left',
              },
            ]}
            onEdit={(r) => console.log('edit', r)}
            onDelete={(r) => console.log('delete', r)}
          />
        </div>
      </div>
    </AdminShell>
  )
}
