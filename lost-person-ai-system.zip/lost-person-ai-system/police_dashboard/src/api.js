/**
 * Axios API client for the police dashboard.
 * Automatically attaches the JWT token from localStorage to every request.
 */

import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
})

// Attach Bearer token if available
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Redirect to login on 401
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

export const login = (username, password) =>
  api.post('/auth/login', { username, password })

// ---------------------------------------------------------------------------
// Alerts
// ---------------------------------------------------------------------------

export const fetchAlerts = () => api.get('/alerts')
export const fetchAlert  = (id) => api.get(`/alerts/${id}`)
export const updateAlert = (id, status) => api.patch(`/alerts/${id}`, { status })

// ---------------------------------------------------------------------------
// Lost Persons
// ---------------------------------------------------------------------------

export const fetchPersons = () => api.get('/persons')
export const fetchPerson  = (id) => api.get(`/persons/${id}`)
export const addPerson    = (formData) =>
  api.post('/persons', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })

export default api
