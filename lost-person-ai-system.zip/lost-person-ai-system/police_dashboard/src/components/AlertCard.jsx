import { formatDistanceToNow } from 'date-fns'
import { useNavigate } from 'react-router-dom'
import { MapPin, Activity, User, ChevronRight, Clock } from 'lucide-react'

function ConfidenceBadge({ level }) {
  const map = {
    strong_match:   { cls: 'badge-strong',   label: 'Strong Match' },
    possible_match: { cls: 'badge-possible', label: 'Possible Match' },
    low_confidence: { cls: 'badge-low',      label: 'Low Confidence' },
  }
  const { cls, label } = map[level] ?? { cls: 'badge-low', label: 'Unknown' }
  return <span className={cls}>{label}</span>
}

function StatusDot({ status }) {
  const map = {
    pending:  'bg-blue-400 animate-pulse-slow',
    accepted: 'bg-emerald-400',
    rejected: 'bg-gray-500',
  }
  return (
    <span className={`inline-block w-2 h-2 rounded-full ${map[status] ?? map.pending}`} />
  )
}

export default function AlertCard({ alert }) {
  const navigate = useNavigate()
  const timeAgo  = alert.timestamp
    ? formatDistanceToNow(new Date(alert.timestamp), { addSuffix: true })
    : 'Unknown'
  const score    = alert.similarity_score
    ? `${(alert.similarity_score * 100).toFixed(1)}%`
    : '—'

  return (
    <div
      onClick={() => navigate(`/alerts/${alert._id}`)}
      className="group glass-card-hover p-4 cursor-pointer"
    >
      <div className="flex items-center gap-4">

        {/* Thumbnail */}
        <div className="flex-shrink-0 relative">
          {alert.scanned_image ? (
            <img
              src={`data:image/jpeg;base64,${alert.scanned_image}`}
              alt="Scanned"
              className="w-14 h-14 rounded-xl object-cover border border-white/10"
            />
          ) : (
            <div className="w-14 h-14 rounded-xl bg-navy-700 border border-white/5 flex items-center justify-center">
              <User className="w-6 h-6 text-gray-600" />
            </div>
          )}
          <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-navy-800 border border-navy-900 flex items-center justify-center">
            <StatusDot status={alert.status} />
          </div>
        </div>

        {/* Details */}
        <div className="flex-1 min-w-0 space-y-1.5">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-white truncate text-sm">
              {alert.matched_person_name || 'Unknown Person'}
            </span>
            <ConfidenceBadge level={alert.confidence_level} />
          </div>

          <div className="flex items-center gap-3 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <Activity className="w-3 h-3 text-brand" />
              {score} similarity
            </span>
            {alert.gps_location && (
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-emerald-500" />
                {alert.gps_location.lat?.toFixed(3)}, {alert.gps_location.lng?.toFixed(3)}
              </span>
            )}
          </div>
        </div>

        {/* Right side */}
        <div className="flex flex-col items-end gap-2 flex-shrink-0">
          <span className={`badge text-[11px] ${
            alert.status === 'accepted' ? 'badge-accepted' :
            alert.status === 'rejected' ? 'badge-rejected' : 'badge-pending'
          }`}>
            {alert.status ?? 'pending'}
          </span>
          <span className="flex items-center gap-1 text-[11px] text-gray-600">
            <Clock className="w-3 h-3" />
            {timeAgo}
          </span>
        </div>

        {/* Arrow */}
        <ChevronRight className="w-4 h-4 text-gray-700 group-hover:text-gray-400 group-hover:translate-x-0.5 transition-all flex-shrink-0" />
      </div>

      {/* Subtle bottom progress bar for similarity score */}
      {alert.similarity_score && (
        <div className="mt-3 h-0.5 bg-white/5 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-700 ${
              alert.confidence_level === 'strong_match'
                ? 'bg-gradient-to-r from-emerald-500 to-emerald-400'
                : alert.confidence_level === 'possible_match'
                ? 'bg-gradient-to-r from-amber-500 to-amber-400'
                : 'bg-gradient-to-r from-yellow-600 to-yellow-500'
            }`}
            style={{ width: `${(alert.similarity_score * 100).toFixed(0)}%` }}
          />
        </div>
      )}
    </div>
  )
}
