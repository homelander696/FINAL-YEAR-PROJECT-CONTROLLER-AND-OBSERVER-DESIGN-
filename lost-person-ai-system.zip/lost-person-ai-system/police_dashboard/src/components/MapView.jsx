import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet'
import L from 'leaflet'
import { MapPin } from 'lucide-react'

// Fix default icon
delete L.Icon.Default.prototype._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

export default function MapView({ lat, lng, accuracy = 0, label = 'Alert location' }) {
  if (!lat || !lng) {
    return (
      <div className="w-full h-64 bg-navy-800/50 rounded-2xl border border-white/5 flex flex-col items-center justify-center gap-3 text-gray-600">
        <MapPin className="w-8 h-8 opacity-30" />
        <p className="text-sm">GPS coordinates unavailable</p>
      </div>
    )
  }

  return (
    <div className="rounded-2xl overflow-hidden border border-white/5" style={{ height: '280px' }}>
      <MapContainer
        center={[lat, lng]}
        zoom={14}
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {accuracy > 0 && (
          <Circle
            center={[lat, lng]}
            radius={accuracy}
            pathOptions={{ color: '#3B82F6', fillColor: '#3B82F6', fillOpacity: 0.1, weight: 1 }}
          />
        )}
        <Marker position={[lat, lng]}>
          <Popup className="text-sm font-medium">{label}</Popup>
        </Marker>
      </MapContainer>
    </div>
  )
}
