import { useNavigate, useLocation } from 'react-router-dom'
import { Shield, LogOut, UserPlus, LayoutDashboard, ChevronRight } from 'lucide-react'

export default function Navbar() {
  const navigate  = useNavigate()
  const location  = useLocation()
  const username  = localStorage.getItem('role') || 'officer'

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('role')
    navigate('/login')
  }

  const isActive = (path) => location.pathname === path

  return (
    <header className="sticky top-0 z-50 bg-navy-900/80 backdrop-blur-md border-b border-white/5">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-4">

        {/* Brand */}
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2.5 flex-shrink-0 group"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand to-violet-500 flex items-center justify-center shadow-glow-sm group-hover:shadow-glow transition-shadow">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <div className="leading-tight">
            <span className="font-bold text-white text-sm block">Lost Person AI</span>
            <span className="text-gray-500 text-[10px] block">Police Dashboard</span>
          </div>
        </button>

        {/* Breadcrumb (on detail pages) */}
        {location.pathname.startsWith('/alerts/') && (
          <div className="hidden sm:flex items-center gap-1 text-sm text-gray-500">
            <button onClick={() => navigate('/')} className="hover:text-gray-300 transition-colors">
              Dashboard
            </button>
            <ChevronRight className="w-3.5 h-3.5" />
            <span className="text-gray-300">Alert Detail</span>
          </div>
        )}

        {/* Right actions */}
        <div className="flex items-center gap-2 ml-auto">
          <button
            onClick={() => navigate('/')}
            className={`hidden sm:flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg transition-all duration-200 ${
              isActive('/')
                ? 'bg-brand/15 text-brand border border-brand/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            Alerts
          </button>

          <button
            onClick={() => navigate('/add-person')}
            className={`flex items-center gap-1.5 text-sm px-3 py-1.5 rounded-lg transition-all duration-200 ${
              isActive('/add-person')
                ? 'bg-brand/15 text-brand border border-brand/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span className="hidden sm:inline">Add Person</span>
          </button>

          {/* Avatar + logout */}
          <div className="flex items-center gap-2 pl-2 border-l border-white/10 ml-1">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-brand to-violet-500 flex items-center justify-center text-xs font-bold text-white uppercase">
              {username[0]}
            </div>
            <button
              onClick={handleLogout}
              title="Logout"
              className="p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-200"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
