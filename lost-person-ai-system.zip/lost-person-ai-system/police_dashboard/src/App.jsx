import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import AlertDetail from './pages/AlertDetail'
import AddPerson from './pages/AddPerson'

// Route guard — redirect to /login if no token stored
function PrivateRoute({ children }) {
  const token = localStorage.getItem('token')
  return token ? children : <Navigate to="/login" replace />
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login />} />

        <Route
          path="/"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          }
        />

        <Route
          path="/alerts/:id"
          element={
            <PrivateRoute>
              <AlertDetail />
            </PrivateRoute>
          }
        />

        <Route
          path="/add-person"
          element={
            <PrivateRoute>
              <AddPerson />
            </PrivateRoute>
          }
        />

        {/* Catch-all */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}
