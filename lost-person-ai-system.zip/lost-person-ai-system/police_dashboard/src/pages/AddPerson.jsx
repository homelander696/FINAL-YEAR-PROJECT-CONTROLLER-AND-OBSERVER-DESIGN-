import { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { addPerson } from '../api'
import Navbar from '../components/Navbar'
import {
  UserPlus, Upload, CheckCircle, AlertCircle,
  User, Hash, MapPin, Clock, X, ArrowLeft,
} from 'lucide-react'

export default function AddPerson() {
  const navigate   = useNavigate()
  const fileInputRef = useRef(null)
  const [form, setForm] = useState({
    name: '', age_at_missing: '', last_seen_location: '', case_id: '',
  })
  const [imageFile, setImageFile] = useState(null)
  const [preview, setPreview]     = useState(null)
  const [loading, setLoading]     = useState(false)
  const [success, setSuccess]     = useState(null)
  const [error, setError]         = useState('')
  const [dragOver, setDragOver]   = useState(false)

  const handleImageChange = (file) => {
    if (!file || !file.type.startsWith('image/')) return
    setImageFile(file)
    setPreview(URL.createObjectURL(file))
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files[0]
    handleImageChange(file)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!imageFile) { setError('Please upload a photo.'); return }
    setError('')
    setLoading(true)
    const data = new FormData()
    Object.entries(form).forEach(([k, v]) => data.append(k, v))
    data.append('image', imageFile)
    try {
      const { data: res } = await addPerson(data)
      setSuccess(res)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to register person.')
    } finally {
      setLoading(false)
    }
  }

  const reset = () => {
    setSuccess(null)
    setForm({ name: '', age_at_missing: '', last_seen_location: '', case_id: '' })
    setPreview(null)
    setImageFile(null)
    setError('')
  }

  return (
    <div className="min-h-screen bg-navy-950">
      <div className="bg-orb w-96 h-96 bg-violet-600/5 top-0 right-0" />
      <Navbar />

      <main className="relative z-10 max-w-2xl mx-auto px-4 py-8 page-enter">

        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <button onClick={() => navigate('/')} className="btn-ghost p-2">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-xl font-bold text-white">Register Missing Person</h2>
            <p className="text-gray-500 text-sm mt-0.5">
              Add a new record to the identification database
            </p>
          </div>
        </div>

        {success ? (
          /* ── Success state ── */
          <div className="glass-card p-10 text-center animate-fade-in">
            <div className="w-16 h-16 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center mx-auto mb-5">
              <CheckCircle className="w-9 h-9 text-emerald-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Person Registered</h3>
            <p className="text-gray-400 text-sm mb-1">
              Case ID: <span className="font-mono text-white bg-white/5 px-2 py-0.5 rounded">{success.case_id}</span>
            </p>
            <p className="text-gray-500 text-sm mb-8">
              Age progressions generated:{' '}
              {success.age_progressions_generated?.length > 0
                ? success.age_progressions_generated.join(', ')
                : 'none (fallback mode)'}
            </p>
            <div className="flex gap-3 justify-center">
              <button onClick={reset} className="btn-ghost">Add Another</button>
              <button onClick={() => navigate('/')} className="btn-primary">Go to Dashboard</button>
            </div>
          </div>
        ) : (
          /* ── Form ── */
          <div className="glass-card p-6">
            <form onSubmit={handleSubmit} className="space-y-6">

              {/* Image upload */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Photo of Missing Person <span className="text-red-400">*</span>
                </label>

                {preview ? (
                  <div className="relative rounded-2xl overflow-hidden border border-white/10 group">
                    <img src={preview} alt="Preview" className="w-full h-52 object-cover" />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => { setPreview(null); setImageFile(null) }}
                        className="flex items-center gap-1.5 bg-red-500/80 hover:bg-red-500 text-white text-sm px-3 py-1.5 rounded-lg transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                        Remove
                      </button>
                    </div>
                    <div className="absolute bottom-2 left-2 bg-black/60 rounded-lg px-2 py-1 text-xs text-gray-300">
                      {imageFile?.name}
                    </div>
                  </div>
                ) : (
                  <div
                    onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
                    onDragLeave={() => setDragOver(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                    className={`relative h-44 rounded-2xl border-2 border-dashed transition-all duration-200 cursor-pointer flex flex-col items-center justify-center gap-3 ${
                      dragOver
                        ? 'border-brand bg-brand/10 scale-[1.01]'
                        : 'border-white/10 hover:border-brand/40 hover:bg-white/[0.02] bg-navy-700/30'
                    }`}
                  >
                    <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                      <Upload className="w-6 h-6 text-gray-500" />
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-400">
                        <span className="text-brand font-medium">Click to upload</span> or drag and drop
                      </p>
                      <p className="text-xs text-gray-600 mt-1">JPEG, PNG — max 10 MB</p>
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageChange(e.target.files[0])}
                      className="hidden"
                    />
                  </div>
                )}
              </div>

              {/* Form fields grid */}
              <div className="grid sm:grid-cols-2 gap-4">
                <FormField
                  label="Full Name"
                  icon={<User className="w-4 h-4" />}
                  required
                >
                  <input
                    type="text"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="input-field pl-10"
                    placeholder="e.g. Priya Sharma"
                    required
                  />
                </FormField>

                <FormField
                  label="Age When Missing"
                  icon={<Clock className="w-4 h-4" />}
                  required
                >
                  <input
                    type="number"
                    min={1} max={120}
                    value={form.age_at_missing}
                    onChange={(e) => setForm({ ...form, age_at_missing: e.target.value })}
                    className="input-field pl-10"
                    placeholder="e.g. 28"
                    required
                  />
                </FormField>

                <FormField
                  label="Last Seen Location"
                  icon={<MapPin className="w-4 h-4" />}
                  required
                  fullWidth
                >
                  <input
                    type="text"
                    value={form.last_seen_location}
                    onChange={(e) => setForm({ ...form, last_seen_location: e.target.value })}
                    className="input-field pl-10"
                    placeholder="e.g. Connaught Place, New Delhi"
                    required
                  />
                </FormField>

                <FormField
                  label="Case ID (optional)"
                  icon={<Hash className="w-4 h-4" />}
                  fullWidth
                >
                  <input
                    type="text"
                    value={form.case_id}
                    onChange={(e) => setForm({ ...form, case_id: e.target.value })}
                    className="input-field pl-10 font-mono"
                    placeholder="e.g. DEL2024001"
                  />
                </FormField>
              </div>

              {/* Error */}
              {error && (
                <div className="flex items-center gap-2.5 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {error}
                </div>
              )}

              {/* Info note */}
              <div className="bg-brand/5 border border-brand/20 rounded-xl px-4 py-3 text-xs text-gray-400 flex items-start gap-2.5">
                <UserPlus className="w-4 h-4 text-brand mt-0.5 flex-shrink-0" />
                <span>
                  Upon submission, the system will automatically detect the face,
                  generate a 128-D embedding, and create age-progressed images
                  for <strong className="text-gray-300">+5, +10, and +15 years</strong>.
                </span>
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full flex items-center justify-center gap-2 py-3 text-base"
              >
                {loading ? (
                  <>
                    <svg className="w-5 h-5 animate-spin" viewBox="0 0 24 24" fill="none">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                    </svg>
                    Processing AI modules…
                  </>
                ) : (
                  <>
                    <UserPlus className="w-5 h-5" />
                    Register Person
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  )
}

function FormField({ label, icon, required, children, fullWidth }) {
  return (
    <div className={fullWidth ? 'sm:col-span-2' : ''}>
      <label className="block text-sm font-medium text-gray-300 mb-1.5">
        {label} {required && <span className="text-red-400">*</span>}
      </label>
      <div className="relative">
        <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none">
          {icon}
        </span>
        {children}
      </div>
    </div>
  )
}
