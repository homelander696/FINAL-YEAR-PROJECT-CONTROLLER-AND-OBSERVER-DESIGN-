import { useState, useEffect, useCallback } from 'react'
import { fetchAlerts } from '../api'
import AlertCard from '../components/AlertCard'
import Navbar from '../components/Navbar'
import { RefreshCw, Bell, CheckCircle, XCircle, Clock, AlertTriangle, TrendingUp } from 'lucide-react'

const TABS = [
  { key: 'all',      label: 'All Alerts', icon: Bell },
  { key: 'pending',  label: 'Pending',    icon: Clock },
  { key: 'accepted', label: 'Accepted',   icon: CheckCircle },
  { key: 'rejected', label: 'Rejected',   icon: XCircle },
]

export default function Dashboard() {
  const [alerts, setAlerts]   = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError]     = useState('')
  const [tab, setTab]         = useState('all')

  const loadAlerts = useCallback(async () => {
    try {
      const { data } = await fetchAlerts()
      setAlerts(data.alerts || [])
      setError('')
    } catch {
      setError('Failed to load alerts. Check your connection.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadAlerts()
    const interval = setInterval(loadAlerts, 30000)
    return () => clearInterval(interval)
  }, [loadAlerts])

  const filtered = tab === 'all' ? alerts : alerts.filter((a) => a.status === tab)

  const counts = {
    all:      alerts.length,
    pending:  alerts.filter((a) => a.status === 'pending').length,
    accepted: alerts.filter((a) => a.status === 'accepted').length,
    rejected: alerts.filter((a) => a.status === 'rejected').length,
  }

  const strongMatches = alerts.filter((a) => a.confidence_level === 'strong_match').length

  return (
    <div className="min-h-screen bg-navy-950">
      {/* Background orbs */}
      <div className="bg-orb w-[500px] h-[500px] bg-blue-600/5 top-0 right-0" />
      <div className="bg-orb w-96 h-96 bg-violet-600/5 bottom-0 left-0" />

      <Navbar />

      <main className="relative z-10 max-w-5xl mx-auto px-4 py-8 page-enter">

        {/* ── Header ── */}
        <div className="flex items-start justify-between mb-8 gap-4">
          <div>
            <h2 className="text-2xl font-bold text-white">Alert Feed</h2>
            <p className="text-gray-500 text-sm mt-1">
              Real-time face-match reports from the field
            </p>
          </div>
          <button
            onClick={loadAlerts}
            disabled={loading}
            className="btn-ghost flex items-center gap-2 flex-shrink-0"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Refresh</span>
          </button>
        </div>

        {/* ── Stat cards ── */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
          <StatCard
            label="Total Alerts"
            value={counts.all}
            icon={<Bell className="w-5 h-5" />}
            color="text-blue-400"
            bg="bg-blue-500/10"
          />
          <StatCard
            label="Pending Review"
            value={counts.pending}
            icon={<Clock className="w-5 h-5" />}
            color="text-amber-400"
            bg="bg-amber-500/10"
            pulse={counts.pending > 0}
          />
          <StatCard
            label="Accepted"
            value={counts.accepted}
            icon={<CheckCircle className="w-5 h-5" />}
            color="text-emerald-400"
            bg="bg-emerald-500/10"
          />
          <StatCard
            label="Strong Matches"
            value={strongMatches}
            icon={<TrendingUp className="w-5 h-5" />}
            color="text-violet-400"
            bg="bg-violet-500/10"
          />
        </div>

        {/* ── Tabs ── */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
          {TABS.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 flex-shrink-0 ${
                tab === key
                  ? 'bg-brand text-white shadow-glow-sm'
                  : 'bg-navy-800/50 text-gray-400 hover:text-white border border-white/5 hover:border-white/10'
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
              <span
                className={`text-xs px-1.5 py-0.5 rounded-full font-semibold ${
                  tab === key ? 'bg-white/20 text-white' : 'bg-white/5 text-gray-400'
                }`}
              >
                {counts[key]}
              </span>
            </button>
          ))}
        </div>

        {/* ── Error ── */}
        {error && (
          <div className="flex items-center gap-2.5 bg-red-500/10 border border-red-500/30 rounded-xl px-4 py-3 text-red-400 text-sm mb-5">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {/* ── List ── */}
        {loading && alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-56 gap-3 text-gray-600">
            <RefreshCw className="w-8 h-8 animate-spin" />
            <p className="text-sm">Loading alerts…</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 gap-4 text-gray-600">
            <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center">
              <Bell className="w-8 h-8 opacity-40" />
            </div>
            <div className="text-center">
              <p className="font-medium text-gray-400">No {tab !== 'all' ? tab : ''} alerts</p>
              <p className="text-sm mt-1">New reports will appear here automatically</p>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((alert, i) => (
              <div
                key={alert._id}
                style={{ animationDelay: `${i * 50}ms` }}
                className="animate-slide-up"
              >
                <AlertCard alert={alert} />
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}

function StatCard({ label, value, icon, color, bg, pulse }) {
  return (
    <div className="glass-card p-4 flex items-center gap-3 relative overflow-hidden">
      {pulse && (
        <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-amber-400 animate-pulse-slow" />
      )}
      <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center flex-shrink-0 ${color}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-2xl font-bold text-white leading-none">{value}</p>
        <p className="text-xs text-gray-500 mt-0.5 truncate">{label}</p>
      </div>
    </div>
  )
}
