import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { fetchAlert, fetchPerson, updateAlert } from '../api'
import MapView from '../components/MapView'
import Navbar from '../components/Navbar'
import { formatDistanceToNow, format } from 'date-fns'
import {
  ArrowLeft, CheckCircle, XCircle, Activity,
  MapPin, Clock, User, AlertCircle, Sparkles,
  ShieldCheck, Image as ImageIcon,
} from 'lucide-react'

const CONFIDENCE = {
  strong_match:   { badge: 'badge-strong',   label: 'Strong Match',   bar: 'from-emerald-500 to-emerald-400' },
  possible_match: { badge: 'badge-possible', label: 'Possible Match', bar: 'from-amber-500 to-amber-400' },
  low_confidence: { badge: 'badge-low',      label: 'Low Confidence', bar: 'from-yellow-600 to-yellow-500' },
}

export default function AlertDetail() {
  const { id }   = useParams()
  const navigate = useNavigate()
  const [alert, setAlert]       = useState(null)
  const [person, setPerson]     = useState(null)
  const [loading, setLoading]   = useState(true)
  const [actioning, setActioning] = useState(false)
  const [error, setError]       = useState('')
  const [toast, setToast]       = useState('')

  useEffect(() => {
    fetchAlert(id)
      .then(({ data }) => {
        setAlert(data)
        if (data.matched_person_id) {
          fetchPerson(data.matched_person_id)
            .then(({ data: p }) => setPerson(p))
            .catch(() => {})
        }
      })
      .catch(() => setError('Failed to load alert.'))
      .finally(() => setLoading(false))
  }, [id])

  const handleAction = async (status) => {
    setActioning(true)
    try {
      await updateAlert(id, status)
      setAlert((prev) => ({ ...prev, status }))
      setToast(`Alert marked as ${status}.`)
      setTimeout(() => setToast(''), 3000)
    } catch {
      setError('Failed to update alert.')
    } finally {
      setActioning(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-gray-600">
          <svg className="w-8 h-8 animate-spin text-brand" viewBox="0 0 24 24" fill="none">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
          </svg>
          <p className="text-sm">Loading alert…</p>
        </div>
      </div>
    )
  }

  if (error && !alert) {
    return (
      <div className="min-h-screen bg-navy-950 flex flex-col items-center justify-center gap-4">
        <AlertCircle className="w-12 h-12 text-red-400" />
        <p className="text-red-400">{error}</p>
        <button onClick={() => navigate('/')} className="btn-primary">Back to Dashboard</button>
      </div>
    )
  }

  const conf      = CONFIDENCE[alert.confidence_level] ?? CONFIDENCE.low_confidence
  const scoreNum  = alert.similarity_score ? alert.similarity_score * 100 : 0
  const gps       = alert.gps_location || {}
  const ageImages = alert.age_progressed_images || {}

  return (
    <div className="min-h-screen bg-navy-950">
      <div className="bg-orb w-96 h-96 bg-blue-600/5 top-0 right-0" />
      <Navbar />

      {/* Toast */}
      {toast && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-emerald-500 text-white px-5 py-2.5 rounded-full text-sm font-medium shadow-lg animate-fade-in flex items-center gap-2">
          <CheckCircle className="w-4 h-4" />
          {toast}
        </div>
      )}

      <main className="relative z-10 max-w-5xl mx-auto px-4 py-8 page-enter">

        {/* ── Back + title ── */}
        <div className="flex items-center gap-3 mb-8">
          <button
            onClick={() => navigate('/')}
            className="btn-ghost p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-xl font-bold text-white">Alert Detail</h2>
            <p className="text-[11px] text-gray-600 font-mono mt-0.5">{alert._id}</p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <span className={conf.badge}>{conf.label}</span>
            <span className={`badge ${
              alert.status === 'accepted' ? 'badge-accepted' :
              alert.status === 'rejected' ? 'badge-rejected' : 'badge-pending'
            }`}>
              {alert.status}
            </span>
          </div>
        </div>

        {/* ── Two-column grid ── */}
        <div className="grid lg:grid-cols-5 gap-5">

          {/* Left column (3/5) */}
          <div className="lg:col-span-3 space-y-5">

            {/* Similarity meter */}
            <div className="glass-card p-5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-semibold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-brand" />
                  Similarity Score
                </span>
                <span className="text-2xl font-bold text-white">
                  {scoreNum.toFixed(1)}<span className="text-sm text-gray-400">%</span>
                </span>
              </div>
              <div className="h-2.5 bg-white/5 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full bg-gradient-to-r ${conf.bar} transition-all duration-1000`}
                  style={{ width: `${scoreNum.toFixed(0)}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-gray-600 mt-1.5">
                <span>Low (70%)</span>
                <span>Strong (80%+)</span>
              </div>
            </div>

            {/* Photo comparison */}
            <div className="glass-card p-5">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-4">
                <ImageIcon className="w-4 h-4 text-brand" />
                Photo Comparison
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <PhotoBox
                  label="Scanned (Field)"
                  src={alert.scanned_image ? `data:image/jpeg;base64,${alert.scanned_image}` : null}
                  accentColor="border-amber-500/30"
                />
                <PhotoBox
                  label="Database (Original)"
                  src={person?.original_image ? `data:image/jpeg;base64,${person.original_image}` : null}
                  accentColor="border-brand/30"
                />
              </div>
            </div>

            {/* Age progressions */}
            {Object.keys(ageImages).length > 0 && (
              <div className="glass-card p-5">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-4">
                  <Sparkles className="w-4 h-4 text-violet-400" />
                  AI Age Progression
                </h3>
                <div className="grid grid-cols-3 gap-2">
                  {Object.entries(ageImages).map(([label, b64]) => (
                    <div key={label} className="text-center group">
                      <div className="relative overflow-hidden rounded-xl border border-white/5 group-hover:border-violet-500/30 transition-colors">
                        <img
                          src={`data:image/jpeg;base64,${b64}`}
                          alt={`Age ${label}`}
                          className="w-full h-28 object-cover"
                          onError={(e) => { e.target.style.display = 'none' }}
                        />
                        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/70 to-transparent py-1.5 px-2">
                          <span className="text-xs font-bold text-violet-300">{label} yrs</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right column (2/5) */}
          <div className="lg:col-span-2 space-y-5">

            {/* Person info */}
            <div className="glass-card p-5">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-4">
                <User className="w-4 h-4 text-brand" />
                Matched Person
              </h3>
              <div className="space-y-3">
                <InfoRow icon={<User className="w-3.5 h-3.5" />}    label="Name"      value={alert.matched_person_name || '—'} />
                <InfoRow icon={<ShieldCheck className="w-3.5 h-3.5" />} label="Case ID" value={person?.case_id || '—'} mono />
                <InfoRow icon={<Clock className="w-3.5 h-3.5" />}   label="Age when missing" value={person ? `${person.age_at_missing} yrs` : '—'} />
                <InfoRow icon={<MapPin className="w-3.5 h-3.5" />}  label="Last seen" value={person?.last_seen_location || '—'} />
              </div>
            </div>

            {/* Timestamp */}
            <div className="glass-card p-5">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-3">
                <Clock className="w-4 h-4 text-brand" />
                Report Time
              </h3>
              {alert.timestamp && (
                <div className="space-y-1">
                  <p className="text-white text-sm font-medium">
                    {format(new Date(alert.timestamp), 'dd MMM yyyy')}
                  </p>
                  <p className="text-gray-400 text-sm">
                    {format(new Date(alert.timestamp), 'HH:mm:ss')}
                  </p>
                  <p className="text-gray-600 text-xs">
                    {formatDistanceToNow(new Date(alert.timestamp), { addSuffix: true })}
                  </p>
                </div>
              )}
            </div>

            {/* Accept / Reject */}
            {alert.status === 'pending' && (
              <div className="glass-card p-5">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-2">
                  <ShieldCheck className="w-4 h-4 text-brand" />
                  Verification Decision
                </h3>
                <p className="text-xs text-gray-500 mb-4 leading-relaxed">
                  Review all photos and the map carefully. This action is logged and irreversible.
                </p>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => handleAction('accepted')}
                    disabled={actioning}
                    className="flex items-center justify-center gap-2 bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/30 hover:border-emerald-500/60 disabled:opacity-50 text-emerald-400 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 active:scale-95"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Accept — Confirm Match
                  </button>
                  <button
                    onClick={() => handleAction('rejected')}
                    disabled={actioning}
                    className="flex items-center justify-center gap-2 bg-gray-500/10 hover:bg-gray-500/20 border border-gray-500/20 hover:border-gray-500/40 disabled:opacity-50 text-gray-400 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 active:scale-95"
                  >
                    <XCircle className="w-4 h-4" />
                    Reject — False Positive
                  </button>
                </div>
              </div>
            )}

            {alert.status !== 'pending' && (
              <div className={`glass-card p-4 border ${
                alert.status === 'accepted'
                  ? 'border-emerald-500/20 bg-emerald-500/5'
                  : 'border-gray-500/20 bg-gray-500/5'
              }`}>
                <div className="flex items-center gap-2">
                  {alert.status === 'accepted'
                    ? <CheckCircle className="w-5 h-5 text-emerald-400" />
                    : <XCircle className="w-5 h-5 text-gray-400" />
                  }
                  <div>
                    <p className="text-sm font-semibold text-white capitalize">{alert.status}</p>
                    {alert.reviewed_at && (
                      <p className="text-xs text-gray-500">
                        {formatDistanceToNow(new Date(alert.reviewed_at), { addSuffix: true })}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ── Map (full width) ── */}
        <div className="glass-card p-5 mt-5">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2 mb-4">
            <MapPin className="w-4 h-4 text-brand" />
            GPS Location
            {gps.lat && (
              <span className="ml-auto text-xs font-normal text-gray-500 font-mono">
                {gps.lat?.toFixed(5)}, {gps.lng?.toFixed(5)}
                {gps.accuracy ? ` ±${gps.accuracy?.toFixed(0)}m` : ''}
              </span>
            )}
          </h3>
          <MapView
            lat={gps.lat}
            lng={gps.lng}
            accuracy={gps.accuracy}
            label={`${alert.matched_person_name || 'Alert'} — reported here`}
          />
        </div>

      </main>
    </div>
  )
}

// ── Helpers ──────────────────────────────────────────

function PhotoBox({ label, src, accentColor }) {
  return (
    <div className="text-center">
      <p className="text-[11px] text-gray-500 mb-2 font-medium">{label}</p>
      <div className={`rounded-xl overflow-hidden border ${accentColor || 'border-white/5'} bg-navy-700`}>
        {src ? (
          <img src={src} alt={label} className="w-full h-48 object-cover" />
        ) : (
          <div className="w-full h-48 flex items-center justify-center">
            <User className="w-10 h-10 text-gray-700" />
          </div>
        )}
      </div>
    </div>
  )
}

function InfoRow({ icon, label, value, mono }) {
  return (
    <div className="flex items-start gap-2.5">
      <span className="text-gray-500 mt-0.5 flex-shrink-0">{icon}</span>
      <div className="min-w-0">
        <p className="text-[11px] text-gray-600">{label}</p>
        <p className={`text-sm text-white truncate ${mono ? 'font-mono' : ''}`}>{value}</p>
      </div>
    </div>
  )
}
