/// API Service — communicates with the FastAPI backend.
///
/// Exposes a single method [scanFace] that sends the image and GPS
/// coordinates to POST /api/scan and returns the parsed JSON response.

import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const String _defaultBaseUrl = 'http://10.0.2.2:8000';
  static const String _prefKey = 'api_base_url';

  /// Read the saved API base URL (or fall back to emulator localhost).
  static Future<String> getBaseUrl() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_prefKey) ?? _defaultBaseUrl;
  }

  /// Persist a custom API base URL.
  static Future<void> setBaseUrl(String url) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, url);
  }

  /// POST /api/scan
  ///
  /// Sends the [imageFile] along with GPS coordinates to the backend.
  /// Returns the decoded JSON response map on success.
  /// Throws a [ScanException] on HTTP or parsing errors.
  static Future<Map<String, dynamic>> scanFace({
    required File imageFile,
    required double latitude,
    required double longitude,
    double accuracy = 0.0,
  }) async {
    final baseUrl = await getBaseUrl();
    final uri = Uri.parse('$baseUrl/api/scan');

    final request = http.MultipartRequest('POST', uri)
      ..fields['latitude']  = latitude.toString()
      ..fields['longitude'] = longitude.toString()
      ..fields['accuracy']  = accuracy.toString()
      ..files.add(
        await http.MultipartFile.fromPath('image', imageFile.path),
      );

    http.StreamedResponse streamedResponse;
    try {
      streamedResponse = await request.send().timeout(
        const Duration(seconds: 60),
      );
    } on SocketException catch (e) {
      throw ScanException('Cannot reach server: ${e.message}');
    } on Exception catch (e) {
      throw ScanException('Network error: $e');
    }

    final body = await streamedResponse.stream.bytesToString();

    if (streamedResponse.statusCode == 200) {
      return jsonDecode(body) as Map<String, dynamic>;
    }

    // Try to parse error detail from FastAPI
    try {
      final errJson = jsonDecode(body) as Map<String, dynamic>;
      throw ScanException(errJson['detail']?.toString() ?? 'Unknown error');
    } catch (_) {
      throw ScanException(
        'Server returned ${streamedResponse.statusCode}: $body',
      );
    }
  }
}

/// Thrown when [ApiService.scanFace] encounters an error.
class ScanException implements Exception {
  final String message;
  const ScanException(this.message);

  @override
  String toString() => 'ScanException: $message';
}
