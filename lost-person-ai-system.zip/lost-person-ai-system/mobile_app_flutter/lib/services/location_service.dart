/// Location Service — wraps the geolocator package.
///
/// Handles permission requests and GPS coordinate retrieval.

import 'package:geolocator/geolocator.dart';

class LocationService {
  /// Returns the current GPS [Position].
  ///
  /// Requests permissions if not already granted.
  /// Throws a [LocationException] if location cannot be obtained.
  static Future<Position> getCurrentPosition() async {
    // Check if location services are enabled on the device
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      throw const LocationException(
        'Location services are disabled. Please enable GPS.',
      );
    }

    LocationPermission permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        throw const LocationException('Location permission denied.');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      throw const LocationException(
        'Location permission permanently denied. '
        'Please enable it from app settings.',
      );
    }

    return Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );
  }

  /// Returns a human-readable string like "12.9716° N, 77.5946° E".
  static String formatPosition(Position pos) {
    final lat = pos.latitude.toStringAsFixed(4);
    final lng = pos.longitude.toStringAsFixed(4);
    final latDir = pos.latitude >= 0 ? 'N' : 'S';
    final lngDir = pos.longitude >= 0 ? 'E' : 'W';
    return '$lat° $latDir, $lng° $lngDir';
  }
}

/// Thrown when location cannot be obtained.
class LocationException implements Exception {
  final String message;
  const LocationException(this.message);

  @override
  String toString() => 'LocationException: $message';
}
