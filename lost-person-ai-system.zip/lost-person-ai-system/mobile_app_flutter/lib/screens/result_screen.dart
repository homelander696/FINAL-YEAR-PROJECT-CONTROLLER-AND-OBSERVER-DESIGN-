/// Result Screen — shown after a scan completes.
/// Fully redesigned with gradient cards and smooth layout.

import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

const kBg      = Color(0xFF070E17);
const kSurface = Color(0xFF1B2A3B);
const kBorder  = Color(0xFF253545);
const kBlue    = Color(0xFF3B82F6);
const kViolet  = Color(0xFF8B5CF6);

class ResultScreen extends StatelessWidget {
  final Map<String, dynamic> result;
  final File scannedImage;

  const ResultScreen({super.key, required this.result, required this.scannedImage});

  @override
  Widget build(BuildContext context) {
    final matchFound = result['match_found'] == true;

    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: kBorder),
            ),
            child: const Icon(Icons.arrow_back_ios_new, size: 16, color: Colors.white),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'Scan Result',
          style: TextStyle(
            color: Colors.white,
            fontSize: 17,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.3,
          ),
        ),
      ),
      body: matchFound
          ? _MatchBody(result: result, scannedImage: scannedImage)
          : const _NoMatchBody(),
    );
  }
}

// ── No match ─────────────────────────────────────────

class _NoMatchBody extends StatelessWidget {
  const _NoMatchBody();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90, height: 90,
              decoration: BoxDecoration(
                color: kSurface,
                shape: BoxShape.circle,
                border: Border.all(color: kBorder),
              ),
              child: const Icon(Icons.search_off, size: 44, color: Colors.white24),
            ),
            const SizedBox(height: 24),
            const Text(
              'No Match Found',
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.w700,
                letterSpacing: -0.5,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'The scanned face did not match any missing person in the database above the confidence threshold.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white38, fontSize: 14, height: 1.6),
            ),
            const SizedBox(height: 32),
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [kBlue, kViolet]),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Center(
                  child: Text(
                    'Try Again',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Match body ───────────────────────────────────────

class _MatchBody extends StatelessWidget {
  final Map<String, dynamic> result;
  final File scannedImage;

  const _MatchBody({required this.result, required this.scannedImage});

  @override
  Widget build(BuildContext context) {
    final person     = result['matched_person'] as Map<String, dynamic>? ?? {};
    final score      = (result['similarity_score'] as num?)?.toDouble() ?? 0.0;
    final confidence = result['confidence_level'] as String? ?? '';
    final alertId    = result['alert_id'] as String? ?? '';
    final gps        = result['gps_location'] as Map<String, dynamic>? ?? {};
    final ageImages  = person['age_progressed_images'] as Map<String, dynamic>? ?? {};

    final confColor  = _confColor(confidence);
    final confLabel  = _confLabel(confidence);

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 4, 20, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [

          // ── Match banner ──
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: confColor.withOpacity(0.08),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: confColor.withOpacity(0.35)),
            ),
            child: Row(
              children: [
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: confColor.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(Icons.verified_rounded, color: confColor, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        confLabel,
                        style: TextStyle(
                          color: confColor,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${(score * 100).toStringAsFixed(1)}% similarity',
                        style: const TextStyle(color: Colors.white54, fontSize: 13),
                      ),
                    ],
                  ),
                ),
                // Score ring
                _ScoreRing(score: score, color: confColor),
              ],
            ),
          ),

          const SizedBox(height: 14),

          // ── Person info ──
          _Card(
            title: 'Matched Person',
            icon: Icons.person_pin_rounded,
            child: Column(
              children: [
                _InfoRow('Full Name',   person['name']?.toString() ?? '—'),
                _InfoRow('Case ID',     person['case_id']?.toString() ?? '—', mono: true),
                _InfoRow('Age (missing)', '${person['age_at_missing'] ?? '—'} years'),
                _InfoRow('Alert ID',    alertId, mono: true),
                _InfoRow('GPS',         'Lat ${gps['lat']?.toStringAsFixed(4) ?? '—'}, Lng ${gps['lng']?.toStringAsFixed(4) ?? '—'}'),
              ],
            ),
          ),

          const SizedBox(height: 14),

          // ── Photo comparison ──
          _Card(
            title: 'Photo Comparison',
            icon: Icons.compare_rounded,
            child: Row(
              children: [
                Expanded(child: _PhotoBox(
                  label: 'Scanned',
                  child: Image.file(scannedImage, fit: BoxFit.cover),
                  accentColor: Colors.amber,
                )),
                const SizedBox(width: 10),
                Expanded(child: _PhotoBox(
                  label: 'Database',
                  child: _B64Image(b64: person['original_image']?.toString() ?? ''),
                  accentColor: kBlue,
                )),
              ],
            ),
          ),

          // ── Age progressions ──
          if (ageImages.isNotEmpty) ...[
            const SizedBox(height: 14),
            _Card(
              title: 'Age Progression',
              icon: Icons.auto_awesome_rounded,
              iconColor: kViolet,
              child: Row(
                children: ageImages.entries.map((e) => Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3),
                    child: Column(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: kViolet.withOpacity(0.4)),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: _B64Image(b64: e.value.toString(), height: 90),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          e.key,
                          style: const TextStyle(
                            color: kViolet,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                )).toList(),
              ),
            ),
          ],

          const SizedBox(height: 14),

          // ── Alert sent banner ──
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: kBlue.withOpacity(0.07),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: kBlue.withOpacity(0.25)),
            ),
            child: const Row(
              children: [
                Icon(Icons.notifications_active_rounded, color: kBlue, size: 20),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    'Alert sent to police dashboard for human verification.',
                    style: TextStyle(color: Colors.white60, fontSize: 12.5, height: 1.4),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 20),

          // ── Scan again ──
          GestureDetector(
            onTap: () => Navigator.popUntil(context, (r) => r.isFirst),
            child: Container(
              height: 54,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [kBlue, kViolet]),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [BoxShadow(color: kBlue.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 6))],
              ),
              child: const Center(
                child: Text(
                  'Scan Another Person',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _confColor(String l) => switch (l) {
    'strong_match'   => Colors.greenAccent,
    'possible_match' => Colors.orangeAccent,
    'low_confidence' => Colors.yellowAccent,
    _ => Colors.redAccent,
  };

  String _confLabel(String l) => switch (l) {
    'strong_match'   => 'Strong Match',
    'possible_match' => 'Possible Match',
    'low_confidence' => 'Low Confidence',
    _ => 'No Match',
  };
}

// ── Reusable widgets ──────────────────────────────────

class _Card extends StatelessWidget {
  final String   title;
  final IconData icon;
  final Widget   child;
  final Color    iconColor;

  const _Card({
    required this.title,
    required this.icon,
    required this.child,
    this.iconColor = kBlue,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: iconColor),
              const SizedBox(width: 6),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          child,
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  final bool   mono;

  const _InfoRow(this.label, this.value, {this.mono = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label, style: const TextStyle(color: Colors.white38, fontSize: 12)),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 12.5,
                fontFamily: mono ? 'monospace' : null,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PhotoBox extends StatelessWidget {
  final String label;
  final Widget child;
  final Color  accentColor;

  const _PhotoBox({required this.label, required this.child, required this.accentColor});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(label, style: TextStyle(color: accentColor.withOpacity(0.8), fontSize: 11, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Container(
            height: 130,
            decoration: BoxDecoration(
              border: Border.all(color: accentColor.withOpacity(0.35)),
              borderRadius: BorderRadius.circular(12),
            ),
            clipBehavior: Clip.antiAlias,
            child: child,
          ),
        ),
      ],
    );
  }
}

class _B64Image extends StatelessWidget {
  final String b64;
  final double height;

  const _B64Image({required this.b64, this.height = 130});

  @override
  Widget build(BuildContext context) {
    if (b64.isEmpty) return _placeholder(height);
    try {
      final bytes = base64Decode(b64);
      return Image.memory(
        bytes, height: height, width: double.infinity, fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => _placeholder(height),
      );
    } catch (_) {
      return _placeholder(height);
    }
  }

  Widget _placeholder(double h) => Container(
    height: h,
    color: kSurface,
    child: const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white12, size: 32)),
  );
}

class _ScoreRing extends StatelessWidget {
  final double score;
  final Color  color;

  const _ScoreRing({required this.score, required this.color});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 44, height: 44,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CircularProgressIndicator(
            value: score,
            backgroundColor: Colors.white10,
            valueColor: AlwaysStoppedAnimation<Color>(color),
            strokeWidth: 3,
          ),
          Text(
            '${(score * 100).toStringAsFixed(0)}',
            style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }
}
