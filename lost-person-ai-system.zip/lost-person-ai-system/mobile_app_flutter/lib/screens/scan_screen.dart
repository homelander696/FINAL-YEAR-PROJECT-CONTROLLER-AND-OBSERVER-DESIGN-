/// Scan Screen — main screen of the app.
/// Beautifully redesigned with animated face-scan overlay and gradient UI.

import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';

import '../services/api_service.dart';
import '../services/location_service.dart';
import 'result_screen.dart';
import 'settings_screen.dart';

// ── Brand colours ────────────────────────────────────
const kBg       = Color(0xFF070E17);
const kSurface  = Color(0xFF1B2A3B);
const kBorder   = Color(0xFF253545);
const kBlue     = Color(0xFF3B82F6);
const kBlueDark = Color(0xFF1D4ED8);
const kViolet   = Color(0xFF8B5CF6);

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});
  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> with TickerProviderStateMixin {
  final ImagePicker _picker = ImagePicker();

  File?     _selectedImage;
  Position? _currentPosition;
  bool      _isLoading   = false;
  String    _statusText  = 'Tap camera or gallery to\nselect a face photo';
  bool      _hasLocation = false;

  // Scan ring animation
  late final AnimationController _ringCtrl;
  late final Animation<double>    _ringAnim;

  @override
  void initState() {
    super.initState();
    _ringCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat();
    _ringAnim = CurvedAnimation(parent: _ringCtrl, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _ringCtrl.dispose();
    super.dispose();
  }

  // ── Capture ──────────────────────────────────────────

  Future<void> _captureFromCamera() async {
    final xFile = await _picker.pickImage(
      source: ImageSource.camera,
      preferredCameraDevice: CameraDevice.front,
      imageQuality: 90,
    );
    if (xFile != null) _setImage(File(xFile.path));
  }

  Future<void> _pickFromGallery() async {
    final xFile = await _picker.pickImage(source: ImageSource.gallery, imageQuality: 90);
    if (xFile != null) _setImage(File(xFile.path));
  }

  void _setImage(File file) {
    setState(() {
      _selectedImage = file;
      _statusText    = 'Image ready. Fetching GPS…';
      _hasLocation   = false;
    });
    _fetchLocation();
  }

  // ── GPS ──────────────────────────────────────────────

  Future<void> _fetchLocation() async {
    try {
      final pos = await LocationService.getCurrentPosition();
      setState(() {
        _currentPosition = pos;
        _hasLocation     = true;
        _statusText      = 'Ready to scan.\n${LocationService.formatPosition(pos)}';
      });
    } on LocationException catch (e) {
      setState(() => _statusText = 'GPS unavailable: ${e.message}');
    }
  }

  // ── Scan ─────────────────────────────────────────────

  Future<void> _startScan() async {
    if (_selectedImage == null) {
      _toast('Please select or capture a photo first.');
      return;
    }
    setState(() {
      _isLoading  = true;
      _statusText = 'Identifying face…';
    });
    try {
      final pos = _currentPosition ?? await LocationService.getCurrentPosition();
      final result = await ApiService.scanFace(
        imageFile:  _selectedImage!,
        latitude:   pos.latitude,
        longitude:  pos.longitude,
        accuracy:   pos.accuracy,
      );
      if (!mounted) return;
      Navigator.push(
        context,
        PageRouteBuilder(
          pageBuilder: (_, a1, a2) => ResultScreen(result: result, scannedImage: _selectedImage!),
          transitionsBuilder: (_, a1, __, child) =>
              FadeTransition(opacity: a1, child: SlideTransition(
                position: Tween(begin: const Offset(0, 0.05), end: Offset.zero)
                    .animate(CurvedAnimation(parent: a1, curve: Curves.easeOut)),
                child: child,
              )),
          transitionDuration: const Duration(milliseconds: 350),
        ),
      );
    } on ScanException catch (e) {
      _toast('Scan failed: ${e.message}');
    } on LocationException catch (e) {
      _toast('Location error: ${e.message}');
    } catch (e) {
      _toast('Unexpected error: $e');
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), margin: const EdgeInsets.all(16)),
    );
  }

  // ── Build ─────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      centerTitle: true,
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 28, height: 28,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [kBlue, kViolet]),
              borderRadius: BorderRadius.circular(7),
            ),
            child: const Icon(Icons.shield_rounded, size: 16, color: Colors.white),
          ),
          const SizedBox(width: 8),
          const Text(
            'Lost Person Finder',
            style: TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.3,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: kBorder),
            ),
            child: const Icon(Icons.settings_outlined, size: 18, color: Colors.white70),
          ),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const SettingsScreen()),
          ),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _buildBody() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF0D1B2A), kBg],
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ── Image preview / scan overlay ──
              Expanded(child: _buildPreviewArea()),
              const SizedBox(height: 16),

              // ── Status chip ──
              _buildStatusChip(),
              const SizedBox(height: 16),

              // ── Action buttons ──
              _buildActionRow(),
              const SizedBox(height: 12),

              // ── Scan button ──
              _buildScanButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPreviewArea() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: _selectedImage == null
            ? const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF1B2A3B), Color(0xFF0D1B2A)],
              )
            : null,
        border: Border.all(color: kBorder, width: 1),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(23),
        child: _selectedImage != null
            ? Stack(
                fit: StackFit.expand,
                children: [
                  Image.file(_selectedImage!, fit: BoxFit.cover),
                  // Gradient overlay at bottom
                  Positioned(
                    bottom: 0, left: 0, right: 0,
                    child: Container(
                      height: 80,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Colors.black54, Colors.transparent],
                        ),
                      ),
                    ),
                  ),
                  // GPS indicator
                  if (_hasLocation)
                    Positioned(
                      top: 12, right: 12,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.green.withOpacity(0.5)),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.location_on, size: 11, color: Colors.greenAccent),
                            SizedBox(width: 4),
                            Text('GPS', style: TextStyle(color: Colors.greenAccent, fontSize: 11)),
                          ],
                        ),
                      ),
                    ),
                ],
              )
            : Center(child: _buildPlaceholder()),
      ),
    );
  }

  Widget _buildPlaceholder() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Animated scan ring
        SizedBox(
          width: 140, height: 140,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer rotating ring
              AnimatedBuilder(
                animation: _ringAnim,
                builder: (_, __) => Transform.rotate(
                  angle: _ringAnim.value * 2 * math.pi,
                  child: CustomPaint(
                    size: const Size(140, 140),
                    painter: _RingPainter(),
                  ),
                ),
              ),
              // Face icon
              Container(
                width: 90, height: 90,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: kSurface,
                  border: Border.all(color: kBlue.withOpacity(0.4), width: 1.5),
                ),
                child: const Icon(
                  Icons.face_retouching_natural,
                  size: 44,
                  color: kBlue,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        const Text(
          'No photo selected',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'Capture or pick a face photo to identify\na missing person',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white38, fontSize: 13),
        ),
      ],
    );
  }

  Widget _buildStatusChip() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: kSurface.withOpacity(0.7),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _isLoading ? kBlue.withOpacity(0.5) : kBorder,
        ),
      ),
      child: Row(
        children: [
          if (_isLoading)
            const SizedBox(
              width: 14, height: 14,
              child: CircularProgressIndicator(strokeWidth: 2, color: kBlue),
            )
          else
            Icon(
              _hasLocation ? Icons.check_circle_outline : Icons.info_outline,
              size: 14,
              color: _hasLocation ? Colors.greenAccent : Colors.white38,
            ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              _statusText,
              style: const TextStyle(color: Colors.white60, fontSize: 12),
              maxLines: 2,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionRow() {
    return Row(
      children: [
        Expanded(child: _ActionButton(
          icon: Icons.camera_alt_rounded,
          label: 'Camera',
          gradient: const LinearGradient(colors: [Color(0xFF1B2A3B), Color(0xFF253545)]),
          onTap: _isLoading ? null : _captureFromCamera,
        )),
        const SizedBox(width: 12),
        Expanded(child: _ActionButton(
          icon: Icons.photo_library_rounded,
          label: 'Gallery',
          gradient: const LinearGradient(colors: [Color(0xFF1B2A3B), Color(0xFF253545)]),
          onTap: _isLoading ? null : _pickFromGallery,
        )),
      ],
    );
  }

  Widget _buildScanButton() {
    return GestureDetector(
      onTap: _isLoading ? null : _startScan,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 58,
        decoration: BoxDecoration(
          gradient: _isLoading || _selectedImage == null
              ? const LinearGradient(colors: [Color(0xFF253545), Color(0xFF1B2A3B)])
              : const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [kBlue, kViolet],
                ),
          borderRadius: BorderRadius.circular(16),
          boxShadow: _isLoading || _selectedImage == null
              ? []
              : [BoxShadow(color: kBlue.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 6))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_isLoading)
              const SizedBox(
                width: 22, height: 22,
                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
              )
            else
              const Icon(Icons.fingerprint, color: Colors.white, size: 24),
            const SizedBox(width: 10),
            Text(
              _isLoading ? 'Identifying...' : 'Scan & Identify',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Custom ring painter ───────────────────────────────

class _RingPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2 - 4;

    final paint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round
      ..shader = const SweepGradient(
        colors: [Colors.transparent, kBlue, kViolet, Colors.transparent],
        stops: [0.0, 0.3, 0.7, 1.0],
      ).createShader(Rect.fromCircle(center: center, radius: radius));

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      0,
      2 * math.pi * 0.75,
      false,
      paint,
    );
  }

  @override
  bool shouldRepaint(_) => false;
}

// ── Action button ─────────────────────────────────────

class _ActionButton extends StatelessWidget {
  final IconData    icon;
  final String      label;
  final LinearGradient gradient;
  final VoidCallback? onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.gradient,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Opacity(
        opacity: onTap == null ? 0.4 : 1.0,
        child: Container(
          height: 52,
          decoration: BoxDecoration(
            gradient: gradient,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: kBorder),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: kBlue, size: 20),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white70,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
