/// Settings Screen — beautifully redesigned.

import 'package:flutter/material.dart';
import '../services/api_service.dart';

const kBg      = Color(0xFF070E17);
const kSurface = Color(0xFF1B2A3B);
const kBorder  = Color(0xFF253545);
const kBlue    = Color(0xFF3B82F6);
const kViolet  = Color(0xFF8B5CF6);

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _urlCtrl;
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    _urlCtrl = TextEditingController();
    ApiService.getBaseUrl().then((url) {
      if (mounted) setState(() => _urlCtrl.text = url);
    });
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) return;
    await ApiService.setBaseUrl(url);
    setState(() => _saved = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _saved = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
          icon: Container(
            width: 34, height: 34,
            decoration: BoxDecoration(
              color: kSurface,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: kBorder),
            ),
            child: const Icon(Icons.arrow_back_ios_new, size: 16, color: Colors.white),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        centerTitle: true,
        title: const Text(
          'Settings',
          style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [

            // ── Section header ──
            const _SectionLabel('Connection'),

            // ── URL field card ──
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: kSurface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: kBorder),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Backend API URL',
                    style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'The address of the FastAPI server.',
                    style: TextStyle(color: Colors.white38, fontSize: 12),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: _urlCtrl,
                    keyboardType: TextInputType.url,
                    style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'monospace'),
                    decoration: InputDecoration(
                      hintText: 'http://192.168.1.100:8000',
                      hintStyle: const TextStyle(color: Colors.white24, fontSize: 13),
                      filled: true,
                      fillColor: kBg,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: kBorder),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: kBlue, width: 1.5),
                      ),
                      prefixIcon: const Icon(Icons.link_rounded, color: Colors.white24, size: 18),
                    ),
                  ),
                  const SizedBox(height: 14),
                  GestureDetector(
                    onTap: _save,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      height: 46,
                      decoration: BoxDecoration(
                        gradient: _saved
                            ? const LinearGradient(colors: [Color(0xFF059669), Color(0xFF10B981)])
                            : const LinearGradient(colors: [kBlue, kViolet]),
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(
                            color: (_saved ? Colors.green : kBlue).withOpacity(0.3),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          )
                        ],
                      ),
                      child: Center(
                        child: Text(
                          _saved ? '✓ Saved' : 'Save URL',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),
            const _SectionLabel('Quick Reference'),

            // ── Tip cards ──
            _TipCard(
              icon: Icons.phone_android_rounded,
              title: 'Android Emulator',
              tip: 'http://10.0.2.2:8000',
              color: Colors.greenAccent,
            ),
            const SizedBox(height: 8),
            _TipCard(
              icon: Icons.laptop_mac_rounded,
              title: 'iOS Simulator / macOS',
              tip: 'http://localhost:8000',
              color: Colors.blueAccent,
            ),
            const SizedBox(height: 8),
            _TipCard(
              icon: Icons.wifi_rounded,
              title: 'Physical Device',
              tip: 'Use your computer\'s local IP address\ne.g. http://192.168.1.100:8000',
              color: Colors.purpleAccent,
            ),

            const SizedBox(height: 24),
            const _SectionLabel('About'),

            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: kSurface,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: kBorder),
              ),
              child: const Column(
                children: [
                  _AboutRow('App', 'Lost Person Finder v1.0'),
                  Divider(color: kBorder, height: 20),
                  _AboutRow('Project', 'MCA Final Year Project'),
                  Divider(color: kBorder, height: 20),
                  _AboutRow('AI Model', 'FaceNet + MTCNN + SAM GAN'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Helper widgets ────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 4, bottom: 10),
      child: Text(
        text.toUpperCase(),
        style: const TextStyle(
          color: Colors.white38,
          fontSize: 11,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.2,
        ),
      ),
    );
  }
}

class _TipCard extends StatelessWidget {
  final IconData icon;
  final String   title;
  final String   tip;
  final Color    color;

  const _TipCard({required this.icon, required this.title, required this.tip, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: kSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: kBorder),
      ),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon, size: 18, color: color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(tip, style: const TextStyle(color: Colors.white38, fontSize: 11.5, fontFamily: 'monospace')),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AboutRow extends StatelessWidget {
  final String label;
  final String value;
  const _AboutRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text(label, style: const TextStyle(color: Colors.white38, fontSize: 13)),
        ),
        Expanded(
          child: Text(value, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500)),
        ),
      ],
    );
  }
}
