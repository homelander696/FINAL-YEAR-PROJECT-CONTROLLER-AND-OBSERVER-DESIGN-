# Datasets

This folder is for storing test images used during development.

## Structure

```
datasets/
├── test_faces/      # Sample face images for testing the scan endpoint
└── sample_persons/  # Sample missing person photos for seeding the database
```

## Testing

1. Place clear, well-lit face photos (JPEG or PNG) in `test_faces/`.
2. Use the seed script or Swagger UI at `http://localhost:8000/docs`
   to register them as lost persons via `POST /api/persons`.
3. Then test matching by uploading a different photo of the same person
   to `POST /api/scan`.

## Note

Do NOT commit real missing person photos to version control.
Use anonymised or synthetic faces for testing only.
