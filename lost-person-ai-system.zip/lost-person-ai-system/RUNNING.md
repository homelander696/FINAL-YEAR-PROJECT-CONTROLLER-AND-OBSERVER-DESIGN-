# Running Guide

> **AI-Based Lost & Found Person Identification System**
> How to start, test, and use every component of the system.

---

## Table of Contents

1. [Start Order](#1-start-order)
2. [Run the Backend (FastAPI)](#2-run-the-backend-fastapi)
3. [Run the Police Dashboard (React)](#3-run-the-police-dashboard-react)
4. [Run the Flutter Mobile App](#4-run-the-flutter-mobile-app)
5. [End-to-End Test Walkthrough](#5-end-to-end-test-walkthrough)
6. [Using the Swagger API Docs](#6-using-the-swagger-api-docs)
7. [Testing with curl / Postman](#7-testing-with-curl--postman)
8. [Stopping the Services](#8-stopping-the-services)

---

## 1. Start Order

Always start the services in this order:

```
1. Backend (FastAPI)     → must be running first
2. Police Dashboard      → needs the backend
3. Flutter App           → needs the backend
```

---

## 2. Run the Backend (FastAPI)

### Development mode (auto-reload on code changes)

```bash
cd backend_fastapi

# Activate virtual environment
source venv/bin/activate          # macOS/Linux
# venv\Scripts\activate           # Windows

# Start server
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### What you should see

```
INFO:     Will watch for changes in these directories: ['/path/to/backend_fastapi']
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

### Useful URLs

| URL | Description |
|---|---|
| `http://localhost:8000` | Health check |
| `http://localhost:8000/docs` | Swagger UI — interactive API docs |
| `http://localhost:8000/redoc` | ReDoc — alternative API docs |
| `http://localhost:8000/uploads/` | Served static uploaded files |

> **First run note:** MTCNN and FaceNet will download their model weights the first time a face is processed. This requires internet and takes 2–5 minutes. Subsequent runs are instant.

---

## 3. Run the Police Dashboard (React)

Open a **new terminal**:

```bash
cd police_dashboard
npm run dev
```

### What you should see

```
  VITE v5.x.x  ready in 500 ms

  ➜  Local:   http://localhost:3000/
  ➜  Network: http://192.168.1.x:3000/
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Login

Use the officer account you created during setup:
- **Username:** `officer1`
- **Password:** `Police@1234`

---

## 4. Run the Flutter Mobile App

Open a **new terminal**:

```bash
cd mobile_app_flutter

# Check connected devices/emulators
flutter devices

# Run on a specific device (use device ID from above)
flutter run -d <device-id>

# Or simply run (picks the only available device)
flutter run
```

### Running on Android emulator

```bash
# List available emulators
flutter emulators

# Launch an emulator
flutter emulators --launch Pixel_6_API_33

# Then run the app
flutter run
```

### Running on iOS simulator (macOS only)

```bash
# Open simulator
open -a Simulator

# Run app
flutter run
```

### Running on a physical device

1. Enable **Developer Options** on your Android device:
   - Settings → About Phone → tap **Build Number** 7 times
2. Enable **USB Debugging** in Developer Options
3. Connect device via USB
4. Confirm the prompt on your device
5. Run `flutter devices` — your device should appear
6. Run `flutter run -d <device-id>`
7. In the app, tap the settings icon and set the API URL to your computer's local IP:
   ```
   http://192.168.1.XXX:8000
   ```

### Build a release APK (to install without USB)

```bash
flutter build apk --release
# APK location: build/app/outputs/flutter-apk/app-release.apk
```

Transfer the APK to your phone and install it (enable "Install from unknown sources" in settings).

---

## 5. End-to-End Test Walkthrough

Follow these steps to test the complete system pipeline:

### Step 1 — Register a missing person

Open the Police Dashboard → click **Add Person** (top navigation).

Fill in:
- **Name:** Rahul Sharma
- **Age when missing:** 25
- **Last seen location:** Connaught Place, New Delhi
- **Case ID:** DEL2024001
- **Photo:** Upload a clear, well-lit face photo

Click **Register Person**.

The backend will:
1. Detect the face with MTCNN
2. Generate a 128-D FaceNet embedding
3. Generate +5, +10, +15 year age progressions
4. Store everything in MongoDB

You should see a success message with the Case ID.

---

### Step 2 — Scan a face using the mobile app

1. Open the Flutter app
2. Tap **Camera** to take a photo (or **Gallery** to pick one)
3. Use a photo of the same person you registered (or a similar one)
4. Tap **Scan & Identify**

The app will:
1. Send the image + GPS to `POST /api/scan`
2. Display the result with confidence score

---

### Step 3 — View and verify the alert

1. Open the Police Dashboard
2. Navigate to the **Alert Feed** (home page)
3. You should see a new alert with status **pending**
4. Click on it to see the full detail view

On the detail page:
- Compare the scanned photo vs database photo
- View age-progressed images
- See the GPS location on the map
- Click **Accept Match** or **Reject**

---

### Step 4 — Confirm the alert status updated

After clicking Accept/Reject:
- The alert status badge changes on the dashboard
- Go back to the Alert Feed and check the **Accepted** or **Rejected** tab

---

## 6. Using the Swagger API Docs

The backend auto-generates interactive API documentation at [http://localhost:8000/docs](http://localhost:8000/docs).

### How to authenticate in Swagger

1. First, call `POST /api/auth/login` with your credentials
2. Copy the `access_token` from the response
3. Click the **Authorize** button (lock icon, top right)
4. Enter: `Bearer <paste_token_here>`
5. Click **Authorize**

Now all subsequent requests in Swagger will include your JWT token.

### Test the scan endpoint in Swagger

1. Expand `POST /api/scan`
2. Click **Try it out**
3. Upload an image file
4. Enter latitude and longitude (any valid values, e.g., 28.6139 and 77.2090)
5. Click **Execute**
6. Scroll down to see the response

---

## 7. Testing with curl / Postman

### Register a police officer
```bash
curl -X POST http://localhost:8000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username": "officer1", "password": "Police@1234", "role": "officer"}'
```

### Login and get a token
```bash
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "officer1", "password": "Police@1234"}'
```

Copy the `access_token` from the response. Use it as `TOKEN` below.

### Add a missing person
```bash
curl -X POST http://localhost:8000/api/persons \
  -H "Authorization: Bearer TOKEN" \
  -F "name=Rahul Sharma" \
  -F "age_at_missing=25" \
  -F "last_seen_location=Connaught Place, New Delhi" \
  -F "case_id=DEL2024001" \
  -F "image=@/path/to/face_photo.jpg"
```

### Scan a face
```bash
curl -X POST http://localhost:8000/api/scan \
  -F "image=@/path/to/scan_photo.jpg" \
  -F "latitude=28.6139" \
  -F "longitude=77.2090" \
  -F "accuracy=10.0"
```

### List all alerts (protected)
```bash
curl http://localhost:8000/api/alerts \
  -H "Authorization: Bearer TOKEN"
```

### Accept an alert
```bash
curl -X PATCH http://localhost:8000/api/alerts/ALERT_ID \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"status": "accepted"}'
```

---

## 8. Stopping the Services

### Stop the backend
Press `Ctrl + C` in the terminal where uvicorn is running.

### Stop the React dashboard
Press `Ctrl + C` in the terminal where `npm run dev` is running.

### Stop the Flutter app
Press `q` in the terminal where `flutter run` is running (graceful stop).
Or press `Ctrl + C`.

### Deactivate Python virtual environment
```bash
deactivate
```

---

## Logs and Debugging

### Backend logs
All request logs appear in the uvicorn terminal. For more verbose output:
```bash
uvicorn main:app --reload --log-level debug --port 8000
```

### Flutter verbose logs
```bash
flutter run --verbose
```

### React build errors
```bash
npm run build
# Shows all TypeScript/ESLint errors
```

### Check MongoDB data directly
Use **MongoDB Compass** (free GUI):
1. Download from [https://www.mongodb.com/products/compass](https://www.mongodb.com/products/compass)
2. Connect with your `MONGODB_URI`
3. Browse `lost_found_db` → `lost_persons`, `alerts`, `police_users`
