# Setup Guide

> **AI-Based Lost & Found Person Identification System**
> Follow this guide from zero to a fully running system on your local machine.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Clone / Download the Project](#2-clone--download-the-project)
3. [MongoDB Setup (Atlas — Free Tier)](#3-mongodb-setup-atlas--free-tier)
4. [HuggingFace API Token](#4-huggingface-api-token)
5. [Backend Setup (Python + FastAPI)](#5-backend-setup-python--fastapi)
6. [Police Dashboard Setup (React)](#6-police-dashboard-setup-react)
7. [Flutter Mobile App Setup](#7-flutter-mobile-app-setup)
8. [Environment Variables Reference](#8-environment-variables-reference)
9. [Verify Everything is Working](#9-verify-everything-is-working)
10. [Common Setup Errors & Fixes](#10-common-setup-errors--fixes)

---

## 1. Prerequisites

Install all of the following before starting.

### System Requirements

| Requirement | Minimum | Recommended |
|---|---|---|
| RAM | 4 GB | 8 GB |
| Storage | 5 GB free | 10 GB free |
| OS | Windows 10 / macOS 11 / Ubuntu 20.04 | Latest version |
| Internet | Required | Required |

### Software to Install

#### Python 3.10 or 3.11
```bash
# Check if already installed
python --version    # or python3 --version

# Install on macOS (using Homebrew)
brew install python@3.11

# Install on Ubuntu/Debian
sudo apt update && sudo apt install python3.11 python3.11-venv python3-pip -y

# Windows — download installer from:
# https://www.python.org/downloads/
```

#### Node.js 18 or higher (for React dashboard)
```bash
# Check version
node --version

# Install via nvm (recommended)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
nvm install 18
nvm use 18

# Or download directly from: https://nodejs.org/
```

#### Flutter 3.19 or higher (for mobile app)
```bash
# Check version
flutter --version

# Install on macOS
brew install --cask flutter

# Or download from: https://docs.flutter.dev/get-started/install
# Follow the full Flutter installation guide for your OS
```

After installing Flutter, run the Flutter doctor:
```bash
flutter doctor
```
Resolve any issues it reports before continuing.

#### Git
```bash
git --version
# Install: https://git-scm.com/downloads
```

---

## 2. Clone / Download the Project

```bash
# If using Git
git clone <your-repo-url> lost-person-ai-system
cd lost-person-ai-system

# Or if you already have the files, just navigate to the project folder
cd /path/to/lost-person-ai-system
```

Your folder structure should look like:
```
lost-person-ai-system/
├── backend_fastapi/
├── mobile_app_flutter/
├── police_dashboard/
├── datasets/
└── README.md
```

---

## 3. MongoDB Setup (Atlas — Free Tier)

The system uses MongoDB to store missing persons, face embeddings, alerts, and police users.

### Step 1 — Create a free MongoDB Atlas account

1. Go to [https://www.mongodb.com/cloud/atlas](https://www.mongodb.com/cloud/atlas)
2. Click **Try Free** and sign up
3. Choose the **Free (M0)** tier when prompted
4. Select any cloud region near you (e.g., AWS Mumbai for India)
5. Click **Create Cluster** — takes about 3 minutes

### Step 2 — Create a database user

1. In Atlas left sidebar → **Database Access**
2. Click **Add New Database User**
3. Authentication: **Password**
4. Enter a username (e.g., `lostfound_user`) and a strong password
5. Role: **Read and write to any database**
6. Click **Add User**

### Step 3 — Whitelist your IP

1. In Atlas left sidebar → **Network Access**
2. Click **Add IP Address**
3. Click **Allow Access from Anywhere** (for development — use specific IPs in production)
4. Click **Confirm**

### Step 4 — Get your connection string

1. In Atlas → **Database** → Click **Connect**
2. Choose **Connect your application**
3. Driver: **Python**, Version: **3.6 or later**
4. Copy the connection string — it looks like:
   ```
   mongodb+srv://lostfound_user:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
5. Replace `<password>` with your actual password
6. Add the database name — change `/?retryWrites` to `/lost_found_db?retryWrites`:
   ```
   mongodb+srv://lostfound_user:yourpassword@cluster0.xxxxx.mongodb.net/lost_found_db?retryWrites=true&w=majority
   ```

Save this string — you'll need it in Step 5.

---

## 4. HuggingFace API Token

The age progression module uses the SAM (Style-based Age Manipulation) model hosted on HuggingFace.

> **Note:** If you don't have a HuggingFace token, the system will automatically fall back to the OpenCV age simulation. You can skip this step and the system will still work.

### To get a free HuggingFace token:

1. Go to [https://huggingface.co/join](https://huggingface.co/join) and create a free account
2. Click your profile icon → **Settings** → **Access Tokens**
3. Click **New token**
4. Name: `lost-found-project`, Role: **Read**
5. Click **Generate token**
6. Copy the token (starts with `hf_...`)

---

## 5. Backend Setup (Python + FastAPI)

```bash
cd backend_fastapi
```

### Step 1 — Create a Python virtual environment

```bash
# Create virtual environment
python -m venv venv

# Activate it
# macOS / Linux:
source venv/bin/activate

# Windows (Command Prompt):
venv\Scripts\activate.bat

# Windows (PowerShell):
venv\Scripts\Activate.ps1
```

You should see `(venv)` at the start of your terminal prompt.

### Step 2 — Install Python dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

> This will download and install TensorFlow, DeepFace, MTCNN, FastAPI, and all other dependencies.
> **This step takes 5–15 minutes** depending on your internet speed.
> TensorFlow alone is ~600 MB.

### Step 3 — Configure environment variables

```bash
# Copy the example file
cp .env.example .env

# Open .env in any text editor and fill in your values
```

Edit `.env`:
```
MONGODB_URI=mongodb+srv://lostfound_user:yourpassword@cluster0.xxxxx.mongodb.net/lost_found_db?retryWrites=true&w=majority
JWT_SECRET=my_super_secret_key_at_least_32_characters_long_123
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=480
HUGGINGFACE_API_TOKEN=hf_your_token_here
UPLOAD_DIR=uploads
```

**Important:** The `JWT_SECRET` must be at least 32 characters long and must be kept private.

### Step 4 — Seed the first police officer account

Start the server briefly to seed the database:
```bash
uvicorn main:app --reload --port 8000
```

In a **new terminal** (with venv activated), run:
```bash
curl -X POST http://localhost:8000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username": "officer1", "password": "Police@1234", "role": "officer"}'
```

You should receive:
```json
{"message": "User registered successfully.", "id": "..."}
```

Stop the server with `Ctrl + C`.

---

## 6. Police Dashboard Setup (React)

```bash
cd ../police_dashboard
```

### Step 1 — Install Node dependencies

```bash
npm install
```

This installs React, Vite, Tailwind CSS, React-Leaflet, Axios, and all other packages. Takes 1–2 minutes.

### Step 2 — Verify the proxy config

Open `vite.config.js`. The proxy is already configured to forward `/api` requests to `http://localhost:8000`.
No changes needed if you're running everything locally.

---

## 7. Flutter Mobile App Setup

```bash
cd ../mobile_app_flutter
```

### Step 1 — Get Flutter dependencies

```bash
flutter pub get
```

### Step 2 — Android setup (if running on Android)

Make sure you have:
- Android Studio installed: [https://developer.android.com/studio](https://developer.android.com/studio)
- Android SDK installed (via Android Studio → SDK Manager)
- An Android emulator created (via Android Studio → AVD Manager) **OR** a physical Android device with USB debugging enabled

Check:
```bash
flutter doctor -v
```
All Android items should show a checkmark.

### Step 3 — iOS setup (macOS only)

```bash
# Install Xcode from App Store
# Then install command-line tools:
sudo xcode-select --install

# Install CocoaPods
sudo gem install cocoapods

# Install iOS dependencies
cd ios
pod install
cd ..
```

### Step 4 — Set the backend URL

When you run the app on a **physical device**, it cannot reach `localhost`. You need to set your computer's local IP:

1. Find your local IP:
   ```bash
   # macOS / Linux:
   ipconfig getifaddr en0   # or: hostname -I

   # Windows:
   ipconfig   # look for IPv4 Address
   ```
2. After launching the app, tap the settings icon (top right) and enter:
   ```
   http://192.168.1.XXX:8000
   ```
   (replace with your actual IP)

For the **Android emulator**, the default `http://10.0.2.2:8000` is already configured — no change needed.

---

## 8. Environment Variables Reference

| Variable | Required | Description | Example |
|---|---|---|---|
| `MONGODB_URI` | Yes | Full MongoDB Atlas connection string | `mongodb+srv://user:pass@cluster...` |
| `JWT_SECRET` | Yes | Secret key for signing JWT tokens | `my_32_char_secret_key_abc123xyz` |
| `JWT_ALGORITHM` | No | JWT algorithm (default: HS256) | `HS256` |
| `JWT_EXPIRE_MINUTES` | No | Token expiry in minutes (default: 480) | `480` |
| `HUGGINGFACE_API_TOKEN` | No | Token for SAM age progression model | `hf_xxxxxxxxxxxx` |
| `UPLOAD_DIR` | No | Directory for image uploads (default: `uploads`) | `uploads` |

---

## 9. Verify Everything is Working

### Check backend health
```bash
curl http://localhost:8000/health
# Expected: {"status": "healthy"}
```

### Check API docs
Open: [http://localhost:8000/docs](http://localhost:8000/docs)
You should see the Swagger UI with all endpoints listed.

### Check MongoDB connection
```bash
curl http://localhost:8000/api/persons \
  -H "Authorization: Bearer <your_jwt_token>"
# Expected: {"total": 0, "persons": []}
```

### Check dashboard
Open: [http://localhost:3000](http://localhost:3000)
You should see the police login page.

---

## 10. Common Setup Errors & Fixes

### `ModuleNotFoundError: No module named 'deepface'`
```bash
# Make sure venv is activated
source venv/bin/activate
pip install deepface
```

### `tensorflow` installation fails on Apple Silicon (M1/M2/M3 Mac)
```bash
pip install tensorflow-macos
pip install tensorflow-metal   # optional — GPU acceleration
```

### `MTCNN` model download fails
MTCNN downloads its weights on first use. Ensure internet access when running the server for the first time.

### MongoDB connection timeout
- Verify your IP is whitelisted in Atlas → Network Access
- Check the connection string has the correct password
- Test with MongoDB Compass (free GUI): [https://www.mongodb.com/products/compass](https://www.mongodb.com/products/compass)

### Flutter: `No devices found`
```bash
# List connected devices
flutter devices

# Start Android emulator
flutter emulators --launch <emulator-id>
```

### Flutter: Camera permission denied on Android
Ensure `AndroidManifest.xml` has the camera permission (already included). On the device, go to **Settings → Apps → Lost Person Finder → Permissions → Enable Camera**.

### React dashboard: `Cannot connect to backend`
- Ensure the FastAPI server is running on port 8000
- Check browser console for CORS errors
- The Vite proxy (`vite.config.js`) only works in development mode (`npm run dev`)

### Port already in use
```bash
# Kill process on port 8000 (macOS/Linux)
lsof -ti:8000 | xargs kill -9

# Kill process on port 3000
lsof -ti:3000 | xargs kill -9
```
