# AI-Based Lost & Found Person Identification System

**MCA Final Year Project**

An end-to-end AI system that helps identify missing persons using face recognition, age progression, GPS alerting, and a police verification dashboard.

---

## Documentation

| Document | Description |
|---|---|
| [SETUP.md](SETUP.md) | First-time installation guide for all components |
| [RUNNING.md](RUNNING.md) | How to start and test the full system |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Deploy to cloud (Render, Vercel, Docker, AWS) |
| [INTERVIEW_QUESTIONS.md](INTERVIEW_QUESTIONS.md) | Top 100 Q&A for project viva and interviews |

---

## System Components

| Component | Technology | Location |
|---|---|---|
| Backend API | Python + FastAPI | `backend_fastapi/` |
| Face Detection | MTCNN (pretrained) | `backend_fastapi/face_detection/` |
| Face Recognition | DeepFace + FaceNet | `backend_fastapi/face_recognition/` |
| Age Progression | SAM GAN (HuggingFace) | `backend_fastapi/age_progression/` |
| Database | MongoDB | `backend_fastapi/database/` |
| Mobile App | Flutter | `mobile_app_flutter/` |
| Police Dashboard | React + Tailwind | `police_dashboard/` |

---

## Quick Start

### 1. Backend

```bash
cd backend_fastapi

# Create virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your MongoDB URI, JWT secret, and HuggingFace token

# Start the server
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

API docs: http://localhost:8000/docs

### 2. Seed a police officer account

```bash
curl -X POST http://localhost:8000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username": "officer1", "password": "securepassword123", "role": "officer"}'
```

### 3. Police Dashboard

```bash
cd police_dashboard
npm install
npm run dev
```

Open: http://localhost:3000

### 4. Flutter Mobile App

```bash
cd mobile_app_flutter
flutter pub get
flutter run
```

In the app Settings screen, set the backend URL:
- Android emulator: `http://10.0.2.2:8000`
- Physical device: `http://<your-local-ip>:8000`

---

## API Endpoints

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | No | Register police officer |
| POST | `/api/auth/login` | No | Login, get JWT token |
| POST | `/api/persons` | JWT | Add missing person |
| GET | `/api/persons` | JWT | List all persons |
| GET | `/api/persons/{id}` | JWT | Get person by ID |
| POST | `/api/scan` | No | Scan face + GPS |
| GET | `/api/alerts` | JWT | List all alerts |
| GET | `/api/alerts/{id}` | JWT | Get alert by ID |
| PATCH | `/api/alerts/{id}` | JWT | Accept / reject alert |

---

## System Flow

```
User scans face (Flutter app)
        │
        ▼
POST /api/scan  ──►  MTCNN face detection
                         │
                         ▼
                   FaceNet 128-D embedding
                         │
                         ▼
               Cosine similarity vs all DB embeddings
                         │
                ┌────────┴────────┐
           < 75%                > 75%
           No match         Match found
                                 │
                         GPS location captured
                                 │
                         Alert created in MongoDB
                                 │
                         Police dashboard notified
                                 │
                    Officer: Accept / Reject
```

---

## Similarity Thresholds

| Score | Label | Action |
|---|---|---|
| < 70% | No match | Ignored |
| 70–75% | Low confidence | Ignored (below alert threshold) |
| 75–80% | Possible match | Alert created |
| > 80% | Strong match | Alert created |

---

## Environment Variables

```
MONGODB_URI          MongoDB Atlas connection string
JWT_SECRET           Secret key for signing JWT tokens (min 32 chars)
JWT_ALGORITHM        HS256
JWT_EXPIRE_MINUTES   480 (8 hours)
HUGGINGFACE_API_TOKEN  Token for SAM age progression model
UPLOAD_DIR           Directory for storing uploaded images (default: uploads)
```

---

## Project Structure

```
lost-person-ai-system/
├── backend_fastapi/
│   ├── main.py                    FastAPI entry point
│   ├── requirements.txt
│   ├── .env                       (git-ignored)
│   ├── api/
│   │   ├── auth.py                JWT helpers + Depends guard
│   │   ├── routes_auth.py         /api/auth/*
│   │   ├── routes_persons.py      /api/persons/*
│   │   ├── routes_scan.py         /api/scan
│   │   └── routes_alerts.py       /api/alerts/*
│   ├── face_detection/
│   │   └── detector.py            MTCNN wrapper
│   ├── face_recognition/
│   │   └── embedder.py            FaceNet + cosine similarity
│   ├── age_progression/
│   │   └── age_gan.py             SAM GAN via HuggingFace + OpenCV fallback
│   └── database/
│       └── mongo.py               PyMongo CRUD helpers
├── mobile_app_flutter/
│   ├── pubspec.yaml
│   ├── android/app/src/main/AndroidManifest.xml
│   └── lib/
│       ├── main.dart
│       ├── screens/
│       │   ├── scan_screen.dart
│       │   ├── result_screen.dart
│       │   └── settings_screen.dart
│       └── services/
│           ├── api_service.dart
│           └── location_service.dart
├── police_dashboard/
│   ├── package.json
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── src/
│       ├── App.jsx
│       ├── api.js
│       ├── index.css
│       ├── main.jsx
│       ├── pages/
│       │   ├── Login.jsx
│       │   ├── Dashboard.jsx
│       │   ├── AlertDetail.jsx
│       │   └── AddPerson.jsx
│       └── components/
│           ├── AlertCard.jsx
│           ├── MapView.jsx
│           └── Navbar.jsx
└── datasets/
    └── README.md
```

---

## Technologies Used

- **FastAPI** — async Python web framework
- **MTCNN** — Multi-task Cascaded Convolutional Neural Networks for face detection
- **DeepFace + FaceNet** — pretrained face recognition, 128-D embeddings
- **SAM (yuval-alaluf/SAM)** — Style-based Age Manipulation GAN via HuggingFace
- **SciPy** — cosine similarity computation
- **MongoDB** — document store for persons, alerts, users
- **Flutter** — cross-platform mobile app (Android + iOS)
- **React + Vite + Tailwind CSS** — police dashboard
- **React-Leaflet + OpenStreetMap** — GPS map (no API key needed)
- **JWT (python-jose)** — stateless auth
