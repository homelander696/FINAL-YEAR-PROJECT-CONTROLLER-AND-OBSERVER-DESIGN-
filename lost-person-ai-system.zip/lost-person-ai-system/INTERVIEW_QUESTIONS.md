# Top 100 Interview Questions & Answers

> **AI-Based Lost & Found Person Identification System**
> Prepared for MCA Final Year Project viva, panel interviews, and technical discussions.

---

## Table of Contents

1. [Project Overview (Q1–Q10)](#category-1-project-overview)
2. [Face Detection — MTCNN (Q11–Q20)](#category-2-face-detection--mtcnn)
3. [Face Recognition — FaceNet & Embeddings (Q21–Q35)](#category-3-face-recognition--facenet--embeddings)
4. [Age Progression — GAN (Q36–Q45)](#category-4-age-progression--gan)
5. [Backend — FastAPI & Python (Q46–Q58)](#category-5-backend--fastapi--python)
6. [Database — MongoDB (Q59–Q67)](#category-6-database--mongodb)
7. [Security & Authentication (Q68–Q75)](#category-7-security--authentication)
8. [Flutter Mobile App (Q76–Q83)](#category-8-flutter-mobile-app)
9. [React Police Dashboard (Q84–Q90)](#category-9-react-police-dashboard)
10. [System Design & Architecture (Q91–Q100)](#category-10-system-design--architecture)

---

## Category 1: Project Overview

**Q1. What is the core problem this project solves?**

**A:** Traditional missing person identification relies on manual searching through physical records or social media, which is slow and error-prone. This system automates the identification process using AI. A bystander who spots a potentially missing person can scan their face using a mobile app. The system then compares the face against a police database of missing persons using deep learning-based face recognition, and if a match is found above the confidence threshold, it immediately sends an alert — including GPS location — to the police dashboard for human verification.

---

**Q2. What are the main components of this system?**

**A:** The system has four main components:
1. **Flutter Mobile App** — used by field agents or the public to scan a face and capture GPS coordinates
2. **FastAPI Backend** — the central server that runs all AI modules and manages data
3. **AI Modules** — three sub-modules: face detection (MTCNN), face recognition (FaceNet via DeepFace), and age progression (SAM GAN via HuggingFace)
4. **Police Dashboard** — a React web application where officers view alerts, compare photos, see the GPS location on a map, and accept or reject matches

---

**Q3. Why did you choose a pretrained model instead of training from scratch?**

**A:** Training a face recognition model from scratch requires:
- Millions of labelled face images (e.g., the LFW dataset has 13,000+ faces)
- High-end GPU hardware (NVIDIA A100 or V100)
- Days to weeks of training time
- Deep expertise in model architecture

For an MCA project, this is impractical. Pretrained models like FaceNet were trained on millions of faces by researchers at Google and achieve over 99% accuracy on standard benchmarks. Using them via the DeepFace library gives us production-quality results immediately. The principle is called **Transfer Learning** — leveraging knowledge learned on one task for another.

---

**Q4. What is the complete data flow when a face is scanned?**

**A:** The flow is:
1. User captures a photo in the Flutter app
2. App sends image + GPS (latitude, longitude) to `POST /api/scan`
3. Backend receives the image and passes it to MTCNN for face detection
4. MTCNN crops the detected face to 160×160 pixels
5. Cropped face is passed to DeepFace/FaceNet which generates a 128-dimensional embedding vector
6. The embedding is compared using cosine similarity against all stored embeddings in MongoDB
7. If the best match score is ≥ 75%, an alert is created in MongoDB with the scanned image, matched person ID, similarity score, and GPS coordinates
8. The result is returned to the Flutter app
9. The police dashboard displays the new alert for officer review

---

**Q5. What similarity thresholds did you use and why?**

**A:** We use cosine similarity (0 to 1 scale):
- **< 70%** → No match — ignored completely
- **70–75%** → Low confidence — computed but no alert created
- **75–80%** → Possible match — alert created with "possible_match" label
- **> 80%** → Strong match — alert created with "strong_match" label

These thresholds were derived from FaceNet research papers. The original FaceNet paper suggests a threshold of 0.40 using Euclidean distance on the 512-D embedding; we normalise and convert to cosine similarity. Setting the threshold too low creates false positives (innocent people matched with missing persons). Setting it too high causes false negatives (actual matches missed). 75% was chosen as a balance point for prototype purposes.

---

**Q6. How does the system handle false positives?**

**A:** We implement a mandatory **human-in-the-loop** verification step. Even when the AI returns a "strong match" (>80% similarity), the system:
1. Creates a pending alert — never automatically takes action
2. Shows the officer both photos side-by-side for visual comparison
3. Shows all age-progressed images of the missing person
4. Shows the GPS location on a map for context
5. Requires the officer to explicitly click "Accept" or "Reject"

Only after human verification is any official action taken. This is also stated clearly in the app UI with the message "Alert sent to police dashboard for human verification."

---

**Q7. What is age progression and why is it important in this system?**

**A:** Age progression (or age estimation/synthesis) is the process of predicting what a person would look like at a different age. It is critical in missing person cases because:
- A child missing at age 5 would look completely different at age 18
- Standard face matching would fail to find a match across a large age gap
- By generating predicted future-aged images (+5, +10, +15 years), the database becomes far more useful
- The police can compare current scans against age-progressed versions, not just the original photo

We use the **SAM (Style-based Age Manipulation)** model by Yuval Alaluf et al., which can add or subtract years from a face while preserving identity features.

---

**Q8. What are the limitations of this system?**

**A:** Key limitations include:
1. **Lighting and angle sensitivity:** Face detection and recognition accuracy drops significantly in poor lighting or extreme angles
2. **Database size:** Cosine similarity comparison is O(n) — linear scan — which slows down with a very large database
3. **Age progression accuracy:** The SAM model produces approximate results; actual aging varies by genetics, health, and environment
4. **No real-time video:** The current implementation processes single images, not video streams
5. **MongoDB base64 storage:** Storing images as base64 strings in MongoDB is inefficient at scale; a proper system would use object storage (AWS S3)
6. **Free tier API limits:** The HuggingFace API has rate limits and model loading delays

---

**Q9. How would you scale this system for a real national deployment?**

**A:** For national scale, I would:
1. Replace linear embedding scan with **Facebook FAISS** (vector similarity search) — handles billions of vectors in milliseconds
2. Use **AWS S3 or Azure Blob Storage** instead of base64 in MongoDB
3. Add a message queue (**RabbitMQ or Kafka**) between the scan endpoint and the matching engine for async processing
4. Deploy the backend with **auto-scaling** (Kubernetes or AWS ECS)
5. Add a **CDN** (CloudFront) for serving images quickly
6. Implement **role-based access control** — different dashboards for local police, state police, and national agencies
7. Add a **video streaming mode** for CCTV integration

---

**Q10. What is the project tech stack summary?**

**A:**
| Layer | Technology |
|---|---|
| Mobile App | Flutter (Dart) |
| Backend API | Python 3.11 + FastAPI |
| Face Detection | MTCNN |
| Face Recognition | DeepFace + FaceNet |
| Similarity | SciPy cosine distance |
| Age Progression | SAM GAN (HuggingFace Inference API) |
| Database | MongoDB Atlas (PyMongo) |
| Auth | JWT (python-jose + bcrypt) |
| Police Dashboard | React 18 + Vite + Tailwind CSS |
| Maps | React-Leaflet + OpenStreetMap |
| Deployment | Render / Vercel / Docker |

---

## Category 2: Face Detection — MTCNN

**Q11. What is MTCNN and how does it work?**

**A:** MTCNN stands for **Multi-task Cascaded Convolutional Neural Network**. It was proposed in the 2016 paper "Joint Face Detection and Alignment using Multi-task Cascaded Convolutional Networks." It works in three stages (a cascade):
1. **P-Net (Proposal Network):** Scans the image at multiple scales using sliding windows to generate candidate face regions quickly
2. **R-Net (Refine Network):** Takes the candidates from P-Net and rejects most of the false positives using a larger CNN
3. **O-Net (Output Network):** Refines the remaining candidates further and outputs the final bounding box, confidence score, and 5 facial landmark coordinates (two eyes, nose, two mouth corners)

The multi-scale approach allows MTCNN to detect faces of different sizes in the same image.

---

**Q12. Why did you choose MTCNN over other face detectors like Haar Cascades or YOLO?**

**A:**
- **Haar Cascades (OpenCV):** Fast but has high false positive rate and struggles with non-frontal faces and varying lighting
- **YOLO:** Designed primarily for general object detection; overkill for face-only detection and requires more compute
- **MTCNN:** Purpose-built for face detection with landmark localisation, works well with partial faces and varying angles, produces a confidence score, and is the standard choice for FaceNet preprocessing because FaceNet was designed to be paired with MTCNN

MTCNN also returns facial **keypoints** (eye positions, nose, mouth), which can be used for face alignment before recognition — improving embedding quality.

---

**Q13. What does the `min_confidence` parameter do in your detector?**

**A:** MTCNN's O-Net produces a confidence score between 0 and 1 for each detection, representing how certain the model is that the region contains a face. Our code sets `min_confidence=0.90` (90%), which means:
- Only detections with ≥ 90% confidence are accepted
- Lower confidence detections (possible reflections, drawings, partial faces) are discarded

This reduces false positives at the cost of occasionally missing genuinely low-confidence faces. For a security-sensitive application like this, precision (fewer false positives) is more important than recall.

---

**Q14. Why do you resize the cropped face to 160×160?**

**A:** FaceNet (the recognition model) was designed and trained to accept 160×160 pixel face images as input. This is hardcoded in the model architecture. Providing any other size would either:
- Cause an error if the input tensor shape doesn't match
- Produce unreliable embeddings if resized internally by the model

The 160×160 size was chosen by the FaceNet authors as a balance between capturing enough facial detail and keeping the input small enough for efficient processing.

---

**Q15. What is the `margin` parameter in face detection?**

**A:** The `margin` adds extra pixels around the bounding box before cropping. For example, with `margin=20`, if MTCNN returns a box `(x=50, y=30, w=100, h=120)`, the actual crop is from `(30, 10)` to `(170, 170)`. This is important because:
- MTCNN's bounding box sometimes clips the chin, forehead, or ears
- FaceNet performs better when the face has some context pixels around it
- The margin prevents losing facial features at the edges of the bounding box

---

**Q16. How do you handle an image with multiple faces?**

**A:** The `detect_face()` function uses this logic:
```python
best = max(valid, key=lambda d: d["box"][2] * d["box"][3])
```
It selects the face with the **largest bounding box area** (width × height), assuming the most prominent face in the frame is the person of interest. We also provide `detect_all_faces()` for cases where all faces need to be processed (e.g., a group photo search).

---

**Q17. What happens if no face is detected?**

**A:** The function raises a `ValueError` with a descriptive message:
```
"No face detected with confidence >= 90%. Ensure the image is well-lit and the face is clearly visible."
```
This exception is caught in the API route (`routes_scan.py` and `routes_persons.py`) and converted to an HTTP 400 Bad Request response with the same message, which is displayed to the user in the app.

---

**Q18. What is face alignment and did you implement it?**

**A:** Face alignment is the process of rotating and transforming a face so that the eyes, nose, and mouth are in standard positions before generating an embedding. This significantly improves recognition accuracy because the same face at different angles produces more similar embeddings after alignment.

MTCNN returns 5 facial keypoints (landmarks), which can be used to compute an affine transformation to align the face. In our implementation, we use DeepFace's built-in preprocessing which handles basic alignment internally. For the prototype, this is sufficient. A production system would explicitly align using the keypoints from MTCNN.

---

**Q19. What is the time complexity of face detection?**

**A:** MTCNN's three-stage cascade is designed to be efficient:
- P-Net is very fast (small network, sliding window)
- R-Net and O-Net process only a small fraction of candidates that passed P-Net
- On CPU, detecting a face in a 640×480 image takes approximately 0.1–0.5 seconds
- On GPU, this drops to under 10 milliseconds

For our use case (single image upload), this is fast enough. For real-time video (30 fps), GPU acceleration would be necessary.

---

**Q20. What is the difference between face detection and face recognition?**

**A:**
- **Face Detection** answers: "Is there a face in this image? Where is it?" — MTCNN solves this, returning bounding boxes
- **Face Recognition** answers: "Whose face is this?" — FaceNet solves this, comparing the detected face against known identities

Detection always comes first; recognition can only work on a properly cropped face region produced by detection. They are two separate, sequential steps.

---

## Category 3: Face Recognition — FaceNet & Embeddings

**Q21. What is FaceNet?**

**A:** FaceNet is a deep learning model developed by Google (Florian Schroff et al., 2015). It maps face images to a compact Euclidean space where distances directly correspond to face similarity. The key innovation is the **triplet loss function** used during training:
- A triplet consists of an anchor face, a positive face (same person), and a negative face (different person)
- The model learns to minimise distance between anchor and positive while maximising distance to negative
- This produces a 128-dimensional embedding vector that uniquely describes each face

FaceNet achieved 99.63% accuracy on the LFW (Labeled Faces in the Wild) benchmark.

---

**Q22. What is a face embedding?**

**A:** An embedding is a numerical representation of a face — specifically, a vector of 128 floating-point numbers. This vector captures the unique geometric features of a face (eye spacing, nose shape, jaw structure, etc.) in a way that:
- The same person's face always produces a similar vector (regardless of lighting, angle)
- Different people produce clearly different vectors
- The distance (cosine or Euclidean) between two vectors directly indicates how similar the faces are

128 dimensions is sufficient to uniquely represent faces while being compact enough for fast comparison.

---

**Q23. How does the DeepFace library work in your project?**

**A:** DeepFace is a Python library that wraps multiple face recognition models (FaceNet, VGG-Face, ArcFace, DeepFace, DeepID) in a unified API. We use it as:
```python
result = DeepFace.represent(
    img_path=face_array,
    model_name="Facenet",
    detector_backend="skip",  # face already cropped by MTCNN
    enforce_detection=False,
)
embedding = result[0]["embedding"]
```
Setting `detector_backend="skip"` is critical — it tells DeepFace not to run its internal face detector (since we already ran MTCNN), avoiding double-detection overhead.

---

**Q24. Why do you normalise the embedding vector?**

**A:** We normalise to unit length (L2 normalisation):
```python
norm = np.linalg.norm(embedding_arr)
embedding_arr = embedding_arr / norm
```
This ensures all embedding vectors lie on the unit hypersphere. When vectors are unit-normalised, cosine similarity and cosine distance become equivalent, and comparison is more numerically stable. It also prevents longer vectors (with larger magnitudes) from dominating similarity scores unfairly.

---

**Q25. What is cosine similarity and why use it over Euclidean distance?**

**A:** **Cosine similarity** measures the angle between two vectors, not their magnitude. Range: -1 to 1 (1 = identical direction = same face).

Formula: `cos(θ) = (A · B) / (||A|| × ||B||)`

We use `1 - scipy.spatial.distance.cosine(a, b)` to convert distance to similarity.

**Why cosine over Euclidean:**
- More robust to variations in image brightness and contrast (which scale the vector magnitude but not its direction)
- Standard for text and image embeddings in information retrieval
- FaceNet's original paper also uses cosine distance for comparison

---

**Q26. What is the `top_k` parameter in `match_embedding()`?**

**A:** `top_k=5` means the function returns at most the 5 best matches above the threshold. This is useful for:
- Showing multiple possible matches to the officer instead of just one
- Handling ambiguous cases where the system is not confident about a single best match
- Ranking results by similarity score for the user to review

In the current API response, `top_matches` contains the full ranked list, while `matched_person` contains the single best match used to create the alert.

---

**Q27. How do you store the face embedding in MongoDB?**

**A:** The 128-dimensional embedding vector is stored as a JSON array of 128 floats:
```json
{
  "face_embedding": [0.123, -0.456, 0.789, ...]
}
```
MongoDB natively supports arrays, so no serialisation is needed. When loading all embeddings for comparison, we use a projection query to fetch only `_id`, `face_embedding`, and metadata fields — avoiding loading large `original_image` base64 strings, which keeps memory usage low.

---

**Q28. What is the time complexity of face matching?**

**A:** The current implementation is **O(n)** — it computes cosine similarity against every record in the database. For the prototype with tens or hundreds of records, this is fine.

For a large-scale system with millions of records, we would use **FAISS (Facebook AI Similarity Search)**, which uses approximate nearest neighbour (ANN) algorithms (e.g., IVF, HNSW) to reduce the time complexity to approximately **O(log n)** or even **O(1)** for finding the k nearest neighbours.

---

**Q29. What is triplet loss in FaceNet training?**

**A:** Triplet loss is the training objective for FaceNet. For each training step, three images are selected:
- **Anchor (A):** A reference face of person X
- **Positive (P):** Another image of the same person X
- **Negative (N):** An image of a different person Y

The loss function: `L = max(0, ||f(A) - f(P)||² - ||f(A) - f(N)||² + α)`

Where `α` is a margin (set to 0.2 in the paper). The model learns to make `||A-P||` small and `||A-N||` large. Hard triplets (where the negative is very similar to the anchor) are especially useful for training.

---

**Q30. How does FaceNet differ from a simple CNN classifier?**

**A:** A standard CNN classifier would output class probabilities — one probability per known person. This requires:
- Retraining every time a new person is added
- The network to have a fixed number of output neurons equal to the number of people

FaceNet uses a **metric learning** approach — it outputs an embedding, not a class. To add a new person, you just:
1. Pass their photo through FaceNet to get an embedding
2. Store the embedding in the database

No retraining is ever needed. This is called an **open-set recognition system**, as opposed to a closed-set classifier.

---

**Q31. What accuracy does FaceNet achieve?**

**A:** FaceNet achieves:
- **99.63% accuracy** on the LFW (Labeled Faces in the Wild) benchmark
- **95.12% accuracy** on YouTube Faces DB
- These numbers are with the full 512-D model; the 128-D model (which we use) achieves slightly lower but still excellent accuracy

For comparison, human performance on LFW is approximately 97.53%, meaning FaceNet surpasses human-level performance on standard benchmarks.

---

**Q32. What is the difference between Facenet and Facenet512?**

**A:**
- **Facenet:** Produces 128-dimensional embedding vectors. Smaller, faster, slightly less accurate
- **Facenet512:** Produces 512-dimensional embeddings. Larger, slower, higher accuracy

We use the 128-D version because:
- It is faster to compare (fewer dimensions)
- Sufficient accuracy for a prototype
- Smaller storage footprint in MongoDB (128 floats vs 512 floats per person)

---

**Q33. What is the role of `enforce_detection=False` in DeepFace?**

**A:** By default, DeepFace will raise an exception if it cannot detect a face in the input image. Setting `enforce_detection=False` tells it to proceed even if no face is found, returning an embedding for whatever is in the image.

We set this because we already ran MTCNN detection, which guarantees the input is a valid face crop. If detection failed, the error is already raised before this point. This avoids redundant error handling and a second (potentially conflicting) detection attempt.

---

**Q34. Could you use ArcFace instead of FaceNet?**

**A:** Yes. ArcFace (2018) achieves higher accuracy than FaceNet on most benchmarks. It uses **Additive Angular Margin Loss** instead of triplet loss, which enforces larger angular margins between different identities. DeepFace supports ArcFace with:
```python
result = DeepFace.represent(img_path=face_array, model_name="ArcFace")
```
The trade-off is that ArcFace embeddings are 512-D by default, requiring more storage and computation per comparison. For this prototype, FaceNet-128 is sufficient.

---

**Q35. What is the "embedding drift" problem?**

**A:** Embedding drift occurs when a person's face changes over time (aging, weight change, facial hair) such that their current embedding is no longer similar to their stored embedding. This is exactly why we add age progression — to generate predicted embeddings for future appearances. In a production system, embeddings would be periodically updated as new verified photos of the person become available.

---

## Category 4: Age Progression — GAN

**Q36. What is a GAN and how does it work?**

**A:** GAN stands for **Generative Adversarial Network**, introduced by Ian Goodfellow et al. (2014). It consists of two neural networks that compete:
- **Generator (G):** Takes a noise vector (or image) as input and generates a fake image
- **Discriminator (D):** Takes an image and classifies it as real (from training data) or fake (from generator)

Training is a minimax game:
- G tries to fool D by generating increasingly realistic images
- D tries to correctly classify real vs fake
- At equilibrium, G produces images indistinguishable from real data

For age progression specifically, conditional GANs (cGANs) are used where the age target is given as a condition.

---

**Q37. What is the SAM model and how does it do age progression?**

**A:** SAM (**Style-based Age Manipulation**) by Yuval Alaluf et al. (2021) is built on top of **StyleGAN2**, a state-of-the-art GAN architecture. Key features:
1. **Encoder:** Maps the input face to StyleGAN2's latent space (W+)
2. **Age mapper:** A small network that takes the current age and target age and predicts how to shift the latent code to change age
3. **StyleGAN2 decoder:** Generates the aged face from the modified latent code

The identity is preserved because the modification happens only along the age dimension of the latent space, while other identity-related dimensions remain unchanged. The model was trained on the FFHQ dataset (70,000 high-quality face images).

---

**Q38. What is the W+ latent space in StyleGAN?**

**A:** StyleGAN2 uses an intermediate latent space W (18×512 dimensional — one 512-D vector for each of 18 layers). The W+ space is an extended version where each layer has its own style vector. This gives fine-grained control:
- Earlier layers control coarse features (pose, overall shape)
- Middle layers control style (facial structure)
- Later layers control fine details (colour, texture)

Age progression changes primarily the middle layers (which affect skin texture, wrinkle patterns) while keeping early layers (identity/shape) fixed. This is what allows SAM to change apparent age without changing identity.

---

**Q39. What is the difference between age estimation and age progression?**

**A:**
- **Age estimation:** Predicts the person's current age from their photo (classification/regression problem). "This person looks 35 years old."
- **Age progression:** Synthesises what the person will look like at a different age (image generation problem). "Generate what this person will look like at 50."

Our system does both — estimating age at registration (provided by the officer) and synthesising future-aged versions.

---

**Q40. Why does your system generate +5, +10, and +15 year progressions?**

**A:** Missing persons cases often span years or decades. A person missing at age 10:
- At +5 years (age 15): adolescent appearance changes
- At +10 years (age 20): adult facial structure
- At +15 years (age 25): fully mature appearance

Generating multiple intervals covers the realistic range of how long a case might remain unsolved. The police dashboard displays all three versions so officers can compare a scanned face against the progression that best matches the estimated current age.

---

**Q41. What is the OpenCV fallback age simulation and when is it used?**

**A:** The HuggingFace API requires:
- A valid API token
- Internet connectivity
- The model to be loaded (it can be in sleep mode, causing 30-60s delay)

The OpenCV fallback is used when:
- No valid HuggingFace token is configured
- The API returns an error or timeout

The fallback applies three visual effects to simulate aging:
1. **Gaussian blur** — simulates loss of skin smoothness (progressive)
2. **Colour channel shift** — adds a yellowish/brown tint (skin pigmentation change)
3. **Contrast reduction** — softens highlights

This is purely cosmetic and not AI-based — it's a demo fallback, clearly documented as such.

---

**Q42. What are the limitations of GAN-based age progression?**

**A:**
1. **Identity drift:** As age offset increases, the generated image may lose resemblance to the original person
2. **Gender and ethnicity bias:** Models trained primarily on FFHQ (majority Western faces) may produce less accurate results for other ethnicities
3. **Hallucinated details:** GANs can add features (wrinkles, grey hair) that don't match the person's actual genetics
4. **No medical information:** Real aging depends on health, diet, sun exposure — none of which the model accounts for
5. **High compute:** SAM requires GPU for fast inference; CPU inference takes minutes

---

**Q43. What is Mode Collapse in GANs?**

**A:** Mode collapse is a training failure where the Generator learns to produce only one or a few types of outputs (modes) that fool the Discriminator, rather than the full diversity of the training data. For example, a GAN trained on faces might only generate one face type.

Symptoms: The Generator output looks repetitive/similar regardless of input.

Solutions: Wasserstein GAN (WGAN), spectral normalisation, mini-batch discrimination, progressive growing (used in StyleGAN).

---

**Q44. What is progressive growing of GANs (used in StyleGAN)?**

**A:** Progressive growing (ProGAN, 2018) starts training at low resolution (4×4) and progressively adds new layers to increase resolution (8×8 → 16×16 → ... → 1024×1024). Benefits:
- Training is faster and more stable at low resolutions first
- The network learns coarse features before fine details
- Avoids the instability of training a deep high-resolution network from scratch

StyleGAN inherits this approach and adds style-based control (per-layer noise injection and adaptive instance normalisation).

---

**Q45. What alternative age progression models could you have used?**

**A:**
1. **FRAN (Face Re-Aging Network, 2022, Disney Research):** Very high quality but not publicly available
2. **HRFAE (High Resolution Face Age Editing):** Open source, focuses on large age gaps
3. **LIFESPAN (2020):** Handles extreme age ranges including elderly
4. **Age-cGAN:** Conditional GAN specifically for face aging, older but simpler
5. **Diffusion Models (e.g., Stable Diffusion with IP-Adapter):** Latest trend — text-guided age editing

We chose SAM because it is openly available on HuggingFace, produces good results on adults, and the inference API makes integration straightforward without local GPU.

---

## Category 5: Backend — FastAPI & Python

**Q46. Why did you use FastAPI instead of Flask or Django?**

**A:**
| Feature | FastAPI | Flask | Django |
|---|---|---|---|
| Performance | Very fast (async) | Moderate | Moderate |
| Auto API docs | Yes (Swagger + ReDoc) | No | No |
| Type validation | Pydantic (built-in) | Manual | DRF serialisers |
| Async support | Native (ASGI) | Limited (WSGI) | Partial |
| Learning curve | Low | Very low | High |

FastAPI is the best choice for an AI/ML API because:
- Native async support means file uploads and AI inference don't block other requests
- Pydantic models validate request/response types automatically
- Auto-generated Swagger UI makes testing APIs without Postman easy
- It's the fastest Python web framework in benchmarks (comparable to Node.js)

---

**Q47. What is ASGI and how does it differ from WSGI?**

**A:**
- **WSGI (Web Server Gateway Interface):** Synchronous Python web standard. Processes one request at a time per thread. Used by Flask, Django.
- **ASGI (Asynchronous Server Gateway Interface):** Async Python web standard. Can handle thousands of concurrent connections using a single thread via Python's `asyncio` event loop.

FastAPI runs on ASGI (via Uvicorn), which is why it uses `async def` route handlers. For image upload endpoints that may take 2-5 seconds for AI processing, ASGI allows other lightweight requests (health checks, alert reads) to be served concurrently without waiting.

---

**Q48. What is Pydantic and how is it used in FastAPI?**

**A:** Pydantic is a Python data validation library. In FastAPI, it's used to define request and response schemas:
```python
class LoginRequest(BaseModel):
    username: str
    password: str
```
FastAPI automatically:
1. Parses the incoming JSON body
2. Validates that `username` and `password` are strings
3. Returns a 422 Unprocessable Entity error with details if validation fails
4. Generates the Swagger UI schema from the Pydantic model

---

**Q49. What is dependency injection in FastAPI?**

**A:** FastAPI's `Depends()` system allows declaring shared dependencies that are injected into route functions. We use it for JWT authentication:
```python
@router.get("/")
def list_alerts(_auth: dict = Depends(require_auth)):
    ...
```
`require_auth` is called before the route function. If the JWT is invalid, it raises HTTP 401 and the route body never executes. Benefits:
- Authentication logic is written once and reused everywhere
- Easy to add/remove protection from routes
- Testable in isolation

---

**Q50. What is multipart/form-data and why is it used for image upload?**

**A:** `multipart/form-data` is an HTTP content type for sending binary files and form fields in the same request body, separated by a boundary string. It's used instead of JSON because:
- JSON requires base64-encoding binary data, which increases size by ~33%
- `multipart/form-data` sends raw bytes, which is efficient for images
- It allows mixing text fields (name, latitude) with binary files (image) in one request

FastAPI uses `UploadFile` and `File` for multipart:
```python
async def scan_face(image: UploadFile = File(...), latitude: float = Form(...)):
    raw_bytes = await image.read()
```

---

**Q51. What is CORS and why do you enable it?**

**A:** CORS (Cross-Origin Resource Sharing) is a browser security mechanism that blocks JavaScript from making requests to a different domain than the page it loaded from. Without CORS headers:
- The React dashboard at `localhost:3000` cannot call the API at `localhost:8000`
- The browser would block the request with a CORS error

We add FastAPI's `CORSMiddleware` to send the appropriate `Access-Control-Allow-Origin` headers. In development, `allow_origins=["*"]` is used; in production, it should be set to the specific dashboard domain.

---

**Q52. What is the difference between `async def` and `def` in FastAPI routes?**

**A:**
- `async def` routes run in the event loop and should be used when the function does I/O (file reads, database calls, network requests) using `await`
- `def` routes run in a thread pool executor, preventing them from blocking the event loop

In our code, `scan_face` is `async def` because we `await image.read()`. The MongoDB calls in `database/mongo.py` are synchronous (PyMongo is not async), so routes that call them should ideally be `def` — though FastAPI handles this gracefully by running them in a thread pool.

---

**Q53. How does the lifespan context manager work in FastAPI?**

**A:** The `@asynccontextmanager` lifespan function replaces the old `@app.on_event("startup")` and `@app.on_event("shutdown")` decorators:
```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    os.makedirs(upload_dir, exist_ok=True)  # startup
    yield
    # shutdown code here
```
Code before `yield` runs at startup; code after `yield` runs at shutdown. We use it to ensure the `uploads/` directory exists before the static file server tries to serve from it.

---

**Q54. What is the purpose of `StaticFiles` in your FastAPI setup?**

**A:** `StaticFiles` mounts a directory as a static file server:
```python
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")
```
This allows uploaded images to be accessed directly by URL (e.g., `http://localhost:8000/uploads/photo.jpg`) without writing a separate route. The police dashboard can display images using `<img src="http://backend/uploads/..." />`. This is a simple alternative to a dedicated file storage service for the prototype.

---

**Q55. What HTTP status codes does your API return and why?**

**A:**
| Code | Meaning | Where Used |
|---|---|---|
| 200 OK | Success | GET endpoints, successful scan |
| 201 Created | Resource created | POST /persons, POST /auth/register |
| 400 Bad Request | Client error | No face detected in image |
| 401 Unauthorized | Missing/invalid JWT | All protected routes |
| 404 Not Found | Resource missing | GET /persons/id, GET /alerts/id |
| 409 Conflict | Duplicate resource | Register with existing username |
| 422 Unprocessable Entity | Validation error | Wrong field types in request |
| 500 Internal Server Error | Server error | Embedding generation failure |

---

**Q56. How does error handling work in your routes?**

**A:** We use FastAPI's `HTTPException` for intentional errors:
```python
raise HTTPException(status_code=400, detail="No face detected.")
```
This automatically returns a JSON response: `{"detail": "No face detected."}`.

For unexpected errors (model failures), we wrap in try/except and raise an HTTP 500:
```python
try:
    embedding = generate_embedding(face_crop)
except Exception as exc:
    raise HTTPException(status_code=500, detail=f"Embedding failed: {exc}")
```

The age progression failure is non-fatal — the person is registered without age progressions if the GAN fails, and `age_progressions_generated` in the response will be an empty list.

---

**Q57. Why is the `/api/scan` endpoint public (no JWT required)?**

**A:** The scan endpoint is intentionally public because:
- The mobile app is used by general public members or field agents who do not have police officer accounts
- Requiring login would create friction and reduce the likelihood of reports
- The endpoint only creates a "pending" alert — it does not reveal any police database information to the caller
- Human verification by a police officer (who does require authentication) is mandatory before any action is taken

The security model is: **anyone can report, only authenticated officers can act on reports.**

---

**Q58. How would you add rate limiting to prevent abuse of the scan endpoint?**

**A:** Using `slowapi` (FastAPI-compatible rate limiting library):
```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

@router.post("/")
@limiter.limit("10/minute")
async def scan_face(request: Request, ...):
    ...
```
This limits each IP address to 10 scan requests per minute. Exceeding this returns HTTP 429 (Too Many Requests). In production, we'd also add device fingerprinting and require app-level API keys.

---

## Category 6: Database — MongoDB

**Q59. Why did you choose MongoDB over a relational database like MySQL?**

**A:**
1. **Flexible schema:** Face embeddings (128-D arrays), base64 images, and nested GPS objects don't map cleanly to relational tables
2. **Native JSON/BSON:** MongoDB stores documents in BSON (Binary JSON), making Python dict ↔ MongoDB document conversion seamless
3. **Array fields:** The `face_embedding` field (list of 128 floats) is a native MongoDB array — no join tables needed
4. **Free Atlas tier:** MongoDB Atlas offers a generous free M0 cluster
5. **Easy scaling:** MongoDB Atlas supports automatic sharding for horizontal scale

A relational DB would require separate tables for embeddings (128 columns or a serialised BLOB), which is awkward to query and update.

---

**Q60. What are the three MongoDB collections and what does each store?**

**A:**
1. **`lost_persons`:** One document per missing person. Stores name, age, location, original image (base64), age-progressed images (dict), face embedding (array[128]), case ID, created_at
2. **`alerts`:** One document per scan event that produced a match above threshold. Stores scanned image, matched person ID, similarity score, confidence level, GPS coordinates, status (pending/accepted/rejected), timestamp
3. **`police_users`:** One document per registered officer. Stores username, bcrypt-hashed password, role, created_at

---

**Q61. What is BSON?**

**A:** BSON (Binary JSON) is MongoDB's internal storage format. It extends JSON with:
- Binary data type (for file storage)
- `ObjectId` — a 12-byte unique identifier (used as `_id`)
- DateTime type
- 64-bit integers
- Decimal128

PyMongo automatically converts between Python dicts and BSON. The `ObjectId` is why we have a `serialize_doc()` helper — `ObjectId` is not JSON-serialisable, so we convert it to a string before returning it in API responses.

---

**Q62. What is an ObjectId in MongoDB?**

**A:** `ObjectId` is MongoDB's default document ID type. It's a 12-byte value containing:
- 4 bytes: Unix timestamp of creation (seconds)
- 5 bytes: Random value (machine + process unique)
- 3 bytes: Incrementing counter

This design means:
- ObjectIds are globally unique without a central coordination service
- They are roughly sortable by creation time
- Knowing an ObjectId reveals the approximate creation timestamp

---

**Q63. How do you prevent storing duplicate lost person records?**

**A:** In the current prototype, this is handled at the application level — the officer manually ensures they don't register the same person twice (case ID is unique). For production, we would:
1. Add a unique index on `case_id`: `db.lost_persons.create_index("case_id", unique=True)`
2. Before insertion, check for near-duplicate embeddings (similarity > 95% with an existing record)
3. Return a warning if a potential duplicate is detected

---

**Q64. What is the `$set` operator in MongoDB?**

**A:** `$set` is a MongoDB update operator that modifies specific fields in a document without replacing the entire document:
```python
db.alerts.update_one(
    {"_id": ObjectId(alert_id)},
    {"$set": {"status": "accepted", "reviewed_at": now_utc()}}
)
```
Without `$set`, `update_one` with a plain dict would replace the entire document with just `{"status": "accepted"}`, losing all other fields. `$set` is the safe, surgical update operator.

---

**Q65. How does the `get_all_embeddings()` function avoid memory issues?**

**A:** We use MongoDB's projection feature:
```python
projection = {
    "_id": 1,
    "face_embedding": 1,
    "name": 1,
    ...
    # original_image NOT included
}
db.lost_persons.find({}, projection)
```
The `original_image` field can be 1–5 MB (base64 of a full-resolution photo). If we have 1,000 records, loading all original images for matching would use 1–5 GB of RAM unnecessarily. The projection fetches only the lightweight metadata and embedding array, keeping memory usage under 10 MB for 1,000 records.

---

**Q66. What is MongoDB Atlas and how does it differ from a local MongoDB installation?**

**A:**
- **Local MongoDB:** Runs on your own machine. Free, full control, but requires maintenance, backups, and is not accessible from the internet without extra setup
- **MongoDB Atlas:** Fully managed cloud service. Handles backups, security patches, monitoring, and scaling automatically. The free M0 tier provides:
  - 512 MB storage
  - Shared CPU/RAM
  - Automatic daily backups
  - Built-in monitoring dashboard

For a project that needs to be accessed from multiple devices (mobile app + dashboard), Atlas is the natural choice.

---

**Q67. What indexes would you add to improve query performance?**

**A:**
```js
// Fast alert lookups by status (dashboard filtering)
db.alerts.createIndex({ "status": 1 })

// Sort alerts by newest first
db.alerts.createIndex({ "timestamp": -1 })

// Unique case ID lookup
db.lost_persons.createIndex({ "case_id": 1 }, { unique: true })

// Username lookup for login
db.police_users.createIndex({ "username": 1 }, { unique: true })

// Compound index for alerts by person
db.alerts.createIndex({ "matched_person_id": 1, "timestamp": -1 })
```

Without indexes, every query does a full collection scan — O(n). Indexes make lookups O(log n) using B-tree structures.

---

## Category 7: Security & Authentication

**Q68. What is JWT and how does it work?**

**A:** JWT (JSON Web Token) is a compact, self-contained token for transmitting claims (user identity) between parties. Structure: three Base64URL-encoded parts separated by dots:
1. **Header:** `{"alg": "HS256", "typ": "JWT"}`
2. **Payload:** `{"sub": "officer1", "role": "officer", "exp": 1234567890}`
3. **Signature:** `HMACSHA256(base64(header) + "." + base64(payload), secret)`

When an officer logs in:
1. Server validates credentials
2. Server creates a JWT signed with `JWT_SECRET`
3. Client stores the token in `localStorage`
4. Every subsequent request includes `Authorization: Bearer <token>`
5. Server verifies the signature using `JWT_SECRET` — no database lookup needed

JWTs are **stateless** — the server doesn't store sessions.

---

**Q69. What is bcrypt and why use it for password hashing?**

**A:** bcrypt is an adaptive password hashing algorithm designed to be intentionally slow. It uses:
- A randomly generated **salt** (prevents rainbow table attacks)
- A **cost factor** (number of rounds) that can be increased as hardware gets faster

Why not MD5 or SHA-256?
- MD5/SHA are designed to be fast — a modern GPU can compute billions of MD5 hashes/second
- bcrypt with cost=12 takes ~250ms per hash — brute force attacks are impractical
- The salt means the same password hashes differently each time — two users with "password123" have different hashes

---

**Q70. What is the difference between authentication and authorisation?**

**A:**
- **Authentication:** Verifying who you are. "Is this officer1 with the correct password?" — handled by `POST /api/auth/login`
- **Authorisation:** Verifying what you're allowed to do. "Is this token valid? Can this role access this resource?" — handled by `Depends(require_auth)`

In the current system, all authenticated officers have the same permissions. A production system would add role-based access control (RBAC) — e.g., "officer" can view alerts, "admin" can add persons, "super-admin" can manage users.

---

**Q71. Why do you store the JWT in localStorage? What are the security implications?**

**A:** `localStorage` is used for simplicity in the prototype. Security implications:
- **XSS vulnerability:** If the React app has a cross-site scripting vulnerability, malicious JavaScript can read `localStorage` and steal the token
- **Better alternative for production:** Use `httpOnly` cookies — inaccessible to JavaScript, preventing XSS token theft

For a police dashboard handling sensitive data, production should use:
1. `httpOnly` secure cookies
2. CSRF tokens
3. Short expiry (1 hour instead of 8)
4. Token refresh mechanism

---

**Q72. How would you implement role-based access control (RBAC)?**

**A:** The JWT payload already includes `"role"`. To enforce permissions:
```python
def require_role(required_role: str):
    def check(auth: dict = Depends(require_auth)):
        if auth.get("role") != required_role:
            raise HTTPException(status_code=403, detail="Insufficient permissions.")
        return auth
    return check

@router.post("/persons")
def add_person(_auth = Depends(require_role("admin"))):
    ...  # only admins can add persons
```

The `require_role` factory creates a new dependency for each required role.

---

**Q73. How are images secured in this system?**

**A:**
1. **Storage:** Images are stored as base64 strings inside MongoDB documents, not on the public internet
2. **Access:** All person and alert endpoints require JWT authentication
3. **Static files:** The `/uploads/` directory is served without authentication in the prototype (for simplicity), but in production should require a signed URL or token-based access
4. **Transmission:** HTTPS (TLS) encrypts images in transit between app → server → dashboard
5. **No public search:** The scan endpoint returns only similarity score and basic info to the public; actual images are only shown on the authenticated police dashboard

---

**Q74. What is HTTPS and why is it necessary?**

**A:** HTTPS (HTTP over TLS/SSL) encrypts all data transmitted between client and server using asymmetric + symmetric cryptography:
1. **TLS Handshake:** Server sends its certificate; client verifies it against trusted CAs
2. **Key Exchange:** Asymmetric encryption (RSA/ECDH) establishes a shared symmetric key
3. **Data Transfer:** All subsequent data is encrypted with the symmetric key (AES-256-GCM)

Without HTTPS in this system:
- Scanned face images could be intercepted in transit (MITM attack)
- JWT tokens could be stolen from network traffic
- GPS locations could be exposed

Production deployment must use HTTPS. Certbot + Let's Encrypt provides free SSL certificates.

---

**Q75. What SQL injection equivalent exists in MongoDB and how do you prevent it?**

**A:** The MongoDB equivalent is **NoSQL injection**, where an attacker injects MongoDB operators into query parameters. Example attack:
```
POST /login
{"username": {"$gt": ""}, "password": {"$gt": ""}}
```
This matches all users where username > "" (all users).

**Prevention in our code:**
- FastAPI + Pydantic validates the `username` field type as `str` — MongoDB operators like `{"$gt": ""}` are not valid strings and are rejected before reaching the database
- PyMongo uses parameterised queries internally
- For extra safety, validate that usernames only contain alphanumeric characters

---

## Category 8: Flutter Mobile App

**Q76. What is Flutter and why was it chosen?**

**A:** Flutter is Google's open-source UI toolkit for building natively compiled applications for mobile (Android, iOS), web, and desktop from a single codebase using the Dart programming language.

Reasons for choosing Flutter:
1. **Single codebase:** One app for both Android and iOS
2. **Native performance:** Compiles to native ARM code, not a web view
3. **Rich camera and GPS plugins:** `camera`, `geolocator`, `image_picker` are mature and well-maintained
4. **`http` package:** Straightforward multipart file upload
5. **Hot reload:** Very fast development iteration

---

**Q77. What is Dart and how does it differ from Java/Kotlin?**

**A:** Dart is a statically typed, object-oriented language developed by Google. Key differences from Java/Kotlin:
- **Null safety:** Dart has sound null safety (variables are non-nullable by default), similar to Kotlin
- **Async/await:** Native support for async programming with `Future<T>` and `Stream<T>`
- **Single-threaded with Isolates:** Dart is single-threaded but uses Isolates (separate memory heaps) for true parallelism
- **Compiled to ARM:** Dart compiles to native machine code for mobile, unlike Java (JVM bytecode)

---

**Q78. How does the image upload work in Flutter?**

**A:**
```dart
final request = http.MultipartRequest('POST', uri)
  ..fields['latitude'] = latitude.toString()
  ..fields['longitude'] = longitude.toString()
  ..files.add(
    await http.MultipartFile.fromPath('image', imageFile.path),
  );
final streamedResponse = await request.send().timeout(Duration(seconds: 60));
```
`MultipartRequest` creates a `multipart/form-data` request. `MultipartFile.fromPath` reads the image file asynchronously and streams it to the server. The `timeout` prevents the app from hanging indefinitely if the server is slow.

---

**Q79. How does GPS work in the Flutter app?**

**A:** We use the `geolocator` package:
```dart
// Request permission
permission = await Geolocator.requestPermission();

// Get coordinates
final position = await Geolocator.getCurrentPosition(
    desiredAccuracy: LocationAccuracy.high
);
```
`LocationAccuracy.high` uses GPS hardware for maximum accuracy (±5-10m), at the cost of more battery usage. `LocationAccuracy.low` uses network/cell tower triangulation (±500m) but is faster and uses less battery.

The `accuracy` field in the returned `Position` object tells us the radius (in metres) within which the actual location lies.

---

**Q80. What is the `image_picker` vs `camera` package difference?**

**A:**
- **`image_picker`:** High-level plugin that opens the OS native image picker UI (gallery or camera). User sees the standard Android/iOS camera app. Simplest to use, least control
- **`camera`:** Low-level plugin providing direct access to camera streams. Allows custom UI, live preview, manual focus/exposure, filters. More complex to implement

We use `image_picker` because:
- Simpler code (few lines vs many)
- Leverages the OS's optimised camera stack
- Automatically handles permissions UI
- Produces equivalent output (JPEG file) for our needs

---

**Q81. How does the Settings screen persist the API URL?**

**A:** We use `SharedPreferences`:
```dart
final prefs = await SharedPreferences.getInstance();
await prefs.setString('api_base_url', url);
```
`SharedPreferences` stores key-value pairs persistently (survives app restarts) using:
- Android: XML files in `data/data/<package>/shared_prefs/`
- iOS: NSUserDefaults

This allows users to configure the backend URL without recompiling the app — essential for testing on different devices and networks.

---

**Q82. What is a Future in Dart?**

**A:** `Future<T>` represents a value that will be available asynchronously (similar to JavaScript's `Promise<T>`). It can be in three states:
- **Uncompleted:** Waiting for the async operation
- **Completed with a value:** The operation succeeded
- **Completed with an error:** The operation failed

We use `async/await` to write asynchronous code that looks synchronous:
```dart
Future<void> _startScan() async {
    final position = await LocationService.getCurrentPosition();
    final result = await ApiService.scanFace(...);
}
```
The `await` keyword suspends execution of the current function without blocking the UI thread (Flutter uses an event loop).

---

**Q83. How does Flutter handle navigation between screens?**

**A:** Flutter uses a navigation stack (similar to a web browser's history):
```dart
// Push a new screen onto the stack
Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => ResultScreen(result: result)),
);

// Pop back to previous screen
Navigator.pop(context);

// Pop all the way back to the first screen
Navigator.popUntil(context, (route) => route.isFirst);
```
`MaterialPageRoute` wraps the screen widget and provides the standard Material Design transition animation. The `BuildContext` gives the Navigator access to the widget tree.

---

## Category 9: React Police Dashboard

**Q84. What is the component architecture of the dashboard?**

**A:**
```
App (Router)
├── /login         → Login page
├── /              → Dashboard page
│   └── AlertCard (repeated per alert)
├── /alerts/:id    → AlertDetail page
│   ├── MapView    → Leaflet map
│   └── PersonPhoto → Loads from API
└── /add-person    → AddPerson page

Shared: Navbar (used in Dashboard, AlertDetail, AddPerson)
```

---

**Q85. What is React Router and how does it work?**

**A:** React Router provides client-side routing for single-page applications. Routes are defined declaratively:
```jsx
<Routes>
  <Route path="/login" element={<Login />} />
  <Route path="/" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
  <Route path="/alerts/:id" element={<PrivateRoute><AlertDetail /></PrivateRoute>} />
</Routes>
```
When the URL changes, React Router re-renders the matching component without a full page reload. `useParams()` extracts URL parameters like `:id`. The `PrivateRoute` wrapper checks for a JWT token and redirects to login if none is found.

---

**Q86. What is Axios and how does it differ from fetch?**

**A:** Axios is an HTTP client library. Advantages over native `fetch`:
- Automatically parses JSON responses
- Automatic error handling for HTTP errors (fetch doesn't throw on 4xx/5xx)
- Interceptors for global request/response modification (we use this for JWT headers)
- Request/response transformation
- Better error messages with `err.response.data.detail`

Our Axios instance (`src/api.js`) uses interceptors to:
1. Automatically attach `Authorization: Bearer <token>` to every request
2. Redirect to `/login` on 401 responses globally

---

**Q87. How does the auto-refresh polling work in the Dashboard?**

**A:**
```jsx
useEffect(() => {
    loadAlerts()                              // initial load
    const interval = setInterval(loadAlerts, 30000)  // poll every 30s
    return () => clearInterval(interval)      // cleanup on unmount
}, [loadAlerts])
```
`setInterval` calls `loadAlerts` every 30 seconds. The `return () => clearInterval(interval)` cleanup function runs when the component unmounts, preventing memory leaks. `useCallback` on `loadAlerts` prevents the function reference from changing on every render (which would restart the interval).

---

**Q88. How does React-Leaflet display the map and GPS pin?**

**A:**
```jsx
<MapContainer center={[lat, lng]} zoom={14}>
    <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
    />
    <Marker position={[lat, lng]}>
        <Popup>Alert location</Popup>
    </Marker>
</MapContainer>
```
React-Leaflet is a React wrapper around the Leaflet.js library. It uses **OpenStreetMap tiles** (free, no API key) served from OpenStreetMap's CDN. The `{s}` is a subdomain placeholder (a/b/c) for load balancing tile requests.

---

**Q89. How does Tailwind CSS work differently from traditional CSS?**

**A:** Tailwind is a utility-first CSS framework. Instead of writing class names and then CSS:
```css
/* Traditional CSS */
.card { background: #1B2A3B; border-radius: 12px; padding: 20px; }
```
You apply utility classes directly in HTML/JSX:
```jsx
// Tailwind
<div className="bg-navy-800 rounded-xl p-5">
```

Benefits:
- No context switching between files
- Unused CSS is automatically removed in production build (PurgeCSS)
- Consistent design system (spacing, colours, typography)
- Faster prototyping

---

**Q90. Why is `@tailwindcss/forms` plugin used?**

**A:** Browser default form element styles (inputs, selects, checkboxes) are inconsistent across browsers and don't respect Tailwind utility classes well. The `@tailwindcss/forms` plugin applies sensible reset styles to form elements, making them fully styleable with utilities like `border-gray-600`, `focus:border-blue-500`, `bg-navy-700`. Without it, input borders and focus rings appear as browser defaults.

---

## Category 10: System Design & Architecture

**Q91. What design pattern does the backend follow?**

**A:** The backend follows a **layered architecture**:
1. **Route layer** (`api/routes_*.py`) — HTTP request/response handling
2. **Service layer** (face_detection, face_recognition, age_progression) — Business logic and AI processing
3. **Data layer** (`database/mongo.py`) — All database interactions

Each layer only knows about the layer below it. Routes call services and the database; services don't know about HTTP or MongoDB. This separation makes:
- Unit testing easier (mock the database, test the service)
- Code replaceable (swap MongoDB for PostgreSQL without touching routes)
- Debugging simpler (isolate issues to a specific layer)

---

**Q92. How would you add video stream analysis for CCTV integration?**

**A:** For real-time video analysis:
1. Add a WebSocket endpoint to the FastAPI backend
2. The CCTV client sends frames over WebSocket at 5-10 FPS
3. Each frame goes through MTCNN detection
4. Only frames with high-confidence face detections trigger embedding generation (reducing compute)
5. Use a sliding window to avoid duplicate alerts for the same person
6. **OpenCV `VideoCapture`** can be used for local RTSP streams

```python
@app.websocket("/ws/cctv/{camera_id}")
async def cctv_stream(websocket: WebSocket, camera_id: str):
    await websocket.accept()
    while True:
        frame_bytes = await websocket.receive_bytes()
        img = bytes_to_array(frame_bytes)
        faces = detect_all_faces(img)
        for face in faces:
            # match and alert if needed
```

---

**Q93. What is vector database and when would you use one for this project?**

**A:** A vector database (e.g., **Pinecone**, **Weaviate**, **Qdrant**, **Chroma**) stores high-dimensional vectors and supports fast approximate nearest-neighbour (ANN) search. It would replace the current linear scan in `match_embedding()`.

When to switch:
- **< 10,000 records:** Current MongoDB linear scan is fine (< 100ms)
- **10,000–1M records:** Use **FAISS** as an in-memory index alongside MongoDB
- **> 1M records:** Use a dedicated vector database with distributed storage

Benefits of dedicated vector databases: millisecond search at billion-vector scale, built-in filtering (search only females aged 20-30), horizontal scaling.

---

**Q94. What is the CAP theorem and how does it apply to MongoDB?**

**A:** The CAP theorem states that a distributed system can guarantee only two of:
- **Consistency:** All reads see the most recent write
- **Availability:** Every request receives a response (not necessarily the most recent data)
- **Partition tolerance:** The system works despite network partitions

MongoDB prioritises **Consistency + Partition tolerance** (CP):
- With write concern `w: majority`, a write is only confirmed once a majority of replica set members have acknowledged it
- During a network partition, MongoDB may reject reads/writes from the minority partition
- For our use case (police database), consistency is more important than availability — we'd rather have no response than a stale one

---

**Q95. How would you implement real-time notifications on the police dashboard instead of polling?**

**A:** Replace the 30-second polling with WebSockets:

**Backend (FastAPI):**
```python
from fastapi import WebSocket
connected_clients = []

@app.websocket("/ws/alerts")
async def alert_ws(ws: WebSocket):
    await ws.accept()
    connected_clients.append(ws)
    try:
        while True:
            await ws.receive_text()  # keep alive
    finally:
        connected_clients.remove(ws)

# In routes_scan.py, after insert_alert():
for client in connected_clients:
    await client.send_json({"type": "new_alert", "alert_id": alert_id})
```

**Dashboard (React):**
```js
const ws = new WebSocket('ws://localhost:8000/ws/alerts')
ws.onmessage = () => loadAlerts()  // refresh on new alert notification
```

This gives instant notifications instead of 30-second delays.

---

**Q96. What is the difference between SQL and NoSQL databases?**

**A:**
| Feature | SQL (MySQL/PostgreSQL) | NoSQL (MongoDB) |
|---|---|---|
| Schema | Fixed (ALTER TABLE) | Flexible (schema-less) |
| Data model | Tables (rows/columns) | Documents (JSON), key-value, graph, column |
| Relationships | Foreign keys, JOINs | Embedded documents or application-level joins |
| Transactions | ACID (full) | ACID (single document; multi-doc with transactions) |
| Scaling | Vertical (bigger machine) | Horizontal (add more nodes) |
| Query language | SQL | MongoDB Query Language (JSON-like) |
| Best for | Structured, relational data | Semi-structured, hierarchical data |

For this project, MongoDB's flexible document model (embedding arrays, nested GPS objects, base64 image fields) fits naturally.

---

**Q97. What design decisions would you change if starting over?**

**A:**
1. **Image storage:** Use AWS S3/Cloudinary from day one instead of base64 in MongoDB. Base64 bloats document size by 33%
2. **Async database:** Use **Motor** (async MongoDB driver) instead of PyMongo to properly leverage FastAPI's async capabilities
3. **Background tasks:** Use FastAPI's `BackgroundTasks` for age progression (slow operation) — return a response immediately and process in background
4. **FAISS indexing:** Build a FAISS index in memory at startup for fast embedding search
5. **Proper auth cookies:** `httpOnly` cookies instead of localStorage for the dashboard
6. **Flutter state management:** Use **Riverpod** or **Bloc** for proper state management instead of `setState`

---

**Q98. How would you test this system?**

**A:**
- **Unit tests (pytest):** Test each module in isolation
  ```python
  def test_cosine_similarity():
      assert cosine_similarity([1,0,0], [1,0,0]) == 1.0
      assert cosine_similarity([1,0,0], [-1,0,0]) == -1.0
  ```
- **Integration tests:** Test API routes with a test MongoDB instance using `pytest` + `httpx.AsyncClient`
- **Face recognition tests:** Compare embeddings of the same person's photos and verify similarity > 0.80
- **Load tests:** Use `locust` to simulate 100 concurrent scan requests
- **End-to-end tests:** Use `Cypress` for the React dashboard or `Flutter Integration Test`

---

**Q99. What would you add to make this a production-ready system?**

**A:**
1. **Audit logging:** Every database access, alert action, and login is logged with timestamp and officer ID
2. **Two-factor authentication (2FA):** TOTP (Google Authenticator) for officer login
3. **Data encryption at rest:** Encrypt sensitive fields (original_image, face_embedding) using MongoDB Field Level Encryption
4. **Regular model updates:** Retrain or fine-tune FaceNet on Indian face datasets for better accuracy on Indian demographics
5. **Offline mode:** Queue scans locally when offline and sync when connectivity returns
6. **Multi-language support:** Hindi and other regional languages in the Flutter app
7. **Case management:** Full case lifecycle — from open to found to closed — with document uploads
8. **Analytics dashboard:** Monthly reports, match rates by region, average resolution time

---

**Q100. What is the social impact of this project?**

**A:** In India alone, approximately 1 lakh (100,000) persons are reported missing every year, with a significant portion being children. Traditional identification methods are:
- Manual — requiring physical photo matching by officers
- Slow — reports may take days to reach relevant officers
- Geographically limited — a person spotted in Mumbai may not be matched to a record from Delhi

This system addresses all three problems:
- **Automated AI matching** — reduces officer workload and human error
- **Real-time alerting** — GPS-tagged alerts reach the dashboard in seconds
- **Centralised database** — a national missing persons database accessible from anywhere

Beyond the technology, the project demonstrates how accessible AI tools (pretrained models, free cloud services, cross-platform mobile development) can be combined to create socially impactful systems at minimal cost. The entire prototype runs on free-tier services (MongoDB Atlas M0, Render, Vercel).

---

*End of Interview Questions*

> **Tip for viva:** Be ready to explain any piece of code from the project. Interviewers often ask "show me this file" and then ask about specific lines. Know the project end-to-end.
