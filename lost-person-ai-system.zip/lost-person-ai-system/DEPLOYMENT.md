# Deployment Guide

> **AI-Based Lost & Found Person Identification System**
> How to deploy the system for real-world / production use.

---

## Table of Contents

1. [Deployment Overview](#1-deployment-overview)
2. [Option A — Docker Compose (Recommended for VPS)](#2-option-a--docker-compose-recommended-for-vps)
3. [Option B — Deploy Backend on Render (Free)](#3-option-b--deploy-backend-on-render-free)
4. [Option C — Deploy Backend on Railway](#4-option-c--deploy-backend-on-railway)
5. [Option D — Deploy Backend on AWS EC2](#5-option-d--deploy-backend-on-aws-ec2)
6. [Deploy Police Dashboard on Vercel](#6-deploy-police-dashboard-on-vercel)
7. [Deploy Police Dashboard on Netlify](#7-deploy-police-dashboard-on-netlify)
8. [Publish Flutter App (Android APK)](#8-publish-flutter-app-android-apk)
9. [MongoDB Atlas Production Setup](#9-mongodb-atlas-production-setup)
10. [Production Security Checklist](#10-production-security-checklist)
11. [Environment Variables for Production](#11-environment-variables-for-production)

---

## 1. Deployment Overview

```
┌─────────────────────────────────────────────────────────┐
│                   Production Architecture                │
│                                                          │
│  Flutter App  ──►  FastAPI Backend  ──►  MongoDB Atlas   │
│  (Android APK)     (Render / EC2 /       (Free Tier)     │
│                     Railway)                             │
│                         │                               │
│                         ▼                               │
│              React Dashboard (Vercel / Netlify)          │
└─────────────────────────────────────────────────────────┘
```

### Recommended Free-Tier Stack

| Component | Service | Cost |
|---|---|---|
| Backend | Render (Web Service) | Free |
| Database | MongoDB Atlas M0 | Free |
| Dashboard | Vercel | Free |
| Mobile App | Direct APK install | Free |

---

## 2. Option A — Docker Compose (Recommended for VPS)

Use this if you have a VPS (DigitalOcean, Linode, Hetzner, etc.).

### Step 1 — Create `Dockerfile` for the backend

Create `backend_fastapi/Dockerfile`:
```dockerfile
FROM python:3.11-slim

WORKDIR /app

# System deps for OpenCV
RUN apt-get update && apt-get install -y \
    libglib2.0-0 libsm6 libxrender1 libxext6 libgl1 \
    && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN mkdir -p uploads

EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Step 2 — Create `Dockerfile` for the React dashboard

Create `police_dashboard/Dockerfile`:
```dockerfile
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm install

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

Create `police_dashboard/nginx.conf`:
```nginx
server {
    listen 80;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://backend:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### Step 3 — Create `docker-compose.yml` in the project root

```yaml
version: '3.8'

services:
  backend:
    build: ./backend_fastapi
    ports:
      - "8000:8000"
    environment:
      - MONGODB_URI=${MONGODB_URI}
      - JWT_SECRET=${JWT_SECRET}
      - JWT_ALGORITHM=HS256
      - JWT_EXPIRE_MINUTES=480
      - HUGGINGFACE_API_TOKEN=${HUGGINGFACE_API_TOKEN}
      - UPLOAD_DIR=uploads
    volumes:
      - uploads_data:/app/uploads
    restart: unless-stopped

  dashboard:
    build: ./police_dashboard
    ports:
      - "80:80"
    depends_on:
      - backend
    restart: unless-stopped

volumes:
  uploads_data:
```

### Step 4 — Create `.env` in the project root

```
MONGODB_URI=mongodb+srv://...
JWT_SECRET=your_production_secret_key_minimum_32_chars
HUGGINGFACE_API_TOKEN=hf_your_token
```

### Step 5 — Deploy on your VPS

```bash
# SSH into your VPS
ssh user@your-vps-ip

# Clone the project
git clone <your-repo-url>
cd lost-person-ai-system

# Create the .env file
nano .env
# Paste your production environment variables

# Build and start all services
docker compose up -d --build

# Check status
docker compose ps

# View logs
docker compose logs -f backend
```

### Step 6 — Set up a domain and HTTPS (optional but recommended)

```bash
# Install Nginx and Certbot on your VPS
sudo apt install nginx certbot python3-certbot-nginx -y

# Get a free SSL certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com

# Certbot auto-renews certificates
```

---

## 3. Option B — Deploy Backend on Render (Free)

Render offers a free tier for web services.

### Step 1 — Push your code to GitHub

```bash
cd backend_fastapi
git init
git add .
git commit -m "Initial backend"
# Create a new repo on GitHub and push
git remote add origin https://github.com/yourname/lostfound-backend
git push -u origin main
```

### Step 2 — Create a Web Service on Render

1. Go to [https://render.com](https://render.com) and sign up
2. Click **New** → **Web Service**
3. Connect your GitHub repo
4. Configure:
   - **Name:** `lostfound-backend`
   - **Environment:** `Python 3`
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
5. Click **Advanced** → Add environment variables:
   - `MONGODB_URI` → your Atlas URI
   - `JWT_SECRET` → your secret key
   - `HUGGINGFACE_API_TOKEN` → your HF token
6. Click **Create Web Service**

> **Free tier note:** Render free services spin down after 15 minutes of inactivity. First request after idle takes ~30 seconds.

### Step 3 — Note your backend URL

Render gives you a URL like `https://lostfound-backend.onrender.com`.
Use this as the API base URL in your Flutter app and React dashboard.

---

## 4. Option C — Deploy Backend on Railway

Railway provides $5/month free credits.

### Steps

1. Install Railway CLI:
   ```bash
   npm install -g @railway/cli
   railway login
   ```

2. Initialize and deploy:
   ```bash
   cd backend_fastapi
   railway init
   railway up
   ```

3. Set environment variables:
   ```bash
   railway variables set MONGODB_URI="mongodb+srv://..."
   railway variables set JWT_SECRET="your_secret"
   railway variables set HUGGINGFACE_API_TOKEN="hf_..."
   ```

4. Get your deployed URL:
   ```bash
   railway open
   ```

---

## 5. Option D — Deploy Backend on AWS EC2

For production-grade deployment.

### Step 1 — Launch an EC2 instance

1. Go to AWS Console → EC2 → **Launch Instance**
2. Choose: **Ubuntu Server 22.04 LTS**
3. Instance type: **t2.small** (minimum for TensorFlow)
4. Configure security group — open inbound ports:
   - 22 (SSH)
   - 80 (HTTP)
   - 443 (HTTPS)
   - 8000 (API, can remove after Nginx setup)
5. Create or select a key pair
6. Launch

### Step 2 — Connect and set up the server

```bash
# Connect via SSH
ssh -i your-key.pem ubuntu@your-ec2-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install Python 3.11
sudo apt install python3.11 python3.11-venv python3-pip -y

# Install Nginx
sudo apt install nginx -y

# Clone the project
git clone <your-repo-url>
cd lost-person-ai-system/backend_fastapi

# Create venv and install
python3.11 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Create .env
nano .env
# Add your environment variables

# Test the server
uvicorn main:app --host 0.0.0.0 --port 8000
```

### Step 3 — Set up systemd service (auto-start on reboot)

```bash
sudo nano /etc/systemd/system/lostfound.service
```

Paste:
```ini
[Unit]
Description=Lost Found FastAPI Backend
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/lost-person-ai-system/backend_fastapi
Environment="PATH=/home/ubuntu/lost-person-ai-system/backend_fastapi/venv/bin"
ExecStart=/home/ubuntu/lost-person-ai-system/backend_fastapi/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable lostfound
sudo systemctl start lostfound
sudo systemctl status lostfound
```

### Step 4 — Configure Nginx as reverse proxy

```bash
sudo nano /etc/nginx/sites-available/lostfound
```

Paste:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    client_max_body_size 20M;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/lostfound /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 6. Deploy Police Dashboard on Vercel

Vercel is free and perfect for React/Vite apps.

### Step 1 — Update the API base URL

In `police_dashboard/src/api.js`, change the baseURL to your deployed backend:
```js
const api = axios.create({
  baseURL: 'https://your-backend.onrender.com/api',
  timeout: 30000,
})
```

Also update `vite.config.js` — remove the proxy section (not needed in production).

### Step 2 — Deploy to Vercel

```bash
# Install Vercel CLI
npm install -g vercel

cd police_dashboard
vercel

# Follow the prompts:
# - Set up and deploy? Yes
# - Which scope? Your account
# - Link to existing project? No
# - Project name: police-dashboard
# - Directory: ./
# - Override settings? No
```

Your dashboard will be live at `https://police-dashboard-xxx.vercel.app`.

### Or deploy via GitHub (easier)

1. Push `police_dashboard/` to a GitHub repo
2. Go to [https://vercel.com](https://vercel.com) → New Project
3. Import the GitHub repo
4. Framework preset: **Vite**
5. Root directory: `./` (if it's the whole repo, set to `police_dashboard`)
6. Click **Deploy**

---

## 7. Deploy Police Dashboard on Netlify

Alternative to Vercel.

```bash
# Install Netlify CLI
npm install -g netlify-cli

cd police_dashboard
npm run build

# Deploy
netlify deploy --prod --dir=dist
```

Or connect via GitHub at [https://app.netlify.com](https://app.netlify.com).

---

## 8. Publish Flutter App (Android APK)

### Build a signed release APK

```bash
cd mobile_app_flutter

# Generate a keystore (only once)
keytool -genkey -v -keystore lost-found-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias lost-found-key

# Build release APK
flutter build apk --release

# APK is at:
# build/app/outputs/flutter-apk/app-release.apk
```

### Distribute the APK

Option 1 — **Direct share:** Send the APK file via WhatsApp/email to testers.

Option 2 — **Firebase App Distribution** (free):
```bash
npm install -g firebase-tools
firebase login
firebase appdistribution:distribute build/app/outputs/flutter-apk/app-release.apk \
  --app YOUR_FIREBASE_APP_ID \
  --groups "testers"
```

Option 3 — **Google Play Store:** Upload to the Play Console for public distribution (requires $25 one-time developer fee).

---

## 9. MongoDB Atlas Production Setup

For production, harden your MongoDB Atlas configuration.

### Use a dedicated cluster (optional)

For production, consider upgrading from M0 (free) to M10 ($0.08/hr) for:
- Dedicated resources
- Automated backups
- Better performance

### Create production indexes

Run these in MongoDB Atlas → Collections → Aggregation:
```js
// Index for fast embedding lookups (not needed for cosine search, but useful for other queries)
db.lost_persons.createIndex({ "case_id": 1 }, { unique: true })
db.lost_persons.createIndex({ "created_at": -1 })
db.alerts.createIndex({ "timestamp": -1 })
db.alerts.createIndex({ "status": 1 })
db.police_users.createIndex({ "username": 1 }, { unique: true })
```

### Enable Atlas Search (for text search)

1. Atlas → Search → Create Search Index
2. Select `lost_found_db.lost_persons`
3. Default configuration
4. This enables fuzzy name search across person records

---

## 10. Production Security Checklist

Before going live, verify all of the following:

- [ ] `JWT_SECRET` is at least 32 characters, randomly generated, not shared
- [ ] MongoDB Atlas IP whitelist is restricted to your server's IP only
- [ ] HTTPS is enabled (SSL certificate via Certbot or cloud provider)
- [ ] CORS `allow_origins` in `main.py` is set to your dashboard domain only (not `"*"`)
- [ ] `.env` file is in `.gitignore` and never committed to Git
- [ ] `POST /api/auth/register` is removed or protected behind an admin check
- [ ] Uploaded images are validated for type (JPEG/PNG only) and size limit
- [ ] Rate limiting is added to `POST /api/scan` (prevent abuse)
- [ ] MongoDB user has read/write only, not admin privileges

### Add CORS restriction in `main.py`:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-dashboard-domain.vercel.app"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH"],
    allow_headers=["Authorization", "Content-Type"],
)
```

### Add rate limiting (install `slowapi`):
```bash
pip install slowapi
```

```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

@router.post("/")
@limiter.limit("10/minute")
async def scan_face(request: Request, ...):
    ...
```

---

## 11. Environment Variables for Production

| Variable | Development | Production |
|---|---|---|
| `MONGODB_URI` | Atlas free M0 | Atlas M0 or dedicated |
| `JWT_SECRET` | Any string | Random 64-char string |
| `JWT_EXPIRE_MINUTES` | 480 (8 hrs) | 60 (1 hr) |
| `HUGGINGFACE_API_TOKEN` | Optional | Recommended |
| `UPLOAD_DIR` | `uploads` | `/var/app/uploads` or S3 |

### Generate a secure JWT secret:
```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

### Use AWS S3 for image storage (production)

Replace base64 MongoDB storage with S3:
```bash
pip install boto3
```

```python
import boto3

s3 = boto3.client(
    's3',
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY'),
    aws_secret_access_key=os.getenv('AWS_SECRET_KEY'),
)

def upload_image_to_s3(image_bytes: bytes, filename: str) -> str:
    s3.put_object(
        Bucket='your-bucket-name',
        Key=f'persons/{filename}',
        Body=image_bytes,
        ContentType='image/jpeg',
    )
    return f"https://your-bucket-name.s3.amazonaws.com/persons/{filename}"
```

---

## Quick Deployment Reference Card

```
LOCAL DEVELOPMENT
─────────────────
Backend:    uvicorn main:app --reload --port 8000
Dashboard:  npm run dev (port 3000)
Flutter:    flutter run

PRODUCTION (Recommended Free Stack)
────────────────────────────────────
Backend:    Render.com (free web service)
Dashboard:  Vercel.com (free)
Database:   MongoDB Atlas M0 (free)
Mobile:     APK distributed via Firebase / direct

PRODUCTION (Self-hosted VPS)
─────────────────────────────
Backend:    Docker Compose + systemd
Dashboard:  Nginx serving React build
Database:   MongoDB Atlas M0 or self-hosted
SSL:        Certbot (free Let's Encrypt)
```
