"""
Face Detection Module — MTCNN-based face detector.

Responsibilities:
  1. Accept an image (numpy array, file path, or raw bytes).
  2. Detect all faces using MTCNN.
  3. Return the largest (most prominent) cropped face as a numpy array.
  4. Raise a descriptive error when no face is found.

Usage:
    from face_detection.detector import detect_face, bytes_to_array

    img_array = bytes_to_array(raw_bytes)
    face_crop  = detect_face(img_array)
"""

import io
from typing import Optional

import cv2
import numpy as np
from mtcnn import MTCNN
from PIL import Image

# Initialise once at import time — MTCNN loads weights here
_detector: Optional[MTCNN] = None


def _get_detector() -> MTCNN:
    global _detector
    if _detector is None:
        _detector = MTCNN()
    return _detector


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def bytes_to_array(data: bytes) -> np.ndarray:
    """Convert raw image bytes (JPEG/PNG) to an RGB numpy array."""
    image = Image.open(io.BytesIO(data)).convert("RGB")
    return np.array(image)


def array_to_bytes(array: np.ndarray, fmt: str = "JPEG") -> bytes:
    """Convert an RGB numpy array back to JPEG/PNG bytes."""
    pil_image = Image.fromarray(array.astype(np.uint8))
    buffer = io.BytesIO()
    pil_image.save(buffer, format=fmt)
    return buffer.getvalue()


def detect_face(
    image: np.ndarray,
    min_confidence: float = 0.90,
    margin: int = 20,
) -> np.ndarray:
    """
    Detect the most prominent face in *image* and return it as a cropped
    RGB numpy array ready for embedding generation.

    Parameters
    ----------
    image          : RGB numpy array (H x W x 3)
    min_confidence : Minimum MTCNN confidence to accept a detection.
    margin         : Extra pixels added around the bounding box before crop.

    Returns
    -------
    Cropped face as an RGB numpy array (160 x 160 for FaceNet compatibility).

    Raises
    ------
    ValueError if no face meets the confidence threshold.
    """
    detector = _get_detector()
    detections = detector.detect_faces(image)

    # Filter by confidence
    valid = [d for d in detections if d["confidence"] >= min_confidence]
    if not valid:
        raise ValueError(
            f"No face detected with confidence >= {min_confidence:.0%}. "
            "Ensure the image is well-lit and the face is clearly visible."
        )

    # Pick the bounding box with the largest area (most prominent face)
    best = max(valid, key=lambda d: d["box"][2] * d["box"][3])

    x, y, w, h = best["box"]
    img_h, img_w = image.shape[:2]

    # Apply margin while staying within image bounds
    x1 = max(0, x - margin)
    y1 = max(0, y - margin)
    x2 = min(img_w, x + w + margin)
    y2 = min(img_h, y + h + margin)

    crop = image[y1:y2, x1:x2]

    # Resize to 160×160 for FaceNet
    face_160 = cv2.resize(crop, (160, 160), interpolation=cv2.INTER_AREA)
    return face_160


def detect_all_faces(
    image: np.ndarray,
    min_confidence: float = 0.90,
    margin: int = 20,
) -> list[dict]:
    """
    Detect all faces in *image* above the confidence threshold.

    Returns a list of dicts, each containing:
      - 'crop'       : 160×160 RGB numpy array
      - 'box'        : [x, y, w, h]
      - 'confidence' : float
      - 'keypoints'  : dict with facial landmark coordinates
    """
    detector = _get_detector()
    detections = detector.detect_faces(image)
    img_h, img_w = image.shape[:2]

    results = []
    for d in detections:
        if d["confidence"] < min_confidence:
            continue
        x, y, w, h = d["box"]
        x1 = max(0, x - margin)
        y1 = max(0, y - margin)
        x2 = min(img_w, x + w + margin)
        y2 = min(img_h, y + h + margin)
        crop = image[y1:y2, x1:x2]
        face_160 = cv2.resize(crop, (160, 160), interpolation=cv2.INTER_AREA)
        results.append(
            {
                "crop": face_160,
                "box": d["box"],
                "confidence": d["confidence"],
                "keypoints": d["keypoints"],
            }
        )
    return results


def draw_detections(image: np.ndarray, detections: list[dict]) -> np.ndarray:
    """
    Draw bounding boxes and keypoints on *image* for debugging.
    Returns a copy of the image with annotations drawn.
    """
    annotated = image.copy()
    for d in detections:
        x, y, w, h = d["box"]
        cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 255, 0), 2)
        conf_text = f"{d['confidence']:.2f}"
        cv2.putText(
            annotated, conf_text, (x, y - 6),
            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1,
        )
        for _, (kx, ky) in d["keypoints"].items():
            cv2.circle(annotated, (kx, ky), 2, (255, 0, 0), -1)
    return annotated
