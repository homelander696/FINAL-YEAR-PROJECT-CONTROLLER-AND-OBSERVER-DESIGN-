"""
Lost & Found Person Identification System — FastAPI entry point.

Start the server:
    uvicorn main:app --reload --host 0.0.0.0 --port 8000

API docs auto-generated at:
    http://localhost:8000/docs   (Swagger UI)
    http://localhost:8000/redoc  (ReDoc)
"""

import os
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

load_dotenv()

from api.routes_auth import router as auth_router
from api.routes_persons import router as persons_router
from api.routes_scan import router as scan_router
from api.routes_alerts import router as alerts_router


# ---------------------------------------------------------------------------
# Lifespan: run startup / shutdown code
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Ensure the uploads directory exists before serving static files
    upload_dir = os.getenv("UPLOAD_DIR", "uploads")
    os.makedirs(upload_dir, exist_ok=True)
    yield


# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------

app = FastAPI(
    title="Lost & Found AI System",
    description="AI-Based Lost & Found Person Identification with Face Recognition and Age Progression",
    version="1.0.0",
    lifespan=lifespan,
)

# Allow the Flutter app and React dashboard to reach the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # Tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve uploaded images as static files (e.g. /uploads/abc.jpg)
upload_dir = os.getenv("UPLOAD_DIR", "uploads")
os.makedirs(upload_dir, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=upload_dir), name="uploads")

# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------

app.include_router(auth_router,    prefix="/api/auth",    tags=["Auth"])
app.include_router(persons_router, prefix="/api/persons", tags=["Lost Persons"])
app.include_router(scan_router,    prefix="/api/scan",    tags=["Scan"])
app.include_router(alerts_router,  prefix="/api/alerts",  tags=["Alerts"])


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------

@app.get("/", tags=["Health"])
def root():
    return {"status": "ok", "message": "Lost & Found AI System is running"}


@app.get("/health", tags=["Health"])
def health():
    return {"status": "healthy"}
