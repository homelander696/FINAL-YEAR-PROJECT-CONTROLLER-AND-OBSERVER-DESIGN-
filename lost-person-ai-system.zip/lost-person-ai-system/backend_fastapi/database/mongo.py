"""
MongoDB client and CRUD helper functions for the lost-person-ai-system.
All database interactions are centralised here so routes stay thin.
"""

import os
from datetime import datetime, timezone
from typing import Optional
from bson import ObjectId
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------

_client: Optional[MongoClient] = None


def get_client() -> MongoClient:
    global _client
    if _client is None:
        uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
        _client = MongoClient(uri)
    return _client


def get_db():
    return get_client()["lost_found_db"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def serialize_doc(doc: dict) -> dict:
    """Convert ObjectId fields to strings so the document is JSON-serialisable."""
    if doc is None:
        return {}
    result = {}
    for key, value in doc.items():
        if isinstance(value, ObjectId):
            result[key] = str(value)
        elif isinstance(value, datetime):
            result[key] = value.isoformat()
        else:
            result[key] = value
    return result


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


# ---------------------------------------------------------------------------
# lost_persons collection
# ---------------------------------------------------------------------------

def insert_lost_person(record: dict) -> str:
    """Insert a new lost person and return the inserted _id as string."""
    db = get_db()
    record["created_at"] = now_utc()
    result = db.lost_persons.insert_one(record)
    return str(result.inserted_id)


def get_all_lost_persons() -> list[dict]:
    db = get_db()
    return [serialize_doc(d) for d in db.lost_persons.find()]


def get_lost_person_by_id(person_id: str) -> Optional[dict]:
    db = get_db()
    doc = db.lost_persons.find_one({"_id": ObjectId(person_id)})
    return serialize_doc(doc) if doc else None


def get_all_embeddings() -> list[dict]:
    """
    Return only the fields needed for matching: _id, face_embedding,
    name, age_at_missing, case_id, original_image.
    Keeps memory usage low when the database grows.
    """
    db = get_db()
    projection = {
        "_id": 1,
        "face_embedding": 1,
        "name": 1,
        "age_at_missing": 1,
        "case_id": 1,
        "original_image": 1,
        "age_progressed_images": 1,
    }
    return [serialize_doc(d) for d in db.lost_persons.find({}, projection)]


def update_age_progressed_images(person_id: str, images: dict) -> None:
    """Attach age-progressed image blobs to an existing lost_persons record."""
    db = get_db()
    db.lost_persons.update_one(
        {"_id": ObjectId(person_id)},
        {"$set": {"age_progressed_images": images}},
    )


# ---------------------------------------------------------------------------
# alerts collection
# ---------------------------------------------------------------------------

def insert_alert(record: dict) -> str:
    db = get_db()
    record["timestamp"] = now_utc()
    record.setdefault("status", "pending")
    result = db.alerts.insert_one(record)
    return str(result.inserted_id)


def get_all_alerts() -> list[dict]:
    db = get_db()
    return [serialize_doc(d) for d in db.alerts.find().sort("timestamp", -1)]


def get_alert_by_id(alert_id: str) -> Optional[dict]:
    db = get_db()
    doc = db.alerts.find_one({"_id": ObjectId(alert_id)})
    return serialize_doc(doc) if doc else None


def update_alert_status(alert_id: str, status: str) -> bool:
    """Set status to 'accepted' or 'rejected'. Returns True on success."""
    db = get_db()
    result = db.alerts.update_one(
        {"_id": ObjectId(alert_id)},
        {"$set": {"status": status, "reviewed_at": now_utc()}},
    )
    return result.modified_count > 0


# ---------------------------------------------------------------------------
# police_users collection
# ---------------------------------------------------------------------------

def get_police_user(username: str) -> Optional[dict]:
    db = get_db()
    doc = db.police_users.find_one({"username": username})
    return serialize_doc(doc) if doc else None


def create_police_user(username: str, hashed_password: str, role: str = "officer") -> str:
    db = get_db()
    record = {
        "username": username,
        "hashed_password": hashed_password,
        "role": role,
        "created_at": now_utc(),
    }
    result = db.police_users.insert_one(record)
    return str(result.inserted_id)
