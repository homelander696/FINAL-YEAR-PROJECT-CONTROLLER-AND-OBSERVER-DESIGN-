"""
Auth routes — POST /api/auth/login and POST /api/auth/register.

POST /api/auth/login
  Body: { "username": "...", "password": "..." }
  Returns: { "access_token": "...", "token_type": "bearer", "role": "..." }

POST /api/auth/register   (admin use only — seed initial officers)
  Body: { "username": "...", "password": "...", "role": "officer" }
  Returns: { "message": "...", "id": "..." }
"""

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from api.auth import create_access_token, hash_password, verify_password
from database.mongo import create_police_user, get_police_user

router = APIRouter()


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------

class LoginRequest(BaseModel):
    username: str
    password: str


class RegisterRequest(BaseModel):
    username: str
    password: str
    role: str = "officer"


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post("/login")
def login(body: LoginRequest):
    """Authenticate a police officer and return a JWT access token."""
    user = get_police_user(body.username)

    if not user or not verify_password(body.password, user["hashed_password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
        )

    token = create_access_token(
        data={"sub": user["username"], "role": user.get("role", "officer")}
    )
    return {"access_token": token, "token_type": "bearer", "role": user.get("role", "officer")}


@router.post("/register", status_code=status.HTTP_201_CREATED)
def register(body: RegisterRequest):
    """
    Register a new police user.
    In production this should be restricted to admins.
    For the prototype it is open so you can seed the database.
    """
    existing = get_police_user(body.username)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Username '{body.username}' already exists.",
        )

    hashed = hash_password(body.password)
    user_id = create_police_user(body.username, hashed, body.role)
    return {"message": "User registered successfully.", "id": user_id}
