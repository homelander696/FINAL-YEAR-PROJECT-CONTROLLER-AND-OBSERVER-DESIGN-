"""
Scan route — the core identification endpoint.

POST /api/scan
  Multipart form:
    - image     : JPEG/PNG image file captured by the mobile app
    - latitude  : float (GPS latitude)
    - longitude : float (GPS longitude)
    - accuracy  : float (GPS accuracy in metres, optional)

  Flow:
    1. Detect & crop face from uploaded image.
    2. Generate FaceNet embedding.
    3. Compare against all stored embeddings (cosine similarity).
    4. If best match >= 75% → create an alert document in MongoDB.
    5. Return match info (or "no match") to the mobile app.

  Response (match found):
    {
      "match_found":      true,
      "alert_id":         "...",
      "matched_person": { ...person details... },
      "similarity_score": 0.83,
      "confidence_level": "strong_match",
      "gps_location":     { "lat": ..., "lng": ... }
    }

  Response (no match):
    { "match_found": false, "message": "No matching person found." }
"""

import base64

from fastapi import APIRouter, File, Form, HTTPException, UploadFile

from database.mongo import get_all_embeddings, insert_alert
from face_detection.detector import bytes_to_array, detect_face, array_to_bytes
from face_recognition.embedder import generate_embedding, match_embedding, THRESHOLD_POSSIBLE

router = APIRouter()


@router.post("/")
async def scan_face(
    image: UploadFile = File(...),
    latitude: float  = Form(...),
    longitude: float = Form(...),
    accuracy: float  = Form(default=0.0),
):
    """
    Identify a scanned face against the lost persons database.
    This endpoint is PUBLIC (no JWT required) so the mobile app can call it
    without an officer account.  Alert creation is still gated by the
    similarity threshold and reviewed by humans on the police dashboard.
    """
    raw_bytes = await image.read()

    # --- 1. Face detection ---
    try:
        img_array = bytes_to_array(raw_bytes)
        face_crop  = detect_face(img_array)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    # --- 2. Embedding generation ---
    try:
        query_embedding = generate_embedding(face_crop)
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Embedding generation failed: {exc}",
        )

    # --- 3. Load all stored embeddings and compare ---
    db_records = get_all_embeddings()
    if not db_records:
        return {"match_found": False, "message": "Database is empty — no persons registered yet."}

    matches = match_embedding(query_embedding, db_records, top_k=3)

    if not matches or matches[0]["similarity_score"] < THRESHOLD_POSSIBLE:
        return {"match_found": False, "message": "No matching person found above confidence threshold."}

    best = matches[0]

    # --- 4. Create alert in MongoDB ---
    scanned_b64 = base64.b64encode(raw_bytes).decode("utf-8")

    alert_record = {
        "scanned_image":       scanned_b64,
        "matched_person_id":   best["_id"],
        "matched_person_name": best["name"],
        "similarity_score":    best["similarity_score"],
        "confidence_level":    best["confidence_level"],
        "gps_location":        {"lat": latitude, "lng": longitude, "accuracy": accuracy},
        "status":              "pending",
    }
    alert_id = insert_alert(alert_record)

    return {
        "match_found":    True,
        "alert_id":       alert_id,
        "matched_person": {
            "id":                   best["_id"],
            "name":                 best["name"],
            "case_id":              best["case_id"],
            "age_at_missing":       best["age_at_missing"],
            "original_image":       best["original_image"],
            "age_progressed_images": best["age_progressed_images"],
        },
        "similarity_score": best["similarity_score"],
        "confidence_level": best["confidence_level"],
        "gps_location":     {"lat": latitude, "lng": longitude},
        "top_matches":      matches,
    }
