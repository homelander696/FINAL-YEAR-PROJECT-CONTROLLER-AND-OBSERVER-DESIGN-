"""
Alert routes — police dashboard interaction.

GET   /api/alerts           — List all alerts (newest first)
GET   /api/alerts/{id}      — Get a single alert by ID
PATCH /api/alerts/{id}      — Accept or reject an alert
"""

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from api.auth import require_auth
from database.mongo import (
    get_all_alerts,
    get_alert_by_id,
    update_alert_status,
)

router = APIRouter()


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------

class AlertStatusUpdate(BaseModel):
    status: str  # "accepted" or "rejected"


# ---------------------------------------------------------------------------
# GET /api/alerts
# ---------------------------------------------------------------------------

@router.get("/")
def list_alerts(_auth: dict = Depends(require_auth)):
    """
    Return all alerts sorted by timestamp descending.
    Used by the police dashboard to populate the alert list.
    """
    alerts = get_all_alerts()
    return {"total": len(alerts), "alerts": alerts}


# ---------------------------------------------------------------------------
# GET /api/alerts/{alert_id}
# ---------------------------------------------------------------------------

@router.get("/{alert_id}")
def get_alert(alert_id: str, _auth: dict = Depends(require_auth)):
    """Return a single alert by its MongoDB _id."""
    alert = get_alert_by_id(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found.")
    return alert


# ---------------------------------------------------------------------------
# PATCH /api/alerts/{alert_id}
# ---------------------------------------------------------------------------

@router.patch("/{alert_id}")
def update_alert(
    alert_id: str,
    body: AlertStatusUpdate,
    _auth: dict = Depends(require_auth),
):
    """
    Accept or reject an alert.
    Allowed status values: 'accepted', 'rejected'.
    """
    allowed = {"accepted", "rejected"}
    if body.status not in allowed:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Status must be one of {allowed}.",
        )

    success = update_alert_status(alert_id, body.status)
    if not success:
        raise HTTPException(status_code=404, detail="Alert not found or already updated.")

    return {"message": f"Alert marked as '{body.status}'.", "alert_id": alert_id}
