"""
Lost Persons routes.

POST /api/persons         — Add a new lost person record (with image upload)
GET  /api/persons         — List all lost persons (protected)
GET  /api/persons/{id}    — Get a single lost person by ID (protected)
"""

import base64
import uuid

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status

from api.auth import require_auth
from database.mongo import (
    get_all_lost_persons,
    get_lost_person_by_id,
    insert_lost_person,
    update_age_progressed_images,
)
from face_detection.detector import bytes_to_array, detect_face, array_to_bytes
from face_recognition.embedder import generate_embedding
from age_progression.age_gan import generate_age_progression, progression_to_base64

router = APIRouter()


# ---------------------------------------------------------------------------
# POST /api/persons
# ---------------------------------------------------------------------------

@router.post("/", status_code=status.HTTP_201_CREATED)
async def add_lost_person(
    name: str = Form(...),
    age_at_missing: int = Form(...),
    last_seen_location: str = Form(...),
    case_id: str = Form(default=""),
    image: UploadFile = File(...),
    _auth: dict = Depends(require_auth),
):
    """
    Register a new lost person.

    Workflow:
    1. Detect and crop face from the uploaded image.
    2. Generate a 128-D FaceNet embedding for future matching.
    3. Generate age-progressed images at +5, +10, +15 years.
    4. Store everything in MongoDB.

    Multipart form fields:
      - name              : Full name of the missing person
      - age_at_missing    : Age when they went missing
      - last_seen_location: Free-text location description
      - case_id           : Police case ID (optional)
      - image             : Image file (JPEG/PNG)
    """
    raw_bytes = await image.read()

    # --- Face detection ---
    try:
        img_array = bytes_to_array(raw_bytes)
        face_crop  = detect_face(img_array)
        face_bytes = array_to_bytes(face_crop)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

    # --- Embedding generation ---
    try:
        embedding = generate_embedding(face_crop)
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate face embedding: {exc}",
        )

    # --- Age progression ---
    try:
        progression_bytes = generate_age_progression(face_bytes, current_age=age_at_missing)
        progression_b64   = progression_to_base64(progression_bytes)
    except Exception as exc:
        # Age progression failure is non-fatal for registration
        progression_b64 = {}

    # --- Persist to MongoDB ---
    original_b64 = base64.b64encode(raw_bytes).decode("utf-8")

    record = {
        "case_id":               case_id or str(uuid.uuid4())[:8].upper(),
        "name":                  name,
        "age_at_missing":        age_at_missing,
        "last_seen_location":    last_seen_location,
        "original_image":        original_b64,
        "age_progressed_images": progression_b64,
        "face_embedding":        embedding,
    }

    person_id = insert_lost_person(record)

    return {
        "message":   "Lost person registered successfully.",
        "person_id": person_id,
        "case_id":   record["case_id"],
        "age_progressions_generated": list(progression_b64.keys()),
    }


# ---------------------------------------------------------------------------
# GET /api/persons
# ---------------------------------------------------------------------------

@router.get("/")
def list_lost_persons(_auth: dict = Depends(require_auth)):
    """Return all lost person records. Face embeddings are excluded for bandwidth."""
    persons = get_all_lost_persons()
    # Strip embeddings from list view
    for p in persons:
        p.pop("face_embedding", None)
    return {"total": len(persons), "persons": persons}


# ---------------------------------------------------------------------------
# GET /api/persons/{person_id}
# ---------------------------------------------------------------------------

@router.get("/{person_id}")
def get_person(person_id: str, _auth: dict = Depends(require_auth)):
    """Return a single lost person record by MongoDB _id."""
    person = get_lost_person_by_id(person_id)
    if not person:
        raise HTTPException(status_code=404, detail="Person not found.")
    person.pop("face_embedding", None)
    return person
