"""
Face Recognition Module — FaceNet embeddings + cosine similarity matching.

Responsibilities:
  1. Generate a 128-D (FaceNet-128) embedding for a cropped face image.
  2. Compare a query embedding against all stored embeddings.
  3. Return ranked matches with a human-readable confidence label.

Similarity thresholds (cosine similarity, 0–1 scale):
  < 0.70  → No match  (ignore)
  0.70–0.75 → Low confidence
  0.75–0.80 → Possible match
  > 0.80  → Strong match

Usage:
    from face_recognition.embedder import generate_embedding, match_embedding

    embedding = generate_embedding(face_160_rgb_array)
    matches   = match_embedding(embedding, db_records)
"""

import numpy as np
from deepface import DeepFace
from scipy.spatial.distance import cosine

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MODEL_NAME = "Facenet"       # DeepFace model; outputs 128-D embeddings
DETECTOR_BACKEND = "skip"   # Face already cropped by MTCNN — skip re-detection

# Similarity thresholds
THRESHOLD_STRONG  = 0.80
THRESHOLD_POSSIBLE = 0.75
THRESHOLD_LOW     = 0.70


# ---------------------------------------------------------------------------
# Embedding generation
# ---------------------------------------------------------------------------

def generate_embedding(face_array: np.ndarray) -> list[float]:
    """
    Generate a 128-D FaceNet embedding for a pre-cropped 160×160 RGB face.

    Parameters
    ----------
    face_array : numpy array, shape (160, 160, 3), dtype uint8, RGB colour order.

    Returns
    -------
    List of 128 floats (the normalised face embedding vector).

    Raises
    ------
    ValueError  : if DeepFace fails to extract the embedding.
    """
    result = DeepFace.represent(
        img_path=face_array,
        model_name=MODEL_NAME,
        detector_backend=DETECTOR_BACKEND,
        enforce_detection=False,
    )

    # DeepFace.represent returns a list of dicts; take the first face's embedding
    if not result:
        raise ValueError("DeepFace returned an empty result — cannot generate embedding.")

    embedding = result[0]["embedding"]
    # Normalise to unit length for stable cosine similarity
    embedding_arr = np.array(embedding, dtype=np.float32)
    norm = np.linalg.norm(embedding_arr)
    if norm > 0:
        embedding_arr = embedding_arr / norm
    return embedding_arr.tolist()


# ---------------------------------------------------------------------------
# Similarity helpers
# ---------------------------------------------------------------------------

def cosine_similarity(vec_a: list[float], vec_b: list[float]) -> float:
    """
    Return the cosine similarity (0–1) between two embedding vectors.
    Higher is more similar.
    """
    a = np.array(vec_a, dtype=np.float32)
    b = np.array(vec_b, dtype=np.float32)
    return float(1.0 - cosine(a, b))


def label_from_similarity(score: float) -> str:
    """Map a numeric similarity score to a human-readable confidence label."""
    if score >= THRESHOLD_STRONG:
        return "strong_match"
    if score >= THRESHOLD_POSSIBLE:
        return "possible_match"
    if score >= THRESHOLD_LOW:
        return "low_confidence"
    return "no_match"


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------

def match_embedding(
    query_embedding: list[float],
    db_records: list[dict],
    top_k: int = 5,
) -> list[dict]:
    """
    Compare *query_embedding* against every record in *db_records*.

    Each record must contain a "face_embedding" key with a list of floats.
    Records without a valid embedding are silently skipped.

    Parameters
    ----------
    query_embedding : 128-D embedding for the scanned face.
    db_records      : list of lost_persons documents from MongoDB.
    top_k           : maximum number of results to return.

    Returns
    -------
    List of dicts (sorted by similarity descending), each containing:
      {
        "_id":              str,
        "name":             str,
        "case_id":          str,
        "age_at_missing":   int,
        "original_image":   str  (base64 or file path),
        "age_progressed_images": dict,
        "similarity_score": float  (0–1),
        "confidence_level": str,
      }

    Only records with similarity >= THRESHOLD_LOW (0.70) are included.
    """
    results = []

    for record in db_records:
        stored_embedding = record.get("face_embedding")
        if not stored_embedding or len(stored_embedding) == 0:
            continue

        score = cosine_similarity(query_embedding, stored_embedding)
        confidence = label_from_similarity(score)

        if score < THRESHOLD_LOW:
            continue

        results.append(
            {
                "_id":                   record.get("_id", ""),
                "name":                  record.get("name", "Unknown"),
                "case_id":               record.get("case_id", ""),
                "age_at_missing":        record.get("age_at_missing", 0),
                "original_image":        record.get("original_image", ""),
                "age_progressed_images": record.get("age_progressed_images", {}),
                "similarity_score":      round(score, 4),
                "confidence_level":      confidence,
            }
        )

    # Sort by similarity descending, return top_k
    results.sort(key=lambda r: r["similarity_score"], reverse=True)
    return results[:top_k]
