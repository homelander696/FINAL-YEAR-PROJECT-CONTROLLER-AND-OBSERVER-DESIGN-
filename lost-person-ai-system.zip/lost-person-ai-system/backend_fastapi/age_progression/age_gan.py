"""
Age Progression Module — SAM (Style-based Age Manipulation) via HuggingFace.

This module generates age-progressed face images at +5, +10, and +15 years
from the current age by calling the HuggingFace Inference API with the
yuval-alaluf/SAM model.

Fallback strategy:
  If the HuggingFace API is unavailable (no token, quota exceeded, or network
  error) the module falls back to a lightweight OpenCV-based age simulation
  that applies skin-tone shifts and subtle blur — sufficient for prototype
  demonstration without any model download.

Usage:
    from age_progression.age_gan import generate_age_progression

    results = generate_age_progression(face_bytes, current_age=25)
    # results = {
    #     "+5":  <bytes>,   # JPEG bytes of face at age 30
    #     "+10": <bytes>,   # JPEG bytes of face at age 35
    #     "+15": <bytes>,   # JPEG bytes of face at age 40
    # }
"""

import io
import os
import logging
import time

import cv2
import numpy as np
import requests
from PIL import Image

logger = logging.getLogger(__name__)

# HuggingFace Inference API endpoint for SAM
_HF_API_URL = "https://api-inference.huggingface.co/models/yuval-alaluf/sam"
_HF_TOKEN   = os.getenv("HUGGINGFACE_API_TOKEN", "")

# Age offsets to generate
AGE_OFFSETS = [5, 10, 15]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _to_jpeg_bytes(array: np.ndarray) -> bytes:
    pil = Image.fromarray(array.astype(np.uint8))
    buf = io.BytesIO()
    pil.save(buf, format="JPEG", quality=90)
    return buf.getvalue()


def _bytes_to_array(data: bytes) -> np.ndarray:
    pil = Image.open(io.BytesIO(data)).convert("RGB")
    return np.array(pil)


# ---------------------------------------------------------------------------
# HuggingFace SAM API call
# ---------------------------------------------------------------------------

def _age_via_huggingface(face_bytes: bytes, target_age: int, retries: int = 3) -> bytes:
    """
    Call HuggingFace Inference API to age a face image to *target_age*.

    The SAM model accepts an image and an 'age' parameter in the JSON payload.
    Returns JPEG bytes of the aged face.

    Raises requests.HTTPError on non-200 responses after retries.
    """
    headers = {"Authorization": f"Bearer {_HF_TOKEN}"}
    payload = {"inputs": {"age": target_age}}

    for attempt in range(1, retries + 1):
        response = requests.post(
            _HF_API_URL,
            headers=headers,
            data=face_bytes,
            params={"age": target_age},
            timeout=60,
        )
        if response.status_code == 200:
            return response.content
        if response.status_code == 503:
            # Model is loading — wait and retry
            wait = 20 * attempt
            logger.warning(
                "HuggingFace model loading (503), attempt %d/%d, waiting %ds",
                attempt, retries, wait,
            )
            time.sleep(wait)
            continue
        response.raise_for_status()

    raise RuntimeError(f"HuggingFace API failed after {retries} retries.")


# ---------------------------------------------------------------------------
# OpenCV fallback age simulation
# ---------------------------------------------------------------------------

def _age_via_opencv(face_array: np.ndarray, offset_years: int) -> np.ndarray:
    """
    Lightweight age simulation fallback (no ML model required).

    Technique:
      - Slight gaussian blur to simulate skin smoothness loss.
      - Subtle yellow-brown tone shift to mimic age-related pigmentation.
      - Contrast reduction to soften highlights.

    This is purely cosmetic and intended only for prototype/demo purposes.
    """
    result = face_array.copy().astype(np.float32)

    # Progressive blur (more blur = older appearance)
    blur_sigma = 0.3 * offset_years
    kernel_size = max(1, int(blur_sigma * 2) | 1)  # must be odd
    blurred = cv2.GaussianBlur(result, (kernel_size, kernel_size), blur_sigma)
    blend_alpha = min(0.6, offset_years * 0.04)
    result = cv2.addWeighted(result, 1 - blend_alpha, blurred, blend_alpha, 0)

    # Yellowish-brown tint — channel shift
    intensity = offset_years * 1.2
    result[:, :, 0] = np.clip(result[:, :, 0] - intensity * 0.3, 0, 255)  # R: slight drop
    result[:, :, 1] = np.clip(result[:, :, 1] - intensity * 0.5, 0, 255)  # G: moderate drop
    result[:, :, 2] = np.clip(result[:, :, 2] - intensity * 0.8, 0, 255)  # B: larger drop

    # Contrast reduction
    contrast_factor = max(0.70, 1.0 - offset_years * 0.012)
    mean_val = np.mean(result)
    result = mean_val + (result - mean_val) * contrast_factor

    return np.clip(result, 0, 255).astype(np.uint8)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_age_progression(
    face_bytes: bytes,
    current_age: int,
    use_api: bool = True,
) -> dict[str, bytes]:
    """
    Generate age-progressed images at +5, +10, and +15 years.

    Parameters
    ----------
    face_bytes   : JPEG/PNG bytes of the cropped face (160×160 recommended).
    current_age  : The person's age at the time of the original photo.
    use_api      : If True, attempt HuggingFace API first; fall back to
                   OpenCV simulation on failure. Set to False to always use
                   the OpenCV fallback (useful offline).

    Returns
    -------
    Dict mapping offset label to JPEG bytes:
      { "+5": bytes, "+10": bytes, "+15": bytes }
    """
    results: dict[str, bytes] = {}
    face_array = _bytes_to_array(face_bytes)

    for offset in AGE_OFFSETS:
        target_age = current_age + offset
        label = f"+{offset}"

        if use_api and _HF_TOKEN and _HF_TOKEN.startswith("hf_"):
            try:
                logger.info("Generating age +%d via HuggingFace API (target age %d)", offset, target_age)
                aged_bytes = _age_via_huggingface(face_bytes, target_age)
                results[label] = aged_bytes
                continue
            except Exception as exc:
                logger.warning(
                    "HuggingFace API failed for offset +%d: %s. Using OpenCV fallback.",
                    offset, exc,
                )

        # OpenCV fallback
        logger.info("Generating age +%d via OpenCV simulation", offset)
        aged_array = _age_via_opencv(face_array, offset)
        results[label] = _to_jpeg_bytes(aged_array)

    return results


def progression_to_base64(progression: dict[str, bytes]) -> dict[str, str]:
    """
    Convert the bytes dict returned by generate_age_progression into
    base64-encoded strings suitable for storing in MongoDB or sending as JSON.
    """
    import base64
    return {k: base64.b64encode(v).decode("utf-8") for k, v in progression.items()}
