const router = require('express').Router();
const { createUser, listUsers, updateUser } = require('../controllers/user.controller');
const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/rbac');
const { validate } = require('../middleware/validate');
const { createUserValidators, updateUserValidators } = require('../validators/user.validators');

router.use(protect);
router.use(authorize('admin'));

router.post('/', createUserValidators, validate, createUser);
router.get('/', listUsers);
router.patch('/:id', updateUserValidators, validate, updateUser);

module.exports = router;
