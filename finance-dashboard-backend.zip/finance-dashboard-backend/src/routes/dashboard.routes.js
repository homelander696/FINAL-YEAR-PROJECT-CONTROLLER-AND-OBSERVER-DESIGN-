const router = require('express').Router();
const {
  getSummary,
  getCategoryTotals,
  getTrends,
  getRecentActivity,
} = require('../controllers/dashboard.controller');
const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/rbac');

router.use(protect);

// Viewers can see the dashboard; analysts and admins get the same (all have read access)
router.get('/summary', authorize('viewer', 'analyst', 'admin'), getSummary);
router.get('/categories', authorize('viewer', 'analyst', 'admin'), getCategoryTotals);
router.get('/trends', authorize('analyst', 'admin'), getTrends);
router.get('/recent', authorize('viewer', 'analyst', 'admin'), getRecentActivity);

module.exports = router;
