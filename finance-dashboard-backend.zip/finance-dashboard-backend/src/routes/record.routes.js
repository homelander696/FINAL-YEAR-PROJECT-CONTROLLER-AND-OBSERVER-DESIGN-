const router = require('express').Router();
const {
  createRecord,
  listRecords,
  getRecord,
  updateRecord,
  deleteRecord,
} = require('../controllers/record.controller');
const { protect } = require('../middleware/auth');
const { authorize } = require('../middleware/rbac');
const { validate } = require('../middleware/validate');
const {
  createRecordValidators,
  updateRecordValidators,
  listRecordsQueryValidators,
} = require('../validators/record.validators');

router.use(protect);

// Viewers and above can read records
router.get('/', authorize('viewer', 'analyst', 'admin'), listRecordsQueryValidators, validate, listRecords);
router.get('/:id', authorize('viewer', 'analyst', 'admin'), getRecord);

// Only admins can mutate records
router.post('/', authorize('admin'), createRecordValidators, validate, createRecord);
router.patch('/:id', authorize('admin'), updateRecordValidators, validate, updateRecord);
router.delete('/:id', authorize('admin'), deleteRecord);

module.exports = router;
