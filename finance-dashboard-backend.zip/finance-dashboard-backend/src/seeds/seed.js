require('dotenv').config({ path: `${__dirname}/../../.env` });
const mongoose = require('mongoose');
const User = require('../models/User');
const FinancialRecord = require('../models/FinancialRecord');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/finance_dashboard';

const users = [
  { name: 'Alice Admin', email: 'admin@finance.dev', password: 'admin123', role: 'admin' },
  { name: 'Ana Analyst', email: 'analyst@finance.dev', password: 'analyst123', role: 'analyst' },
  { name: 'Victor Viewer', email: 'viewer@finance.dev', password: 'viewer123', role: 'viewer' },
];

const generateRecords = (adminId) => {
  const categories = [
    'salary', 'freelance', 'investment', 'rent', 'utilities',
    'groceries', 'transport', 'healthcare', 'entertainment', 'education',
  ];
  const records = [];

  // Generate 6 months of data
  for (let m = 0; m < 6; m++) {
    const monthDate = new Date();
    monthDate.setMonth(monthDate.getMonth() - m);

    // Income entries
    records.push({
      amount: 5000 + Math.round(Math.random() * 2000),
      type: 'income',
      category: 'salary',
      date: new Date(monthDate.getFullYear(), monthDate.getMonth(), 1),
      notes: `Monthly salary - ${monthDate.toLocaleString('default', { month: 'long', year: 'numeric' })}`,
      createdBy: adminId,
    });

    if (Math.random() > 0.5) {
      records.push({
        amount: Math.round(Math.random() * 1500 + 200),
        type: 'income',
        category: 'freelance',
        date: new Date(monthDate.getFullYear(), monthDate.getMonth(), 10),
        notes: 'Freelance project payment',
        createdBy: adminId,
      });
    }

    // Expense entries
    const expenseCategories = categories.filter((c) => !['salary', 'freelance', 'investment'].includes(c));
    for (const cat of expenseCategories.slice(0, 5)) {
      records.push({
        amount: Math.round(Math.random() * 500 + 50),
        type: 'expense',
        category: cat,
        date: new Date(monthDate.getFullYear(), monthDate.getMonth(), Math.ceil(Math.random() * 28)),
        notes: `${cat} expense`,
        createdBy: adminId,
      });
    }
  }

  return records;
};

const seed = async () => {
  await mongoose.connect(MONGO_URI);
  console.log('Connected to MongoDB');

  await User.deleteMany({});
  await FinancialRecord.deleteMany({});
  console.log('Cleared existing data');

  const createdUsers = [];
  for (const userData of users) {
    const user = await User.create(userData);
    createdUsers.push(user);
    console.log(`Created user: ${user.email} (${user.role})`);
  }

  const admin = createdUsers.find((u) => u.role === 'admin');
  const records = generateRecords(admin._id);
  await FinancialRecord.insertMany(records);
  console.log(`Seeded ${records.length} financial records`);

  console.log('\n--- Seed credentials ---');
  console.log('Admin:    admin@finance.dev   / admin123');
  console.log('Analyst:  analyst@finance.dev / analyst123');
  console.log('Viewer:   viewer@finance.dev  / viewer123');

  await mongoose.disconnect();
  console.log('\nSeeding complete.');
};

seed().catch((err) => {
  console.error('Seed failed:', err.message);
  process.exit(1);
});
