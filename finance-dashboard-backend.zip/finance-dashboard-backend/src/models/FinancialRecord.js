const mongoose = require('mongoose');

const CATEGORIES = [
  'salary',
  'freelance',
  'investment',
  'rent',
  'utilities',
  'groceries',
  'transport',
  'healthcare',
  'entertainment',
  'education',
  'other',
];

const financialRecordSchema = new mongoose.Schema(
  {
    amount: {
      type: Number,
      required: [true, 'Amount is required'],
      min: [0.01, 'Amount must be greater than 0'],
    },
    type: {
      type: String,
      enum: ['income', 'expense'],
      required: [true, 'Type is required'],
    },
    category: {
      type: String,
      enum: CATEGORIES,
      required: [true, 'Category is required'],
    },
    date: {
      type: Date,
      required: [true, 'Date is required'],
      default: Date.now,
    },
    notes: {
      type: String,
      trim: true,
      maxlength: [500, 'Notes cannot exceed 500 characters'],
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

// Exclude soft-deleted records from all standard queries and counts
financialRecordSchema.pre(/^find|countDocuments/, function (next) {
  if (this.getOptions()._includeDeleted) return next();
  this.where({ isDeleted: false });
  next();
});

// Index for common filter patterns
financialRecordSchema.index({ type: 1, category: 1, date: -1 });
financialRecordSchema.index({ createdBy: 1, date: -1 });

const FinancialRecord = mongoose.model('FinancialRecord', financialRecordSchema);
module.exports = FinancialRecord;
module.exports.CATEGORIES = CATEGORIES;
