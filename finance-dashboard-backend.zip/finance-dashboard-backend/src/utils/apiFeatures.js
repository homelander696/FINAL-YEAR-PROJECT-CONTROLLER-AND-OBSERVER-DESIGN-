/**
 * Builds a Mongoose-compatible filter object and pagination options
 * from request query parameters.
 */
const buildRecordFilter = (query) => {
  const { type, category, fromDate, toDate } = query;
  const filter = {};

  if (type) filter.type = type;
  if (category) filter.category = category;

  if (fromDate || toDate) {
    filter.date = {};
    if (fromDate) filter.date.$gte = new Date(fromDate);
    if (toDate) {
      // include the full toDate day
      const end = new Date(toDate);
      end.setHours(23, 59, 59, 999);
      filter.date.$lte = end;
    }
  }

  return filter;
};

const buildPagination = (query) => {
  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(query.limit, 10) || 20));
  const skip = (page - 1) * limit;
  const sortField = query.sortBy || 'date';
  const sortOrder = query.order === 'asc' ? 1 : -1;
  const sort = { [sortField]: sortOrder };
  return { page, limit, skip, sort };
};

module.exports = { buildRecordFilter, buildPagination };
