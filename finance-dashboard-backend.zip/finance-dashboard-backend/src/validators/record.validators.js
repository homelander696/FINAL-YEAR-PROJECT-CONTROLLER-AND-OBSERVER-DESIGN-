const { body, query } = require('express-validator');
const { CATEGORIES } = require('../models/FinancialRecord');

const createRecordValidators = [
  body('amount')
    .isFloat({ gt: 0 })
    .withMessage('Amount must be a positive number'),
  body('type')
    .isIn(['income', 'expense'])
    .withMessage("Type must be 'income' or 'expense'"),
  body('category')
    .isIn(CATEGORIES)
    .withMessage(`Category must be one of: ${CATEGORIES.join(', ')}`),
  body('date')
    .optional()
    .isISO8601()
    .withMessage('Date must be a valid ISO 8601 date'),
  body('notes')
    .optional()
    .isString()
    .isLength({ max: 500 })
    .withMessage('Notes cannot exceed 500 characters'),
];

const updateRecordValidators = [
  body('amount')
    .optional()
    .isFloat({ gt: 0 })
    .withMessage('Amount must be a positive number'),
  body('type')
    .optional()
    .isIn(['income', 'expense'])
    .withMessage("Type must be 'income' or 'expense'"),
  body('category')
    .optional()
    .isIn(CATEGORIES)
    .withMessage(`Category must be one of: ${CATEGORIES.join(', ')}`),
  body('date')
    .optional()
    .isISO8601()
    .withMessage('Date must be a valid ISO 8601 date'),
  body('notes')
    .optional()
    .isString()
    .isLength({ max: 500 })
    .withMessage('Notes cannot exceed 500 characters'),
];

const listRecordsQueryValidators = [
  query('type')
    .optional()
    .isIn(['income', 'expense'])
    .withMessage("type filter must be 'income' or 'expense'"),
  query('category')
    .optional()
    .isIn(CATEGORIES)
    .withMessage(`category filter must be one of: ${CATEGORIES.join(', ')}`),
  query('fromDate')
    .optional()
    .isISO8601()
    .withMessage('fromDate must be a valid ISO 8601 date'),
  query('toDate')
    .optional()
    .isISO8601()
    .withMessage('toDate must be a valid ISO 8601 date'),
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('limit must be between 1 and 100'),
  query('sortBy')
    .optional()
    .isIn(['date', 'amount', 'createdAt'])
    .withMessage("sortBy must be 'date', 'amount', or 'createdAt'"),
  query('order')
    .optional()
    .isIn(['asc', 'desc'])
    .withMessage("order must be 'asc' or 'desc'"),
];

module.exports = { createRecordValidators, updateRecordValidators, listRecordsQueryValidators };
