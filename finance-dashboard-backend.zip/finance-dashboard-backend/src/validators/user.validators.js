const { body } = require('express-validator');
const { ROLES } = require('../models/User');

const createUserValidators = [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('Valid email is required').normalizeEmail(),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters'),
  body('role')
    .optional()
    .isIn(ROLES)
    .withMessage(`Role must be one of: ${ROLES.join(', ')}`),
];

const updateUserValidators = [
  body('role')
    .optional()
    .isIn(ROLES)
    .withMessage(`Role must be one of: ${ROLES.join(', ')}`),
  body('status')
    .optional()
    .isIn(['active', 'inactive'])
    .withMessage("Status must be 'active' or 'inactive'"),
  body('name').optional().trim().notEmpty().withMessage('Name cannot be empty'),
];

module.exports = { createUserValidators, updateUserValidators };
