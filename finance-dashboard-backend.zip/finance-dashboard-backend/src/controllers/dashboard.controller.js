const FinancialRecord = require('../models/FinancialRecord');

/**
 * GET /api/dashboard/summary
 * Returns total income, total expenses, and net balance.
 * Supports optional fromDate/toDate query params to scope the window.
 */
const getSummary = async (req, res, next) => {
  try {
    const matchStage = _buildDateMatch(req.query);

    const result = await FinancialRecord.aggregate([
      { $match: { isDeleted: false, ...matchStage } },
      {
        $group: {
          _id: '$type',
          total: { $sum: '$amount' },
          count: { $sum: 1 },
        },
      },
    ]);

    let totalIncome = 0;
    let totalExpenses = 0;
    let incomeCount = 0;
    let expenseCount = 0;

    for (const item of result) {
      if (item._id === 'income') {
        totalIncome = item.total;
        incomeCount = item.count;
      } else if (item._id === 'expense') {
        totalExpenses = item.total;
        expenseCount = item.count;
      }
    }

    res.json({
      success: true,
      summary: {
        totalIncome,
        totalExpenses,
        netBalance: totalIncome - totalExpenses,
        incomeCount,
        expenseCount,
        totalTransactions: incomeCount + expenseCount,
      },
    });
  } catch (err) {
    next(err);
  }
};

/**
 * GET /api/dashboard/categories
 * Returns category-wise breakdown of income and expenses.
 */
const getCategoryTotals = async (req, res, next) => {
  try {
    const matchStage = _buildDateMatch(req.query);

    const result = await FinancialRecord.aggregate([
      { $match: { isDeleted: false, ...matchStage } },
      {
        $group: {
          _id: { category: '$category', type: '$type' },
          total: { $sum: '$amount' },
          count: { $sum: 1 },
        },
      },
      { $sort: { total: -1 } },
    ]);

    // Shape into { category -> { income, expense, net } }
    const categoriesMap = {};
    for (const item of result) {
      const { category, type } = item._id;
      if (!categoriesMap[category]) {
        categoriesMap[category] = { category, income: 0, expense: 0, net: 0, count: 0 };
      }
      categoriesMap[category][type] = item.total;
      categoriesMap[category].count += item.count;
    }
    for (const c of Object.values(categoriesMap)) {
      c.net = c.income - c.expense;
    }

    res.json({
      success: true,
      categories: Object.values(categoriesMap).sort((a, b) => Math.abs(b.net) - Math.abs(a.net)),
    });
  } catch (err) {
    next(err);
  }
};

/**
 * GET /api/dashboard/trends?groupBy=month|week
 * Returns time-series aggregation grouped by month (default) or week.
 */
const getTrends = async (req, res, next) => {
  try {
    const groupBy = req.query.groupBy === 'week' ? 'week' : 'month';
    const matchStage = _buildDateMatch(req.query);

    const dateFormat = groupBy === 'week' ? '%Y-W%V' : '%Y-%m';

    const result = await FinancialRecord.aggregate([
      { $match: { isDeleted: false, ...matchStage } },
      {
        $group: {
          _id: {
            period: { $dateToString: { format: dateFormat, date: '$date' } },
            type: '$type',
          },
          total: { $sum: '$amount' },
          count: { $sum: 1 },
        },
      },
      { $sort: { '_id.period': 1 } },
    ]);

    // Merge income and expense per period
    const periodsMap = {};
    for (const item of result) {
      const { period, type } = item._id;
      if (!periodsMap[period]) {
        periodsMap[period] = { period, income: 0, expense: 0, net: 0 };
      }
      periodsMap[period][type] = item.total;
    }
    for (const p of Object.values(periodsMap)) {
      p.net = p.income - p.expense;
    }

    res.json({
      success: true,
      groupBy,
      trends: Object.values(periodsMap).sort((a, b) => a.period.localeCompare(b.period)),
    });
  } catch (err) {
    next(err);
  }
};

/**
 * GET /api/dashboard/recent?limit=10
 * Returns most recent financial records.
 */
const getRecentActivity = async (req, res, next) => {
  try {
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 10));

    const records = await FinancialRecord.find({ isDeleted: false })
      .populate('createdBy', 'name email')
      .sort({ date: -1 })
      .limit(limit);

    res.json({ success: true, count: records.length, records });
  } catch (err) {
    next(err);
  }
};

// Helper: build $match date range from query params
const _buildDateMatch = ({ fromDate, toDate }) => {
  const match = {};
  if (fromDate || toDate) {
    match.date = {};
    if (fromDate) match.date.$gte = new Date(fromDate);
    if (toDate) {
      const end = new Date(toDate);
      end.setHours(23, 59, 59, 999);
      match.date.$lte = end;
    }
  }
  return match;
};

module.exports = { getSummary, getCategoryTotals, getTrends, getRecentActivity };
