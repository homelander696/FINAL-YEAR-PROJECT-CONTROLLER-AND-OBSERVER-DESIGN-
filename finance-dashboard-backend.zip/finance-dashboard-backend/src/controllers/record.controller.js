const FinancialRecord = require('../models/FinancialRecord');
const { buildRecordFilter, buildPagination } = require('../utils/apiFeatures');

const createRecord = async (req, res, next) => {
  try {
    const { amount, type, category, date, notes } = req.body;
    const record = await FinancialRecord.create({
      amount,
      type,
      category,
      date,
      notes,
      createdBy: req.user._id,
    });
    res.status(201).json({ success: true, record });
  } catch (err) {
    next(err);
  }
};

const listRecords = async (req, res, next) => {
  try {
    const filter = buildRecordFilter(req.query);
    const { page, limit, skip, sort } = buildPagination(req.query);

    const [records, total] = await Promise.all([
      FinancialRecord.find(filter)
        .populate('createdBy', 'name email')
        .sort(sort)
        .skip(skip)
        .limit(limit),
      FinancialRecord.countDocuments(filter),
    ]);

    res.json({
      success: true,
      total,
      page,
      pages: Math.ceil(total / limit),
      records,
    });
  } catch (err) {
    next(err);
  }
};

const getRecord = async (req, res, next) => {
  try {
    const record = await FinancialRecord.findById(req.params.id).populate(
      'createdBy',
      'name email'
    );
    if (!record) {
      return res.status(404).json({ success: false, message: 'Record not found' });
    }
    res.json({ success: true, record });
  } catch (err) {
    next(err);
  }
};

const updateRecord = async (req, res, next) => {
  try {
    const { amount, type, category, date, notes } = req.body;
    const allowedUpdates = {};
    if (amount !== undefined) allowedUpdates.amount = amount;
    if (type !== undefined) allowedUpdates.type = type;
    if (category !== undefined) allowedUpdates.category = category;
    if (date !== undefined) allowedUpdates.date = date;
    if (notes !== undefined) allowedUpdates.notes = notes;

    const record = await FinancialRecord.findByIdAndUpdate(req.params.id, allowedUpdates, {
      new: true,
      runValidators: true,
    });

    if (!record) {
      return res.status(404).json({ success: false, message: 'Record not found' });
    }
    res.json({ success: true, record });
  } catch (err) {
    next(err);
  }
};

const deleteRecord = async (req, res, next) => {
  try {
    // Soft delete: mark isDeleted instead of removing from DB
    const record = await FinancialRecord.findByIdAndUpdate(
      req.params.id,
      { isDeleted: true },
      { new: true }
    );
    if (!record) {
      return res.status(404).json({ success: false, message: 'Record not found' });
    }
    res.json({ success: true, message: 'Record deleted successfully' });
  } catch (err) {
    next(err);
  }
};

module.exports = { createRecord, listRecords, getRecord, updateRecord, deleteRecord };
