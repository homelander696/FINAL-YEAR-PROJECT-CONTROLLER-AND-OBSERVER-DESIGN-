require('dotenv').config({ path: `${__dirname}/../.env` });

const request = require('supertest');
const app = require('../src/app');
const { clearDB } = require('./helpers/db');
const { createUser, createRecord } = require('./helpers/factories');
const { signToken } = require('../src/utils/jwt');

const getToken = (user) => `Bearer ${signToken(user._id)}`;

let admin, viewer;

beforeEach(async () => {
  admin = await createUser({ role: 'admin', email: 'admin@rec.dev', password: 'pass123' });
  viewer = await createUser({ role: 'viewer', email: 'viewer@rec.dev', password: 'pass123' });
});
afterEach(async () => { await clearDB(); });

describe('POST /api/records', () => {
  it('creates a record with valid payload', async () => {
    const res = await request(app)
      .post('/api/records')
      .set('Authorization', getToken(admin))
      .send({ amount: 1200, type: 'expense', category: 'rent', date: '2024-03-01' });
    expect(res.status).toBe(201);
    expect(res.body.record.category).toBe('rent');
    expect(res.body.record.amount).toBe(1200);
  });

  it('rejects negative amount', async () => {
    const res = await request(app)
      .post('/api/records')
      .set('Authorization', getToken(admin))
      .send({ amount: -100, type: 'income', category: 'salary' });
    expect(res.status).toBe(400);
  });

  it('rejects unknown category', async () => {
    const res = await request(app)
      .post('/api/records')
      .set('Authorization', getToken(admin))
      .send({ amount: 100, type: 'income', category: 'unknown_cat' });
    expect(res.status).toBe(400);
  });
});

describe('GET /api/records', () => {
  beforeEach(async () => {
    await createRecord(admin._id, { type: 'income', category: 'salary', amount: 5000 });
    await createRecord(admin._id, { type: 'expense', category: 'rent', amount: 1200 });
    await createRecord(admin._id, { type: 'expense', category: 'groceries', amount: 300 });
  });

  it('returns all records for authenticated user', async () => {
    const res = await request(app)
      .get('/api/records')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(200);
    expect(res.body.total).toBe(3);
  });

  it('filters by type', async () => {
    const res = await request(app)
      .get('/api/records?type=expense')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(200);
    expect(res.body.total).toBe(2);
    expect(res.body.records.every((r) => r.type === 'expense')).toBe(true);
  });

  it('filters by category', async () => {
    const res = await request(app)
      .get('/api/records?category=rent')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(200);
    expect(res.body.total).toBe(1);
  });

  it('rejects invalid type filter', async () => {
    const res = await request(app)
      .get('/api/records?type=invalid')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(400);
  });
});

describe('PATCH /api/records/:id', () => {
  it('updates a record', async () => {
    const record = await createRecord(admin._id, { amount: 500 });
    const res = await request(app)
      .patch(`/api/records/${record._id}`)
      .set('Authorization', getToken(admin))
      .send({ amount: 750, notes: 'Updated note' });
    expect(res.status).toBe(200);
    expect(res.body.record.amount).toBe(750);
    expect(res.body.record.notes).toBe('Updated note');
  });

  it('returns 404 for non-existent record', async () => {
    const fakeId = '65f0000000000000deadbeef';
    const res = await request(app)
      .patch(`/api/records/${fakeId}`)
      .set('Authorization', getToken(admin))
      .send({ amount: 100 });
    expect(res.status).toBe(404);
  });
});

describe('DELETE /api/records/:id', () => {
  it('soft-deletes a record', async () => {
    const record = await createRecord(admin._id);
    const res = await request(app)
      .delete(`/api/records/${record._id}`)
      .set('Authorization', getToken(admin));
    expect(res.status).toBe(200);
    expect(res.body.message).toMatch(/deleted/i);

    // Should no longer appear in list
    const list = await request(app)
      .get('/api/records')
      .set('Authorization', getToken(viewer));
    expect(list.body.total).toBe(0);
  });
});
