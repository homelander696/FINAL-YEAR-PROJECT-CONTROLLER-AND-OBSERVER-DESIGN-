const User = require('../../src/models/User');
const FinancialRecord = require('../../src/models/FinancialRecord');

const createUser = async (overrides = {}) => {
  const defaults = {
    name: 'Test User',
    email: `test_${Date.now()}@finance.dev`,
    password: 'password123',
    role: 'viewer',
    status: 'active',
  };
  return User.create({ ...defaults, ...overrides });
};

const createRecord = async (userId, overrides = {}) => {
  const defaults = {
    amount: 1000,
    type: 'income',
    category: 'salary',
    date: new Date(),
    createdBy: userId,
  };
  return FinancialRecord.create({ ...defaults, ...overrides });
};

module.exports = { createUser, createRecord };
