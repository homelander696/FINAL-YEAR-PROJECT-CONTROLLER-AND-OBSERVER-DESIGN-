const mongoose = require('mongoose');

/**
 * Deletes all documents from every collection.
 * Called in afterEach to isolate tests.
 */
const clearDB = async () => {
  const { collections } = mongoose.connection;
  for (const key in collections) {
    await collections[key].deleteMany({});
  }
};

module.exports = { clearDB };
