require('dotenv').config({ path: `${__dirname}/../.env` });

const request = require('supertest');
const app = require('../src/app');
const { clearDB } = require('./helpers/db');
const { createUser, createRecord } = require('./helpers/factories');
const { signToken } = require('../src/utils/jwt');

const getToken = (user) => `Bearer ${signToken(user._id)}`;

let admin, analyst, viewer;

beforeEach(async () => {
  admin = await createUser({ role: 'admin', email: 'admin@dash.dev', password: 'pass123' });
  analyst = await createUser({ role: 'analyst', email: 'analyst@dash.dev', password: 'pass123' });
  viewer = await createUser({ role: 'viewer', email: 'viewer@dash.dev', password: 'pass123' });

  await createRecord(admin._id, { type: 'income', category: 'salary', amount: 5000 });
  await createRecord(admin._id, { type: 'income', category: 'freelance', amount: 1000 });
  await createRecord(admin._id, { type: 'expense', category: 'rent', amount: 1200 });
  await createRecord(admin._id, { type: 'expense', category: 'groceries', amount: 400 });
});
afterEach(async () => { await clearDB(); });

describe('GET /api/dashboard/summary', () => {
  it('returns correct income, expenses and net balance', async () => {
    const res = await request(app)
      .get('/api/dashboard/summary')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(200);
    expect(res.body.summary.totalIncome).toBe(6000);
    expect(res.body.summary.totalExpenses).toBe(1600);
    expect(res.body.summary.netBalance).toBe(4400);
  });

  it('viewer can access summary', async () => {
    const res = await request(app)
      .get('/api/dashboard/summary')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(200);
  });
});

describe('GET /api/dashboard/categories', () => {
  it('returns category breakdown', async () => {
    const res = await request(app)
      .get('/api/dashboard/categories')
      .set('Authorization', getToken(analyst));
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.categories)).toBe(true);
    const salaryEntry = res.body.categories.find((c) => c.category === 'salary');
    expect(salaryEntry).toBeDefined();
    expect(salaryEntry.income).toBe(5000);
  });
});

describe('GET /api/dashboard/trends', () => {
  it('returns monthly trends for analyst', async () => {
    const res = await request(app)
      .get('/api/dashboard/trends?groupBy=month')
      .set('Authorization', getToken(analyst));
    expect(res.status).toBe(200);
    expect(res.body.groupBy).toBe('month');
    expect(Array.isArray(res.body.trends)).toBe(true);
  });

  it('returns 403 for viewer', async () => {
    const res = await request(app)
      .get('/api/dashboard/trends')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(403);
  });
});

describe('GET /api/dashboard/recent', () => {
  it('returns recent records respecting limit', async () => {
    const res = await request(app)
      .get('/api/dashboard/recent?limit=2')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(200);
    expect(res.body.records.length).toBeLessThanOrEqual(2);
  });
});
