require('dotenv').config({ path: `${__dirname}/../.env` });

const request = require('supertest');
const app = require('../src/app');
const { clearDB } = require('./helpers/db');
const { createUser, createRecord } = require('./helpers/factories');
const { signToken } = require('../src/utils/jwt');

const getToken = (user) => `Bearer ${signToken(user._id)}`;

afterEach(async () => { await clearDB(); });

describe('Role-Based Access Control', () => {
  let admin, analyst, viewer;

  beforeEach(async () => {
    admin = await createUser({ role: 'admin', email: 'admin@rbac.dev', password: 'pass123' });
    analyst = await createUser({ role: 'analyst', email: 'analyst@rbac.dev', password: 'pass123' });
    viewer = await createUser({ role: 'viewer', email: 'viewer@rbac.dev', password: 'pass123' });
  });

  it('viewer cannot create a financial record', async () => {
    const res = await request(app)
      .post('/api/records')
      .set('Authorization', getToken(viewer))
      .send({ amount: 500, type: 'income', category: 'salary' });
    expect(res.status).toBe(403);
  });

  it('analyst cannot create a financial record', async () => {
    const res = await request(app)
      .post('/api/records')
      .set('Authorization', getToken(analyst))
      .send({ amount: 500, type: 'income', category: 'salary' });
    expect(res.status).toBe(403);
  });

  it('admin can create a financial record', async () => {
    const res = await request(app)
      .post('/api/records')
      .set('Authorization', getToken(admin))
      .send({ amount: 500, type: 'income', category: 'salary', date: new Date().toISOString() });
    expect(res.status).toBe(201);
    expect(res.body.record.amount).toBe(500);
  });

  it('viewer can read records list', async () => {
    await createRecord(admin._id);
    const res = await request(app)
      .get('/api/records')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.records)).toBe(true);
  });

  it('viewer cannot access user management', async () => {
    const res = await request(app)
      .get('/api/users')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(403);
  });

  it('analyst cannot manage users', async () => {
    const res = await request(app)
      .get('/api/users')
      .set('Authorization', getToken(analyst));
    expect(res.status).toBe(403);
  });

  it('admin can list users', async () => {
    const res = await request(app)
      .get('/api/users')
      .set('Authorization', getToken(admin));
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.users)).toBe(true);
  });

  it('viewer cannot access trend analytics', async () => {
    const res = await request(app)
      .get('/api/dashboard/trends')
      .set('Authorization', getToken(viewer));
    expect(res.status).toBe(403);
  });

  it('analyst can access trend analytics', async () => {
    const res = await request(app)
      .get('/api/dashboard/trends')
      .set('Authorization', getToken(analyst));
    expect(res.status).toBe(200);
  });

  it('inactive user is blocked even with valid token', async () => {
    const inactive = await createUser({
      role: 'viewer',
      email: 'inactive@rbac.dev',
      password: 'pass123',
      status: 'inactive',
    });
    const res = await request(app)
      .get('/api/records')
      .set('Authorization', getToken(inactive));
    expect(res.status).toBe(403);
  });
});
