# Running the Finance Dashboard Backend

This document covers every way to start, seed, and test the backend — on **Windows**, macOS, and Linux.

---

## Windows Quick Start

> Copy and run these commands in **PowerShell** (Windows Terminal or the built-in PowerShell app). Run as a regular user — no Administrator needed unless MongoDB setup requires it.

### Step 1 — Install Node.js

Download and run the installer from https://nodejs.org (LTS, v18+).  
Verify it worked:

```powershell
node --version
npm --version
```

### Step 2 — Install and start MongoDB

**Option A — MongoDB Community Server (local install, recommended):**

1. Download from https://www.mongodb.com/try/download/community (MSI installer)
2. During install, tick **"Install MongoDB as a Service"** — it will auto-start on boot
3. Verify it is running:

```powershell
Get-Service -Name MongoDB
```

Start it manually if needed:

```powershell
net start MongoDB
```

**Option B — Docker Desktop (no local install):**

```powershell
docker run -d --name mongo -p 27017:27017 mongo:7
```

**Option C — MongoDB Atlas (cloud, no local install):**

Skip the local MongoDB steps and update `MONGO_URI` in `.env` with your Atlas connection string after Step 4.

### Step 3 — Clone / enter the project folder

```powershell
cd finance-dashboard-backend
```

### Step 4 — Create the `.env` file

```powershell
copy .env.example .env
```

Open `.env` in Notepad (or any editor) and confirm the values look correct:

```
PORT=5000
MONGO_URI=mongodb://localhost:27017/finance_dashboard
JWT_SECRET=your_super_secret_jwt_key_change_in_production
JWT_EXPIRES_IN=7d
NODE_ENV=development
```

Change `JWT_SECRET` to any long random string.

### Step 5 — Install dependencies

```powershell
npm install
```

### Step 6 — Seed demo data

```powershell
npm run seed
```

Output confirms 3 users and ~50 records were created:

```
Connected to MongoDB
Cleared existing data
Created user: admin@finance.dev (admin)
Created user: analyst@finance.dev (analyst)
Created user: viewer@finance.dev (viewer)
Seeded 50 financial records

--- Seed credentials ---
Admin:    admin@finance.dev   / admin123
Analyst:  analyst@finance.dev / analyst123
Viewer:   viewer@finance.dev  / viewer123
```

### Step 7 — Start the server

```powershell
# Development mode (auto-restarts on file changes)
npm run dev

# OR production mode
npm start
```

Server is ready at **http://localhost:5000**

### Step 8 — Verify it works

```powershell
curl http://localhost:5000/api/health
```

Expected: `{"status":"ok"}`

### Step 9 — Run tests

```powershell
npm test
```

No MongoDB needed — tests use an in-memory database. Expected: **34 passed**.

---

## Windows — API Smoke Test (PowerShell)

```powershell
# Login and capture the token
$response = Invoke-RestMethod -Method POST `
  -Uri "http://localhost:5000/api/auth/login" `
  -ContentType "application/json" `
  -Body '{"email":"admin@finance.dev","password":"admin123"}'

$TOKEN = $response.token
Write-Host "Token: $TOKEN"

# Dashboard summary
Invoke-RestMethod -Uri "http://localhost:5000/api/dashboard/summary" `
  -Headers @{ Authorization = "Bearer $TOKEN" } | ConvertTo-Json

# List records
Invoke-RestMethod -Uri "http://localhost:5000/api/records" `
  -Headers @{ Authorization = "Bearer $TOKEN" } | ConvertTo-Json

# Category breakdown
Invoke-RestMethod -Uri "http://localhost:5000/api/dashboard/categories" `
  -Headers @{ Authorization = "Bearer $TOKEN" } | ConvertTo-Json

# Monthly trends (analyst/admin only)
Invoke-RestMethod -Uri "http://localhost:5000/api/dashboard/trends?groupBy=month" `
  -Headers @{ Authorization = "Bearer $TOKEN" } | ConvertTo-Json
```

---

## Windows — Common Issues

| Problem | Fix |
|---------|-----|
| `'node' is not recognized` | Node.js not installed or not on PATH — reinstall from nodejs.org and restart PowerShell |
| `'npm' is not recognized` | Same as above |
| `ECONNREFUSED 127.0.0.1:27017` | MongoDB not running — run `net start MongoDB` or start Docker |
| `copy .env.example .env` overwrites with empty file | Use `Copy-Item .env.example .env` in PowerShell instead |
| `npm run dev` exits instantly | Check `.env` exists and `MONGO_URI` is correct |
| Port 5000 in use | Change `PORT=` in `.env`, or find/kill the process: `netstat -ano \| findstr :5000` then `taskkill /PID <pid> /F` |
| Tests fail first run | `mongodb-memory-server` downloads a MongoDB binary on first use — wait for it, then re-run |
| `execution of scripts is disabled` | Run: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |

---

## Prerequisites

| Requirement | Version  | Notes                                             |
|-------------|----------|---------------------------------------------------|
| Node.js     | 18+      | https://nodejs.org                                |
| npm         | 9+       | Bundled with Node.js                              |
| MongoDB     | 6+       | Only required for running the server (not tests)  |

> **Tests do not need MongoDB.** They use an in-process `mongodb-memory-server`.

---

## First-time Setup

```bash
# 1. Enter the project directory
cd finance-dashboard-backend

# 2. Copy the environment template
cp .env.example .env

# 3. Install dependencies
npm install
```

### `.env` reference

```
PORT=5000
MONGO_URI=mongodb://localhost:27017/finance_dashboard
JWT_SECRET=your_super_secret_jwt_key_change_in_production
JWT_EXPIRES_IN=7d
NODE_ENV=development
```

Change `JWT_SECRET` to any long random string before deploying. The rest of the defaults work as-is for local development.

---

## Using `run.sh` (recommended)

The `run.sh` script handles the full bootstrap in one command: checks Node, checks MongoDB, creates `.env` if missing, installs dependencies, seeds data optionally, and starts the server.

```bash
# Make executable (first time only)
chmod +x run.sh
```

### Commands

| Command                   | What it does                                          |
|---------------------------|-------------------------------------------------------|
| `./run.sh`                | Dev mode with nodemon (auto-restarts on file changes) |
| `./run.sh --prod`         | Production mode with plain `node`                     |
| `./run.sh --seed`         | Seed demo data, then start in dev mode                |
| `./run.sh --prod --seed`  | Seed demo data, then start in production mode         |
| `./run.sh --test`         | Run the full test suite (no server started)           |
| `./run.sh --help`         | Print usage                                           |

**Example — fresh setup with demo data:**

```bash
./run.sh --seed
```

This will:
1. Confirm Node.js is installed
2. Warn if MongoDB is not running
3. Copy `.env.example` → `.env` if `.env` is absent
4. Run `npm install`
5. Seed 3 demo users and ~50 financial records
6. Start the dev server on `http://localhost:5000`

---

## Using `npm` scripts directly

```bash
# Development (nodemon, auto-reload)
npm run dev

# Production
npm start

# Seed demo data
npm run seed

# Run tests
npm test
```

---

## Starting MongoDB

The server requires a running MongoDB instance. Choose whichever method matches your setup:

**macOS — Homebrew:**
```bash
brew services start mongodb-community
```

**Linux — systemd:**
```bash
sudo systemctl start mongod
```

**Docker (no local install needed):**
```bash
docker run -d --name mongo -p 27017:27017 mongo:7
```

**MongoDB Atlas (cloud):**
Update `MONGO_URI` in `.env` to your Atlas connection string:
```
MONGO_URI=mongodb+srv://<user>:<password>@cluster.mongodb.net/finance_dashboard
```

---

## Demo Seed Data

After running `npm run seed` or `./run.sh --seed`, the database contains:

| Role     | Email                  | Password     |
|----------|------------------------|--------------|
| Admin    | admin@finance.dev      | admin123     |
| Analyst  | analyst@finance.dev    | analyst123   |
| Viewer   | viewer@finance.dev     | viewer123    |

Plus approximately 50 financial records spread across the past 6 months covering multiple categories.

**Get a token to start making requests:**

```bash
curl -s -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@finance.dev","password":"admin123"}' \
  | python3 -m json.tool
```

Use the returned `token` value as:
```
Authorization: Bearer <token>
```

---

## Verifying the Server

```bash
# Health check (no auth required)
curl http://localhost:5000/api/health

# Expected response
{"status":"ok"}
```

---

## Running Tests

Tests spin up their own in-memory MongoDB — no running database needed.

```bash
npm test
# or
./run.sh --test
```

Expected output:

```
PASS tests/auth.test.js
PASS tests/rbac.test.js
PASS tests/records.test.js
PASS tests/dashboard.test.js

Tests: 34 passed, 34 total
```

---

## Quick API Smoke Test

After seeding and starting the server, run these to confirm core flows work:

```bash
# 1. Login as admin
TOKEN=$(curl -s -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@finance.dev","password":"admin123"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['token'])")

# 2. List financial records
curl -s http://localhost:5000/api/records \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

# 3. Dashboard summary
curl -s http://localhost:5000/api/dashboard/summary \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

# 4. Category breakdown
curl -s http://localhost:5000/api/dashboard/categories \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

# 5. Monthly trends (analyst/admin only)
curl -s "http://localhost:5000/api/dashboard/trends?groupBy=month" \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool
```

---

## Common Issues (macOS / Linux)

| Problem                          | Likely cause                       | Fix                                                                  |
|----------------------------------|------------------------------------|----------------------------------------------------------------------|
| `ECONNREFUSED 127.0.0.1:27017`   | MongoDB not running                | `brew services start mongodb-community` or `sudo systemctl start mongod` |
| `JWT_SECRET` env error           | `.env` missing or empty            | `cp .env.example .env` and set a secret                              |
| `Port 5000 already in use`       | Another process on the port        | Change `PORT` in `.env` or `lsof -ti:5000 | xargs kill`             |
| `Cannot find module`             | `node_modules` missing             | Run `npm install`                                                    |
| Tests fail with connection error | MongoDB memory server download     | First run downloads the binary — retry once                          |
| `run.sh: Permission denied`      | Script not executable              | Run `chmod +x run.sh`                                                |
