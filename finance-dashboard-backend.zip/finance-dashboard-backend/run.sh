#!/usr/bin/env bash
# run.sh — one-shot setup and start script for the Finance Dashboard Backend
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

# ── colour helpers ────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()    { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

# ── parse flags ───────────────────────────────────────────────────────────────
MODE="dev"        # default: development with nodemon
RUN_SEED=false
RUN_TESTS=false

usage() {
  echo ""
  echo "Usage: ./run.sh [options]"
  echo ""
  echo "  -p, --prod      Start in production mode (node, no nodemon)"
  echo "  -d, --dev       Start in development mode with nodemon (default)"
  echo "  -s, --seed      Seed demo data before starting"
  echo "  -t, --test      Run the test suite instead of starting the server"
  echo "  -h, --help      Show this help message"
  echo ""
}

while [[ $# -gt 0 ]]; do
  case $1 in
    -p|--prod)  MODE="prod"; shift ;;
    -d|--dev)   MODE="dev";  shift ;;
    -s|--seed)  RUN_SEED=true; shift ;;
    -t|--test)  RUN_TESTS=true; shift ;;
    -h|--help)  usage; exit 0 ;;
    *)          warn "Unknown option: $1"; usage; exit 1 ;;
  esac
done

# ── check Node.js ─────────────────────────────────────────────────────────────
if ! command -v node &>/dev/null; then
  error "Node.js is not installed. Install it from https://nodejs.org (v18+ recommended)."
fi

NODE_VER=$(node -e "process.stdout.write(process.versions.node.split('.')[0])")
if [[ "$NODE_VER" -lt 16 ]]; then
  warn "Node.js v$NODE_VER detected. v18+ is recommended."
fi
info "Node.js v$(node --version | tr -d 'v') detected."

# ── check MongoDB (only for server modes) ────────────────────────────────────
if [[ "$RUN_TESTS" == false ]]; then
  if ! command -v mongod &>/dev/null && ! pgrep -x mongod &>/dev/null; then
    warn "MongoDB does not appear to be running. Make sure it is started before the server."
    warn "  macOS (Homebrew):  brew services start mongodb-community"
    warn "  Linux (systemd):   sudo systemctl start mongod"
    warn "  Docker:            docker run -d -p 27017:27017 mongo"
  else
    info "MongoDB appears to be running."
  fi
fi

# ── .env setup ────────────────────────────────────────────────────────────────
if [[ ! -f ".env" ]]; then
  if [[ -f ".env.example" ]]; then
    info ".env not found — copying from .env.example"
    cp .env.example .env
    warn "Review .env and set a strong JWT_SECRET before production use."
  else
    error ".env and .env.example both missing. Cannot continue."
  fi
else
  info ".env found."
fi

# ── install dependencies ──────────────────────────────────────────────────────
if [[ ! -d "node_modules" ]]; then
  info "node_modules not found — running npm install..."
  npm install
else
  info "node_modules present — skipping install. Run 'npm install' manually if needed."
fi

# ── seed ──────────────────────────────────────────────────────────────────────
if [[ "$RUN_SEED" == true ]]; then
  info "Seeding demo data..."
  npm run seed
fi

# ── test ──────────────────────────────────────────────────────────────────────
if [[ "$RUN_TESTS" == true ]]; then
  info "Running test suite..."
  npm test
  exit $?
fi

# ── start server ──────────────────────────────────────────────────────────────
if [[ "$MODE" == "prod" ]]; then
  info "Starting server in PRODUCTION mode..."
  export NODE_ENV=production
  npm start
else
  info "Starting server in DEVELOPMENT mode (nodemon)..."
  export NODE_ENV=development
  npm run dev
fi
