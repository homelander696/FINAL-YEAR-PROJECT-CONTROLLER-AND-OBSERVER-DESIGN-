# Architecture

This document describes the structure, design decisions, and data flow of the Finance Dashboard Backend.

---

## Technology Stack

| Concern            | Choice                                   |
|--------------------|------------------------------------------|
| Runtime            | Node.js 18+                              |
| HTTP Framework     | Express 4                                |
| Database           | MongoDB (via Mongoose ODM)               |
| Authentication     | JSON Web Tokens (`jsonwebtoken`)         |
| Password Hashing   | bcryptjs (cost factor 12)                |
| Input Validation   | express-validator                        |
| Logging            | Morgan (dev mode)                        |
| Testing            | Jest + Supertest + MongoMemoryServer     |

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────┐
│                      HTTP Client                        │
│              (curl / Postman / Frontend)                │
└────────────────────────┬────────────────────────────────┘
                         │ HTTP Request
                         ▼
┌─────────────────────────────────────────────────────────┐
│                    Express App                          │
│                                                         │
│  ┌────────────┐  ┌──────────┐  ┌─────────────────────┐ │
│  │   CORS     │  │  Morgan  │  │   express.json()    │ │
│  │ middleware │  │ (logger) │  │   body parser       │ │
│  └────────────┘  └──────────┘  └─────────────────────┘ │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │                    Routes                       │   │
│  │  /api/auth  /api/users  /api/records  /api/dashboard │
│  └────────────────────┬────────────────────────────┘   │
│                       │                                 │
│  ┌────────────────────▼────────────────────────────┐   │
│  │               Middleware Chain                  │   │
│  │                                                 │   │
│  │  1. protect()     — verify JWT, attach req.user │   │
│  │  2. authorize()   — check role against allowlist│   │
│  │  3. validators    — express-validator rules     │   │
│  │  4. validate()    — short-circuit on errors     │   │
│  └────────────────────┬────────────────────────────┘   │
│                       │                                 │
│  ┌────────────────────▼────────────────────────────┐   │
│  │                Controllers                      │   │
│  │  auth · user · record · dashboard               │   │
│  └────────────────────┬────────────────────────────┘   │
│                       │                                 │
│  ┌────────────────────▼────────────────────────────┐   │
│  │            Mongoose Models / ODM                │   │
│  │         User  ·  FinancialRecord                │   │
│  └────────────────────┬────────────────────────────┘   │
│                       │                                 │
└───────────────────────┼─────────────────────────────────┘
                        │ TCP / Mongoose driver
                        ▼
              ┌─────────────────┐
              │    MongoDB      │
              │  finance_dashboard  │
              └─────────────────┘
```

---

## Directory Structure

```
finance-dashboard-backend/
├── src/
│   ├── server.js            # Process entry: loads .env, connects DB, starts server
│   ├── app.js               # Express factory: mounts middleware and route modules
│   │
│   ├── config/
│   │   └── db.js            # Mongoose.connect() wrapper
│   │
│   ├── models/
│   │   ├── User.js          # Schema, bcrypt pre-save hook, comparePassword()
│   │   └── FinancialRecord.js  # Schema, soft-delete query middleware, indexes
│   │
│   ├── controllers/         # One file per resource; no business logic bleeds into routes
│   │   ├── auth.controller.js
│   │   ├── user.controller.js
│   │   ├── record.controller.js
│   │   └── dashboard.controller.js
│   │
│   ├── routes/              # Express routers; wire validators + middleware + controller
│   │   ├── auth.routes.js
│   │   ├── user.routes.js
│   │   ├── record.routes.js
│   │   └── dashboard.routes.js
│   │
│   ├── middleware/
│   │   ├── auth.js          # protect() — JWT verification, inactive-user guard
│   │   ├── rbac.js          # authorize(...roles) — role enforcement
│   │   ├── validate.js      # reads express-validator result, returns 400 on failure
│   │   └── errorHandler.js  # global Express error handler, maps to JSON envelope
│   │
│   ├── validators/          # express-validator rule arrays per resource
│   │   ├── auth.validators.js
│   │   ├── user.validators.js
│   │   └── record.validators.js
│   │
│   ├── utils/
│   │   ├── jwt.js           # signToken(id) helper
│   │   └── apiFeatures.js   # buildRecordFilter() + buildPagination() from req.query
│   │
│   └── seeds/
│       └── seed.js          # Creates 3 demo users + ~50 records over 6 months
│
├── tests/
│   ├── setup.js             # MongoMemoryServer lifecycle (beforeAll / afterAll)
│   ├── helpers/
│   │   ├── db.js            # clearDB() — wipes collections between tests
│   │   └── factories.js     # createUser() / createRecord() test helpers
│   ├── auth.test.js
│   ├── rbac.test.js
│   ├── records.test.js
│   └── dashboard.test.js
│
├── .env.example             # Environment variable template
├── .gitignore
├── package.json
├── README.md
└── ARCHITECTURE.md          # This file
```

---

## Data Models

### User

| Field      | Type     | Notes                                |
|------------|----------|--------------------------------------|
| `name`     | String   | Required, max 100 chars              |
| `email`    | String   | Unique, lowercased                   |
| `password` | String   | Bcrypt hash, never returned in queries (`select: false`) |
| `role`     | Enum     | `viewer` · `analyst` · `admin`       |
| `status`   | Enum     | `active` · `inactive`                |
| `createdAt`| Date     | Auto (Mongoose timestamps)           |
| `updatedAt`| Date     | Auto (Mongoose timestamps)           |

Password hashing happens in a Mongoose `pre('save')` hook. The plain-text password never touches the database.

### FinancialRecord

| Field       | Type     | Notes                                       |
|-------------|----------|---------------------------------------------|
| `amount`    | Number   | Positive float, required                    |
| `type`      | Enum     | `income` · `expense`                        |
| `category`  | Enum     | 11 defined categories (see README)          |
| `date`      | Date     | Defaults to `Date.now`                      |
| `notes`     | String   | Optional, max 500 chars                     |
| `createdBy` | ObjectId | Ref to `User`                               |
| `isDeleted` | Boolean  | Default `false`; soft-delete flag           |
| `createdAt` | Date     | Auto                                        |
| `updatedAt` | Date     | Auto                                        |

**Indexes:**
- `{ type, category, date }` — covers the most common filter pattern
- `{ createdBy, date }` — covers per-user record lookups

**Soft delete:** A Mongoose `pre(/^find|countDocuments/)` middleware transparently appends `{ isDeleted: false }` to every query so deleted records are invisible to all standard operations without any changes in controller code.

---

## Authentication Flow

```
POST /api/auth/login
       │
       ▼
  Validate body (email, password)
       │
       ▼
  User.findOne({ email }).select('+password')
       │
       ├─ not found or wrong password → 401
       ├─ status === 'inactive'       → 403
       └─ ok → bcrypt.compare()
                    │
                    └─ ok → jwt.sign({ id }) → return { token, user }
```

Subsequent protected requests:

```
Authorization: Bearer <token>
       │
       ▼
  protect() middleware
       ├─ no header        → 401
       ├─ jwt.verify fails → 401
       ├─ user not found   → 401
       ├─ user inactive    → 403
       └─ ok → req.user = user → next()
```

---

## Access Control

Role resolution happens in the `authorize(...allowedRoles)` middleware, which runs after `protect()`:

```
protect() → authorize('admin') → controller
```

### Role Matrix

| Endpoint                         | viewer | analyst | admin |
|----------------------------------|:------:|:-------:|:-----:|
| `POST /api/auth/register`        | ✓      | ✓       | ✓     |
| `POST /api/auth/login`           | ✓      | ✓       | ✓     |
| `GET  /api/auth/me`              | ✓      | ✓       | ✓     |
| `GET  /api/records`              | ✓      | ✓       | ✓     |
| `GET  /api/records/:id`          | ✓      | ✓       | ✓     |
| `POST /api/records`              |        |         | ✓     |
| `PATCH /api/records/:id`         |        |         | ✓     |
| `DELETE /api/records/:id`        |        |         | ✓     |
| `GET /api/dashboard/summary`     | ✓      | ✓       | ✓     |
| `GET /api/dashboard/categories`  | ✓      | ✓       | ✓     |
| `GET /api/dashboard/recent`      | ✓      | ✓       | ✓     |
| `GET /api/dashboard/trends`      |        | ✓       | ✓     |
| `GET /api/users`                 |        |         | ✓     |
| `POST /api/users`                |        |         | ✓     |
| `PATCH /api/users/:id`           |        |         | ✓     |

---

## Request Lifecycle

```
Incoming Request
      │
      ▼
  CORS · Morgan · JSON parser
      │
      ▼
  Route match
      │
      ▼
  protect()          ← JWT decode, user hydration, inactive check
      │
      ▼
  authorize()        ← role membership check
      │
      ▼
  validator chain    ← express-validator rules (body / query)
      │
      ▼
  validate()         ← collect errors, return 400 if any
      │
      ▼
  Controller         ← Mongoose operations, business logic
      │
      ├─ success → res.json({ success: true, ... })
      └─ error   → next(err)
                        │
                        ▼
                  errorHandler()   ← maps error type → status code + JSON envelope
```

---

## Dashboard Aggregation Strategy

All four dashboard endpoints use MongoDB aggregation pipelines rather than loading records into memory:

| Endpoint              | Pipeline stages                                                |
|-----------------------|----------------------------------------------------------------|
| `/summary`            | `$match` (date range + isDeleted) → `$group` by type → sum    |
| `/categories`         | `$match` → `$group` by `{category, type}` → in-memory reshape |
| `/trends`             | `$match` → `$group` by `$dateToString` period + type → sort   |
| `/recent`             | `find` + `sort({ date: -1 })` + `limit`                       |

This approach scales to large datasets without loading all records into the application layer.

---

## Error Response Envelope

Every error (validation, auth, server) returns the same shape:

```json
{
  "success": false,
  "message": "Human-readable description",
  "details": [
    { "field": "email", "message": "Valid email is required" }
  ]
}
```

`details` is only present for validation failures (HTTP 400). The `errorHandler` middleware maps Mongoose duplicate-key errors (11000), cast errors, and validation errors to appropriate 4xx codes automatically.

---

## Testing Strategy

Tests use `mongodb-memory-server` to spin up a real in-process MongoDB instance, so no external service is required to run the test suite.

| File                  | What it covers                                               |
|-----------------------|--------------------------------------------------------------|
| `auth.test.js`        | Register, login, duplicate email, missing fields, `/me`      |
| `rbac.test.js`        | Every role boundary: forbidden routes, inactive user block   |
| `records.test.js`     | CRUD happy paths, filter validation, soft-delete visibility  |
| `dashboard.test.js`   | Aggregation correctness, role gates on trends endpoint       |

Lifecycle:
- `tests/setup.js` (`setupFilesAfterEnv`) — starts MongoMemoryServer once per suite, stops it after all tests
- Each test file calls `clearDB()` in `afterEach` to isolate tests without restarting the server

---

## Environment Variables

| Variable        | Required | Default                                        | Description                    |
|-----------------|----------|------------------------------------------------|--------------------------------|
| `PORT`          | No       | `5000`                                         | HTTP server port               |
| `MONGO_URI`     | Yes      | `mongodb://localhost:27017/finance_dashboard`  | MongoDB connection string      |
| `JWT_SECRET`    | Yes      | —                                              | HMAC secret for JWT signing    |
| `JWT_EXPIRES_IN`| No       | `7d`                                           | Token expiry duration          |
| `NODE_ENV`      | No       | `development`                                  | Controls Morgan logging        |
