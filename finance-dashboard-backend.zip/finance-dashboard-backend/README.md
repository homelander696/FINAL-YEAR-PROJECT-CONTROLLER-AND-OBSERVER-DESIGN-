# Finance Dashboard Backend

A backend REST API for a finance dashboard system, built as part of an internship assignment.

Built with **Node.js**, **Express**, **MongoDB** (Mongoose), and **JWT authentication**.

---

## Features

- JWT-based authentication (register / login / token-protected routes)
- Role-based access control: `viewer`, `analyst`, `admin`
- Financial records CRUD with soft delete, filtering, pagination, and sorting
- Dashboard analytics via MongoDB aggregation pipelines
  - Total income / expenses / net balance
  - Category-wise breakdown
  - Monthly and weekly trends
  - Recent activity feed
- Input validation with `express-validator` and structured error responses
- Seed script with demo users and 6 months of sample data

---

## Tech Stack

| Layer       | Technology                       |
|-------------|----------------------------------|
| Runtime     | Node.js 18+                      |
| Framework   | Express 4                        |
| Database    | MongoDB (via Mongoose)           |
| Auth        | JWT (`jsonwebtoken`, `bcryptjs`) |
| Validation  | `express-validator`              |
| Dev tools   | Nodemon, Morgan                  |
| Testing     | Jest + Supertest                 |

---

## Project Structure

```
finance-dashboard-backend/
├── src/
│   ├── app.js               # Express app setup (routes, middleware)
│   ├── server.js            # Entry point (connects DB, starts server)
│   ├── config/
│   │   └── db.js            # Mongoose connection
│   ├── models/
│   │   ├── User.js          # User schema (roles, status, bcrypt)
│   │   └── FinancialRecord.js  # Record schema (soft delete, indexes)
│   ├── controllers/
│   │   ├── auth.controller.js
│   │   ├── user.controller.js
│   │   ├── record.controller.js
│   │   └── dashboard.controller.js
│   ├── routes/
│   │   ├── auth.routes.js
│   │   ├── user.routes.js
│   │   ├── record.routes.js
│   │   └── dashboard.routes.js
│   ├── middleware/
│   │   ├── auth.js          # JWT verification, req.user attachment
│   │   ├── rbac.js          # authorize(...roles) middleware
│   │   ├── validate.js      # express-validator error handler
│   │   └── errorHandler.js  # Centralized error handler
│   ├── validators/
│   │   ├── auth.validators.js
│   │   ├── user.validators.js
│   │   └── record.validators.js
│   ├── utils/
│   │   ├── jwt.js           # Token signing helper
│   │   └── apiFeatures.js   # Filter + pagination query builder
│   └── seeds/
│       └── seed.js          # Demo data seeder
└── tests/
    ├── helpers/
    │   ├── db.js            # Test DB connect/clear/disconnect
    │   └── factories.js     # User + record factory helpers
    ├── auth.test.js
    ├── rbac.test.js
    ├── records.test.js
    └── dashboard.test.js
```

---

## Setup

### Prerequisites

- Node.js 18+
- MongoDB running locally on `mongodb://localhost:27017` (or update `MONGO_URI`)

### Install

```bash
cd finance-dashboard-backend
npm install
```

### Configure environment

```bash
cp .env.example .env
# Edit .env if needed — defaults work for local development
```

### Run development server

```bash
npm run dev
```

Server starts on `http://localhost:5000`.

### Seed demo data

```bash
npm run seed
```

This creates three demo accounts:

| Role     | Email                    | Password     |
|----------|--------------------------|--------------|
| Admin    | admin@finance.dev        | admin123     |
| Analyst  | analyst@finance.dev      | analyst123   |
| Viewer   | viewer@finance.dev       | viewer123    |

And seeds ~50 financial records across the past 6 months.

### Run tests

> Requires MongoDB running locally (uses a separate `finance_dashboard_test` DB).

```bash
npm test
```

---

## API Reference

All protected routes require `Authorization: Bearer <token>` header.

### Auth

| Method | Path                  | Auth | Description                     |
|--------|-----------------------|------|---------------------------------|
| POST   | `/api/auth/register`  | No   | Register a new user             |
| POST   | `/api/auth/login`     | No   | Login and receive JWT           |
| GET    | `/api/auth/me`        | Yes  | Get current user profile        |

**Register / Login request body:**
```json
{
  "name": "Alice",
  "email": "alice@example.com",
  "password": "secret123"
}
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGci...",
  "user": { "_id": "...", "name": "Alice", "email": "...", "role": "viewer" }
}
```

---

### Users (Admin only)

| Method | Path             | Roles | Description              |
|--------|------------------|-------|--------------------------|
| POST   | `/api/users`     | admin | Create a new user        |
| GET    | `/api/users`     | admin | List all users           |
| PATCH  | `/api/users/:id` | admin | Update role/status/name  |

**List users query params:** `role`, `status`, `page`, `limit`

**Update user body (all optional):**
```json
{
  "name": "New Name",
  "role": "analyst",
  "status": "inactive"
}
```

---

### Financial Records

| Method | Path              | Roles                       | Description                |
|--------|-------------------|-----------------------------|----------------------------|
| POST   | `/api/records`    | admin                       | Create a record            |
| GET    | `/api/records`    | viewer, analyst, admin      | List records (filterable)  |
| GET    | `/api/records/:id`| viewer, analyst, admin      | Get a single record        |
| PATCH  | `/api/records/:id`| admin                       | Update a record            |
| DELETE | `/api/records/:id`| admin                       | Soft-delete a record       |

**Create / Update record body:**
```json
{
  "amount": 5000,
  "type": "income",
  "category": "salary",
  "date": "2024-03-01",
  "notes": "March salary"
}
```

**List records query params:**

| Param     | Values                                   | Description                |
|-----------|------------------------------------------|----------------------------|
| `type`    | `income`, `expense`                      | Filter by type             |
| `category`| See categories below                     | Filter by category         |
| `fromDate`| ISO 8601 date                            | Start of date range        |
| `toDate`  | ISO 8601 date                            | End of date range          |
| `sortBy`  | `date`, `amount`, `createdAt`            | Sort field (default: date) |
| `order`   | `asc`, `desc`                            | Sort order (default: desc) |
| `page`    | integer ≥ 1                              | Pagination page            |
| `limit`   | 1–100                                    | Results per page           |

**Valid categories:** `salary`, `freelance`, `investment`, `rent`, `utilities`, `groceries`, `transport`, `healthcare`, `entertainment`, `education`, `other`

---

### Dashboard

| Method | Path                       | Roles                  | Description                   |
|--------|----------------------------|------------------------|-------------------------------|
| GET    | `/api/dashboard/summary`   | viewer, analyst, admin | Income / expenses / net       |
| GET    | `/api/dashboard/categories`| viewer, analyst, admin | Category-wise breakdown       |
| GET    | `/api/dashboard/trends`    | analyst, admin         | Time-series trends            |
| GET    | `/api/dashboard/recent`    | viewer, analyst, admin | Recent transactions           |

**Summary response:**
```json
{
  "success": true,
  "summary": {
    "totalIncome": 6000,
    "totalExpenses": 1600,
    "netBalance": 4400,
    "incomeCount": 2,
    "expenseCount": 2,
    "totalTransactions": 4
  }
}
```

**Trends query params:** `groupBy=month|week`, `fromDate`, `toDate`

**Recent query params:** `limit` (max 50, default 10)

---

## Access Control Matrix

| Action                       | Viewer | Analyst | Admin |
|------------------------------|:------:|:-------:|:-----:|
| Login / Register             | ✓      | ✓       | ✓     |
| View records                 | ✓      | ✓       | ✓     |
| View dashboard summary       | ✓      | ✓       | ✓     |
| View category breakdown      | ✓      | ✓       | ✓     |
| View recent activity         | ✓      | ✓       | ✓     |
| View trend analytics         |        | ✓       | ✓     |
| Create / update / delete records |    |         | ✓     |
| Create / update users        |        |         | ✓     |
| List all users               |        |         | ✓     |

---

## Error Responses

All errors follow a consistent envelope:

```json
{
  "success": false,
  "message": "Human-readable error description",
  "details": [{ "field": "email", "message": "Valid email is required" }]
}
```

| Code | Meaning                                         |
|------|-------------------------------------------------|
| 400  | Validation error / bad input                    |
| 401  | Missing or invalid token                        |
| 403  | Authenticated but not authorized / inactive     |
| 404  | Resource not found                              |
| 409  | Conflict (duplicate email)                      |
| 500  | Unexpected server error                         |

---

## Assumptions and Design Decisions

1. **Single-organization scope** — no multi-tenancy; all users share the same record pool.
2. **Admin-only mutations** — only admin can create, update, or delete records and manage users. Analyst and Viewer are read-only for data integrity.
3. **Viewer sees trends restriction** — trends endpoint is scoped to `analyst+` since it reveals more analytical insight; summary and categories are safe for viewers.
4. **Soft delete** — records are marked `isDeleted: true` rather than permanently removed. A Mongoose query middleware filter ensures they are transparently excluded from all standard queries and aggregations.
5. **Public registration defaults to Viewer** — any new self-registered user gets the `viewer` role. Admins can later upgrade via PATCH `/api/users/:id`.
6. **Amounts are plain numbers** — no currency conversion or multi-currency support. The currency unit is assumed consistent.
7. **Password storage** — bcrypt with cost factor 12.
8. **JWT expiry** — configurable via `JWT_EXPIRES_IN` env var (default 7 days).

---

## Tradeoffs

- **No refresh tokens** — for simplicity, tokens are long-lived (7d). A production system would implement short-lived access tokens with refresh token rotation.
- **In-process validation** — `express-validator` is used inline rather than a separate schema-validation library (e.g., Zod) to keep the dependency footprint small.
- **No rate limiting** — out of scope for an internship assignment but would be added via `express-rate-limit` in production.
- **Test DB isolation** — tests use a dedicated `finance_dashboard_test` database and drop it on teardown. No in-memory MongoDB adapter is used to keep the setup simple and representative.
