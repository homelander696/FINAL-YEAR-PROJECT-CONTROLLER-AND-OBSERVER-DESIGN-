import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react'
import { users as initialUsers } from '../data/users'
import { gestures as initialGestures } from '../data/gestures'
import { commands as initialCommands } from '../data/commands'
import { pages as initialPages } from '../data/pages'
import {
  operatorMappings as initialOperatorMappings,
  viewerMappings as initialViewerMappings,
} from '../data/mappings'
import { nextNumericId, nextPrefixedId } from '../utils/ids'

function newMappingRowId() {
  return `map-${crypto.randomUUID().slice(0, 8)}`
}

const AdminDataContext = createContext(null)

function patchMappingSections(sections, sectionTitle, fn) {
  return sections.map((s) =>
    s.sectionTitle === sectionTitle ? { ...s, rows: fn(s.rows) } : s,
  )
}

export function AdminDataProvider({ children }) {
  const [users, setUsers] = useState(() => [...initialUsers])
  const [gestures, setGestures] = useState(() => [...initialGestures])
  const [pages, setPages] = useState(() => [...initialPages])
  const [commands, setCommands] = useState(() => [...initialCommands])
  const [operatorMappings, setOperatorMappings] = useState(() =>
    initialOperatorMappings.map((s) => ({ ...s, rows: [...s.rows] })),
  )
  const [viewerMappings, setViewerMappings] = useState(() =>
    initialViewerMappings.map((s) => ({ ...s, rows: [...s.rows] })),
  )

  const pagesRef = useRef(pages)
  useEffect(() => {
    pagesRef.current = pages
  }, [pages])

  const addUser = useCallback((u) => {
    setUsers((prev) => [
      ...prev,
      { ...u, id: nextNumericId(prev.map((x) => x.id)) },
    ])
  }, [])

  const updateUser = useCallback((id, patch) => {
    setUsers((prev) =>
      prev.map((x) => (x.id === id ? { ...x, ...patch } : x)),
    )
  }, [])

  const deleteUser = useCallback((id) => {
    setUsers((prev) => prev.filter((x) => x.id !== id))
  }, [])

  const addGesture = useCallback((g) => {
    setGestures((prev) => {
      const gestureId = nextPrefixedId(
        'G',
        prev.map((x) => x.gestureId),
      )
      const numericLabels = prev
        .map((x) => parseInt(x.label, 10))
        .filter((n) => !Number.isNaN(n))
      const autoLabel = String(
        numericLabels.length ? Math.max(...numericLabels) + 1 : prev.length + 1,
      )
      const label =
        g.label !== undefined && g.label.trim() !== ''
          ? g.label.trim()
          : autoLabel
      return [
        ...prev,
        {
          gestureName: g.gestureName,
          symbol: g.symbol,
          gestureId,
          label,
        },
      ]
    })
  }, [])

  const updateGesture = useCallback((gestureId, patch) => {
    setGestures((prev) =>
      prev.map((x) => (x.gestureId === gestureId ? { ...x, ...patch } : x)),
    )
  }, [])

  const deleteGesture = useCallback((gestureId) => {
    setGestures((prev) => prev.filter((x) => x.gestureId !== gestureId))
  }, [])

  const addPage = useCallback((p) => {
    setPages((prev) => {
      const pageId = nextPrefixedId(
        'P',
        prev.map((x) => x.pageId),
      )
      return [...prev, { ...p, pageId }]
    })
  }, [])

  const updatePage = useCallback((pageId, patch) => {
    setPages((prev) =>
      prev.map((x) => (x.pageId === pageId ? { ...x, ...patch } : x)),
    )
    if (patch.pageName !== undefined) {
      setCommands((prev) =>
        prev.map((c) =>
          c.pageId === pageId ? { ...c, pageName: patch.pageName } : c,
        ),
      )
    }
  }, [])

  const deletePage = useCallback((pageId) => {
    setCommands((prev) => prev.filter((c) => c.pageId !== pageId))
    setPages((prev) => prev.filter((p) => p.pageId !== pageId))
  }, [])

  const addCommand = useCallback((c) => {
    setCommands((prev) => {
      const page = pagesRef.current.find((p) => p.pageId === c.pageId)
      const pageName = page?.pageName ?? ''
      const commandId = nextPrefixedId(
        'C',
        prev.map((x) => x.commandId),
      )
      return [...prev, { ...c, commandId, pageName }]
    })
  }, [])

  const updateCommand = useCallback((commandId, patch) => {
    setCommands((prev) =>
      prev.map((x) => {
        if (x.commandId !== commandId) return x
        const next = { ...x, ...patch }
        if (patch.pageId !== undefined) {
          const p = pagesRef.current.find((pg) => pg.pageId === next.pageId)
          if (p) next.pageName = p.pageName
        }
        return next
      }),
    )
  }, [])

  const deleteCommand = useCallback((commandId) => {
    setCommands((prev) => prev.filter((c) => c.commandId !== commandId))
  }, [])

  const setMappings = useCallback((role, updater) => {
    if (role === 'operator') setOperatorMappings(updater)
    else setViewerMappings(updater)
  }, [])

  const addMappingRow = useCallback(
    (role, sectionTitle, row) => {
      const full = { ...row, id: newMappingRowId() }
      setMappings(role, (sections) =>
        patchMappingSections(sections, sectionTitle, (rows) => [...rows, full]),
      )
    },
    [setMappings],
  )

  const updateMappingRow = useCallback(
    (role, sectionTitle, rowId, patch) => {
      setMappings(role, (sections) =>
        patchMappingSections(sections, sectionTitle, (rows) =>
          rows.map((r) => (r.id === rowId ? { ...r, ...patch } : r)),
        ),
      )
    },
    [setMappings],
  )

  const deleteMappingRow = useCallback(
    (role, sectionTitle, rowId) => {
      setMappings(role, (sections) =>
        patchMappingSections(sections, sectionTitle, (rows) =>
          rows.filter((r) => r.id !== rowId),
        ),
      )
    },
    [setMappings],
  )

  const value = useMemo(
    () => ({
      users,
      addUser,
      updateUser,
      deleteUser,
      gestures,
      addGesture,
      updateGesture,
      deleteGesture,
      pages,
      addPage,
      updatePage,
      deletePage,
      commands,
      addCommand,
      updateCommand,
      deleteCommand,
      operatorMappings,
      viewerMappings,
      addMappingRow,
      updateMappingRow,
      deleteMappingRow,
    }),
    [
      users,
      addUser,
      updateUser,
      deleteUser,
      gestures,
      addGesture,
      updateGesture,
      deleteGesture,
      pages,
      addPage,
      updatePage,
      deletePage,
      commands,
      addCommand,
      updateCommand,
      deleteCommand,
      operatorMappings,
      viewerMappings,
      addMappingRow,
      updateMappingRow,
      deleteMappingRow,
    ],
  )

  return (
    <AdminDataContext.Provider value={value}>{children}</AdminDataContext.Provider>
  )
}

/** @see AdminDataProvider */
// eslint-disable-next-line react-refresh/only-export-components -- hook colocated with provider
export function useAdminData() {
  const ctx = useContext(AdminDataContext)
  if (!ctx) throw new Error('useAdminData must be used within AdminDataProvider')
  return ctx
}
