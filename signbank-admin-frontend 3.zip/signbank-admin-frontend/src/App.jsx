import { Navigate, Route, Routes } from 'react-router-dom'
import { AdminLogin } from './pages/AdminLogin'
import { AdminDashboard } from './pages/AdminDashboard'
import { AnalyticsPage } from './pages/AnalyticsPage'
import { Home } from './pages/Home'
import { ManageCommands } from './pages/ManageCommands'
import { ManageGestures } from './pages/ManageGestures'
import { ManageMappingPicker } from './pages/ManageMappingPicker'
import { ManageMappingRole } from './pages/ManageMappingRole'
import { ManagePages } from './pages/ManagePages'
import { ManageUsers } from './pages/ManageUsers'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/admin/users" element={<ManageUsers />} />
      <Route path="/admin/gestures" element={<ManageGestures />} />
      <Route path="/admin/commands" element={<ManageCommands />} />
      <Route path="/admin/pages" element={<ManagePages />} />
      <Route path="/admin/mapping" element={<ManageMappingPicker />} />
      <Route path="/admin/mapping/:role" element={<ManageMappingRole />} />
      <Route path="/admin/analytics" element={<AnalyticsPage />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
