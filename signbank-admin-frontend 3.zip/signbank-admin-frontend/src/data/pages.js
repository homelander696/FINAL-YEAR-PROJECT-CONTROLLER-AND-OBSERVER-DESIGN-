export const pages = [
  {
    pageId: 'P001',
    pageName: 'Operator Dashboard',
    roleId: 'R001',
  },
  {
    pageId: 'P002',
    pageName: 'Operator Balance Page',
    roleId: 'R001',
  },
  {
    pageId: 'P003',
    pageName: 'Viewer Dashboard',
    roleId: 'R002',
  },
  {
    pageId: 'P004',
    pageName: 'Viewer Log Page',
    roleId: 'R002',
  },
  {
    pageId: 'P005',
    pageName: 'Viewer Analytics Page',
    roleId: 'R002',
  },
]
