export const operatorMappings = [
  {
    sectionTitle: 'Operator DashBoard',
    rows: [
      {
        id: 'o-db-1',
        command: 'Check Balance',
        gesture: 'Two Fingers',
        gestureSymbol: '✌️',
      },
      {
        id: 'o-db-2',
        command: 'Logout',
        gesture: 'Fist',
        gestureSymbol: '✊',
      },
    ],
  },
  {
    sectionTitle: 'Operator Balance Page',
    rows: [
      {
        id: 'o-bp-1',
        command: 'Back',
        gesture: 'Fist',
        gestureSymbol: '✊',
      },
    ],
  },
]

export const viewerMappings = [
  {
    sectionTitle: 'Viewer DashBoard',
    rows: [
      {
        id: 'v-db-1',
        command: 'Recent Gesture Logs',
        gesture: 'One Finger',
        gestureSymbol: '☝️',
      },
      {
        id: 'v-db-2',
        command: 'Analytics',
        gesture: 'Two Finger',
        gestureSymbol: '✌️',
      },
      {
        id: 'v-db-3',
        command: 'Logout',
        gesture: 'Fist',
        gestureSymbol: '✊',
      },
    ],
  },
  {
    sectionTitle: 'Viewer Log Page',
    rows: [
      {
        id: 'v-lp-1',
        command: 'Back',
        gesture: 'Fist',
        gestureSymbol: '✊',
      },
    ],
  },
  {
    sectionTitle: 'Viewer analytics Page',
    rows: [
      {
        id: 'v-ap-1',
        command: 'Back',
        gesture: 'Fist',
        gestureSymbol: '✊',
      },
    ],
  },
]
