import { SquarePen, Trash2 } from 'lucide-react'

export function DataTable({
  columns,
  rows,
  getRowKey,
  showActions = true,
  actionsHeader = 'ACTIONS',
  className = '',
  onEdit,
  onDelete,
}) {
  return (
    <div
      className={`overflow-x-auto rounded-xl border border-neutral-200 bg-white ${className}`}
    >
      <table className="w-full min-w-[640px] border-collapse text-left text-sm">
        <thead>
          <tr className="border-b border-neutral-200 bg-neutral-50/80">
            {columns.map((col) => (
              <th
                key={col.id}
                scope="col"
                className={`px-4 py-3 text-xs font-bold uppercase tracking-wide text-neutral-900 ${col.headerClassName ?? ''}`}
              >
                {col.header}
              </th>
            ))}
            {showActions ? (
              <th
                scope="col"
                className="px-4 py-3 text-right text-xs font-bold uppercase tracking-wide text-neutral-900"
              >
                {actionsHeader}
              </th>
            ) : null}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr
              key={getRowKey(row, index)}
              className="border-b border-neutral-100 last:border-0"
            >
              {columns.map((col) => (
                <td
                  key={col.id}
                  className={`px-4 py-4 text-neutral-800 ${col.cellClassName ?? ''}`}
                >
                  {col.cell(row)}
                </td>
              ))}
              {showActions ? (
                <td className="px-4 py-4">
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      aria-label="Edit"
                      className="rounded-md p-1.5 text-neutral-700 hover:bg-neutral-100"
                      onClick={() => onEdit?.(row)}
                    >
                      <SquarePen className="h-5 w-5" strokeWidth={1.5} />
                    </button>
                    <button
                      type="button"
                      aria-label="Delete"
                      className="rounded-md p-1.5 text-neutral-700 hover:bg-neutral-100"
                      onClick={() => onDelete?.(row)}
                    >
                      <Trash2 className="h-5 w-5" strokeWidth={1.5} />
                    </button>
                  </div>
                </td>
              ) : null}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
