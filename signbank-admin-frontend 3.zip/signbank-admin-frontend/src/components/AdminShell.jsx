export function AdminShell({
  children,
  variant = 'default',
  className = '',
}) {
  const bg =
    variant === 'gradient'
      ? 'min-h-screen bg-gradient-to-b from-sky-100/80 to-white'
      : 'min-h-screen bg-[var(--color-page-bg)]'

  return (
    <div className={`${bg} font-sans text-neutral-900 ${className}`}>
      {children}
    </div>
  )
}
