import { Modal } from './Modal'
import { PrimaryButton } from './PrimaryButton'

export function ConfirmDialog({
  open,
  title,
  message,
  confirmLabel = 'Delete',
  onConfirm,
  onCancel,
}) {
  return (
    <Modal
      open={open}
      title={title}
      onClose={onCancel}
      footer={
        <>
          <button
            type="button"
            className="rounded-full border border-neutral-300 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-50"
            onClick={onCancel}
          >
            Cancel
          </button>
          <PrimaryButton
            type="button"
            className="bg-red-600 hover:bg-red-700"
            onClick={onConfirm}
          >
            {confirmLabel}
          </PrimaryButton>
        </>
      }
    >
      <p className="text-sm text-neutral-600">{message}</p>
    </Modal>
  )
}
