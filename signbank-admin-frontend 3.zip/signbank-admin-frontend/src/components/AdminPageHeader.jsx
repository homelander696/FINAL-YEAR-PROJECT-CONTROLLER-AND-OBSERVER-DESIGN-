export function AdminPageHeader({
  breadcrumb,
  title,
  subtitle,
  right,
}) {
  return (
    <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
      <div>
        <p className="text-xs font-medium tracking-wide text-neutral-400">
          {breadcrumb}
        </p>
        <h1 className="mt-1 text-3xl font-bold tracking-tight text-neutral-900">
          {title}
        </h1>
        <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
      </div>
      {right ? <div className="shrink-0 sm:pt-6">{right}</div> : null}
    </div>
  )
}
