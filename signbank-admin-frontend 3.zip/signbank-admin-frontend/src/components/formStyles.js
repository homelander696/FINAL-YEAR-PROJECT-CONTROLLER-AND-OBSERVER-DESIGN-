export const formLabelClass = 'text-xs font-medium text-neutral-600'
export const formInputClass =
  'mt-1 w-full rounded-xl border border-neutral-200 bg-white px-3 py-2 text-sm text-neutral-900 placeholder:text-neutral-400 focus:border-[var(--color-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/20'
export const formSelectClass = formInputClass
