/** Next id like G001, C012, P003 from existing prefixed ids. */
export function nextPrefixedId(prefix, existingIds) {
  const re = new RegExp(`^${prefix}(\\d+)$`, 'i')
  let max = 0
  for (const id of existingIds) {
    const m = id.match(re)
    if (m) max = Math.max(max, parseInt(m[1], 10))
  }
  return `${prefix}${String(max + 1).padStart(3, '0')}`
}

export function nextNumericId(existingIds) {
  const nums = existingIds
    .map((id) => parseInt(id, 10))
    .filter((n) => !Number.isNaN(n))
  const n = nums.length ? Math.max(...nums) + 1 : 1
  return String(n)
}
