import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ArrowLeft, Landmark } from 'lucide-react'
import { AdminShell } from '../components/AdminShell'

export function AdminLogin() {
  const navigate = useNavigate()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    navigate('/admin')
  }

  return (
    <AdminShell variant="gradient">
      <p className="px-6 pt-4 text-xs text-neutral-400">Admin Login</p>
      <div className="mx-auto flex max-w-lg flex-col px-6 pb-16 pt-6">
        <div className="mb-10 flex items-start justify-between gap-4">
          <Link
            to="/"
            className="inline-flex items-center gap-1 text-sm font-medium text-[var(--color-primary)]"
          >
            <ArrowLeft className="h-4 w-4" />
            Back
          </Link>
          <div className="flex flex-1 flex-col items-center text-center">
            <h1 className="text-2xl font-bold text-neutral-900 sm:text-3xl">
              SignBank{' '}
              <span className="font-bold">
                Enterprise<span className="text-[var(--color-primary)]">.</span>
              </span>
            </h1>
            <p className="mt-2 max-w-md text-sm text-neutral-500">
              Gesture Driven Smart Interaction Platform
            </p>
          </div>
          <div
            className="flex h-12 w-12 items-center justify-center rounded-lg border border-neutral-200 bg-white text-neutral-800 shadow-sm"
            aria-hidden
          >
            <Landmark className="h-7 w-7" strokeWidth={1.5} />
          </div>
        </div>

        <div className="rounded-2xl border border-neutral-100 bg-white p-8 shadow-lg">
          <h2 className="text-lg font-bold text-neutral-900">Admin Login</h2>
          <p className="mt-1 text-sm text-neutral-500">
            Use gestures to control the form.
          </p>
          <form onSubmit={handleSubmit} className="mt-8 space-y-6">
            <div className="text-left">
              <label
                htmlFor="username"
                className="text-xs font-medium text-neutral-600"
              >
                Username
              </label>
              <input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter your username"
                autoComplete="username"
                className="mt-2 w-full rounded-xl border border-neutral-200 bg-neutral-50/50 px-4 py-3 text-sm text-neutral-900 placeholder:text-neutral-400 focus:border-[var(--color-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/20"
              />
            </div>
            <div className="text-left">
              <label
                htmlFor="password"
                className="text-xs font-medium text-neutral-600"
              >
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Show your password."
                autoComplete="current-password"
                className="mt-2 w-full rounded-xl border border-neutral-200 bg-neutral-50/50 px-4 py-3 text-sm text-neutral-900 placeholder:text-neutral-400 focus:border-[var(--color-primary)] focus:outline-none focus:ring-2 focus:ring-[var(--color-primary)]/20"
              />
            </div>
            <button
              type="submit"
              className="w-full rounded-full bg-[var(--color-primary)] py-3.5 text-sm font-bold text-white shadow-md transition hover:bg-[var(--color-primary-hover)]"
            >
              Sign In
            </button>
          </form>
        </div>
      </div>
    </AdminShell>
  )
}
