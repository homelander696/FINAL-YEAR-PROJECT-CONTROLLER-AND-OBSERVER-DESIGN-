import { useState } from 'react'
import { Navigate, useParams } from 'react-router-dom'
import { SquarePen, Trash2 } from 'lucide-react'
import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { ConfirmDialog } from '../components/ConfirmDialog'
import { Modal } from '../components/Modal'
import { PrimaryButton } from '../components/PrimaryButton'
import { formInputClass, formLabelClass } from '../components/formStyles'
import { useAdminData } from '../context/AdminDataContext'

const emptyRow = { command: '', gesture: '', gestureSymbol: '' }

function SectionTable({ section, onEdit, onDelete, onAdd }) {
  return (
    <div className="rounded-xl border border-neutral-300 bg-white p-4 shadow-sm">
      <div className="mb-4 flex flex-col items-center justify-between gap-3 sm:flex-row">
        <h3 className="text-center text-base font-semibold text-neutral-900 sm:flex-1">
          {section.sectionTitle}
        </h3>
        <PrimaryButton
          type="button"
          className="shrink-0 px-4 py-2 text-xs"
          onClick={() => onAdd(section.sectionTitle)}
        >
          + Add row
        </PrimaryButton>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[400px] border-collapse border border-neutral-300 text-sm">
          <thead>
            <tr className="bg-[#d9d9d9]">
              <th className="border border-neutral-300 px-3 py-3 text-center font-bold text-neutral-900">
                Command
              </th>
              <th className="border border-neutral-300 px-3 py-3 text-center font-bold text-neutral-900">
                Gesture
              </th>
              <th className="border border-neutral-300 px-3 py-3 text-center font-bold text-neutral-900">
                Gesture Symbol
              </th>
              <th className="border border-neutral-300 px-3 py-3 text-right text-xs font-bold uppercase text-neutral-900">
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {section.rows.length === 0 ? (
              <tr>
                <td
                  colSpan={4}
                  className="border border-neutral-300 bg-neutral-50 px-3 py-6 text-center text-neutral-500"
                >
                  No mappings yet. Use &quot;+ Add row&quot;.
                </td>
              </tr>
            ) : (
              section.rows.map((row) => (
                <tr key={row.id} className="bg-neutral-100">
                  <td className="border border-neutral-300 px-3 py-3 text-neutral-800">
                    {row.command}
                  </td>
                  <td className="border border-neutral-300 px-3 py-3 text-center font-semibold text-neutral-900">
                    {row.gesture}
                  </td>
                  <td className="border border-neutral-300 px-3 py-3 text-center text-2xl">
                    {row.gestureSymbol}
                  </td>
                  <td className="border border-neutral-300 px-3 py-3">
                    <div className="flex justify-end gap-2">
                      <button
                        type="button"
                        aria-label="Edit"
                        className="rounded-md p-1.5 text-neutral-700 hover:bg-neutral-200/80"
                        onClick={() => onEdit(row)}
                      >
                        <SquarePen className="h-5 w-5" strokeWidth={1.5} />
                      </button>
                      <button
                        type="button"
                        aria-label="Delete"
                        className="rounded-md p-1.5 text-neutral-700 hover:bg-neutral-200/80"
                        onClick={() => onDelete(row)}
                      >
                        <Trash2 className="h-5 w-5" strokeWidth={1.5} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export function ManageMappingRole() {
  const { role: roleParam } = useParams()
  const {
    operatorMappings,
    viewerMappings,
    addMappingRow,
    updateMappingRow,
    deleteMappingRow,
  } = useAdminData()

  const [modalOpen, setModalOpen] = useState(false)
  const [sectionTitle, setSectionTitle] = useState('')
  const [editingRowId, setEditingRowId] = useState(null)
  const [form, setForm] = useState(emptyRow)
  const [deleteTarget, setDeleteTarget] = useState(null)

  if (roleParam !== 'operator' && roleParam !== 'viewer') {
    return <Navigate to="/admin/mapping" replace />
  }
  const role = roleParam

  const sections = role === 'operator' ? operatorMappings : viewerMappings
  const roleTitle = role === 'operator' ? 'Operator' : 'Viewer'

  function openAdd(title) {
    setSectionTitle(title)
    setEditingRowId(null)
    setForm(emptyRow)
    setModalOpen(true)
  }

  function openEdit(row, title) {
    setSectionTitle(title)
    setEditingRowId(row.id)
    setForm({
      command: row.command,
      gesture: row.gesture,
      gestureSymbol: row.gestureSymbol,
    })
    setModalOpen(true)
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (
      !form.command.trim() ||
      !form.gesture.trim() ||
      !form.gestureSymbol.trim()
    )
      return
    if (editingRowId) {
      updateMappingRow(role, sectionTitle, editingRowId, {
        command: form.command.trim(),
        gesture: form.gesture.trim(),
        gestureSymbol: form.gestureSymbol.trim(),
      })
    } else {
      addMappingRow(role, sectionTitle, {
        command: form.command.trim(),
        gesture: form.gesture.trim(),
        gestureSymbol: form.gestureSymbol.trim(),
      })
    }
    setModalOpen(false)
  }

  return (
    <AdminShell>
      <div className="mx-auto max-w-4xl px-6 py-10">
        <AdminPageHeader
          breadcrumb="Admin - Manage mappings"
          title="Manage Mapping"
          subtitle="View and edit mapped Gestures."
        />
        <div className="rounded-2xl border border-neutral-300 bg-white p-8 shadow-sm">
          <h2 className="mb-8 text-center text-2xl font-bold text-neutral-900">
            {roleTitle}
          </h2>
          <div className="space-y-8">
            {sections.map((section) => (
              <SectionTable
                key={section.sectionTitle}
                section={section}
                onAdd={openAdd}
                onEdit={(row) => openEdit(row, section.sectionTitle)}
                onDelete={(row) =>
                  setDeleteTarget({ sectionTitle: section.sectionTitle, row })
                }
              />
            ))}
          </div>
        </div>
      </div>

      <Modal
        open={modalOpen}
        title={editingRowId ? 'Edit mapping' : 'Add mapping'}
        onClose={() => setModalOpen(false)}
        footer={
          <>
            <button
              type="button"
              className="rounded-full border border-neutral-300 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-50"
              onClick={() => setModalOpen(false)}
            >
              Cancel
            </button>
            <PrimaryButton type="submit" form="mapping-row-form">
              {editingRowId ? 'Save' : 'Create'}
            </PrimaryButton>
          </>
        }
      >
        <p className="mb-4 text-left text-xs text-neutral-500">
          Section:{' '}
          <span className="font-medium text-neutral-700">{sectionTitle}</span>
        </p>
        <form
          id="mapping-row-form"
          className="space-y-4"
          onSubmit={handleSubmit}
        >
          <div className="text-left">
            <label htmlFor="map-cmd" className={formLabelClass}>
              Command
            </label>
            <input
              id="map-cmd"
              value={form.command}
              onChange={(e) =>
                setForm((f) => ({ ...f, command: e.target.value }))
              }
              className={formInputClass}
              required
            />
          </div>
          <div className="text-left">
            <label htmlFor="map-gesture" className={formLabelClass}>
              Gesture
            </label>
            <input
              id="map-gesture"
              value={form.gesture}
              onChange={(e) =>
                setForm((f) => ({ ...f, gesture: e.target.value }))
              }
              className={formInputClass}
              required
            />
          </div>
          <div className="text-left">
            <label htmlFor="map-symbol" className={formLabelClass}>
              Gesture symbol
            </label>
            <input
              id="map-symbol"
              value={form.gestureSymbol}
              onChange={(e) =>
                setForm((f) => ({ ...f, gestureSymbol: e.target.value }))
              }
              className={formInputClass}
              required
              placeholder="✌️"
            />
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete mapping"
        message={
          deleteTarget
            ? `Remove mapping for "${deleteTarget.row.command}" in ${deleteTarget.sectionTitle}?`
            : ''
        }
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) {
            deleteMappingRow(
              role,
              deleteTarget.sectionTitle,
              deleteTarget.row.id,
            )
          }
          setDeleteTarget(null)
        }}
      />
    </AdminShell>
  )
}
