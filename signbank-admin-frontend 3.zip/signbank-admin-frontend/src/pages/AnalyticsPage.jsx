import { Activity, Check, Hash, Users } from 'lucide-react'
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { AdminShell } from '../components/AdminShell'
import { analyticsStats, operationsOverTime } from '../data/analytics'

const iconMap = {
  hash: Hash,
  check: Check,
  users: Users,
  pulse: Activity,
}

const toneIconBg = {
  green: 'bg-emerald-500',
  blue: 'bg-sky-500',
  purple: 'bg-violet-500',
  amber: 'bg-amber-500',
}

export function AnalyticsPage() {
  return (
    <AdminShell variant="gradient">
      <p className="px-6 pt-4 text-xs text-neutral-400">Admin analytics Page</p>
      <div className="mx-auto max-w-6xl px-6 pb-16 pt-2">
        <div className="rounded-2xl bg-white p-8 shadow-lg ring-1 ring-black/5">
          <h1 className="text-3xl font-bold text-neutral-900">Analytics</h1>

          <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {analyticsStats.map((stat) => {
              const Icon = iconMap[stat.icon]
              const circle = toneIconBg[stat.iconTone]
              return (
                <div
                  key={stat.id}
                  className="flex gap-3 rounded-xl bg-[var(--color-dark-card)] p-4 text-left shadow-inner"
                >
                  <div
                    className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-white ${circle}`}
                  >
                    <Icon className="h-5 w-5" strokeWidth={2} />
                  </div>
                  <div>
                    <p className="text-xs text-neutral-400">{stat.label}</p>
                    <p className="mt-1 text-2xl font-bold text-white">
                      {stat.value}
                    </p>
                  </div>
                </div>
              )
            })}
          </div>

          <div className="mt-6 rounded-xl bg-[var(--color-dark-card)] p-6 shadow-inner">
            <h2 className="text-sm font-medium text-neutral-200">
              Operations Over Time
            </h2>
            <div className="mt-4 h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={operationsOverTime}
                  margin={{ top: 8, right: 12, left: 0, bottom: 8 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#374151"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="time"
                    tick={{ fill: '#9ca3af', fontSize: 12 }}
                    axisLine={{ stroke: '#4b5563' }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fill: '#9ca3af', fontSize: 12 }}
                    axisLine={false}
                    tickLine={false}
                    domain={[0, 600]}
                    ticks={[0, 150, 300, 450, 600]}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1f2937',
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      color: '#f9fafb',
                    }}
                    labelStyle={{ color: '#9ca3af' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="operations"
                    stroke="var(--color-chart-line)"
                    strokeWidth={2}
                    dot={{
                      r: 4,
                      fill: '#fff',
                      stroke: 'var(--color-chart-line)',
                      strokeWidth: 2,
                    }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </AdminShell>
  )
}
