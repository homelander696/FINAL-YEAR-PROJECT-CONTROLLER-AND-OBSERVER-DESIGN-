import { useState } from 'react'
import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { ConfirmDialog } from '../components/ConfirmDialog'
import { DataTable } from '../components/DataTable'
import { Modal } from '../components/Modal'
import { PrimaryButton } from '../components/PrimaryButton'
import {
  formInputClass,
  formLabelClass,
  formSelectClass,
} from '../components/formStyles'
import { useAdminData } from '../context/AdminDataContext'

const emptyForm = {
  commandName: '',
  commandDescription: '',
  pageId: '',
}

export function ManageCommands() {
  const { commands, pages, addCommand, updateCommand, deleteCommand } =
    useAdminData()
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [deleteTarget, setDeleteTarget] = useState(null)

  function openCreate() {
    setEditingId(null)
    setForm({
      ...emptyForm,
      pageId: pages[0]?.pageId ?? '',
    })
    setModalOpen(true)
  }

  function openEdit(c) {
    setEditingId(c.commandId)
    setForm({
      commandName: c.commandName,
      commandDescription: c.commandDescription,
      pageId: c.pageId,
    })
    setModalOpen(true)
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.commandName.trim() || !form.pageId) return
    if (editingId) {
      updateCommand(editingId, {
        commandName: form.commandName.trim(),
        commandDescription: form.commandDescription.trim(),
        pageId: form.pageId,
      })
    } else {
      addCommand({
        commandName: form.commandName.trim(),
        commandDescription: form.commandDescription.trim(),
        pageId: form.pageId,
      })
    }
    setModalOpen(false)
  }

  const selectedPageName =
    pages.find((p) => p.pageId === form.pageId)?.pageName ?? '—'

  return (
    <AdminShell>
      <div className="mx-auto max-w-7xl px-6 py-8">
        <AdminPageHeader
          breadcrumb="Admin - Manage Commands"
          title="Manage Commands"
          subtitle="View and edit command"
          right={
            <PrimaryButton onClick={openCreate} disabled={pages.length === 0}>
              + Add Commands
            </PrimaryButton>
          }
        />
        {pages.length === 0 ? (
          <p className="mb-4 text-sm text-amber-700">
            Add at least one page before creating commands.
          </p>
        ) : null}
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
          <DataTable
            className="rounded-none border-0 shadow-none"
            rows={commands}
            getRowKey={(r) => r.commandId}
            columns={[
              { id: 'cid', header: 'Command id', cell: (r) => r.commandId },
              {
                id: 'cname',
                header: 'Command name',
                cell: (r) => r.commandName,
              },
              {
                id: 'desc',
                header: 'Command description',
                cell: (r) => r.commandDescription,
              },
              {
                id: 'pid',
                header: (
                  <span className="inline-flex items-center gap-1.5">
                    <span
                      className="inline-block h-1.5 w-1.5 rounded-full bg-red-500"
                      aria-hidden
                    />
                    Page id
                  </span>
                ),
                cell: (r) => r.pageId,
              },
              {
                id: 'pname',
                header: 'Page name',
                cell: (r) => r.pageName,
              },
            ]}
            onEdit={openEdit}
            onDelete={setDeleteTarget}
          />
        </div>
      </div>

      <Modal
        open={modalOpen}
        title={editingId ? 'Edit command' : 'Add command'}
        onClose={() => setModalOpen(false)}
        footer={
          <>
            <button
              type="button"
              className="rounded-full border border-neutral-300 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-50"
              onClick={() => setModalOpen(false)}
            >
              Cancel
            </button>
            <PrimaryButton type="submit" form="command-form">
              {editingId ? 'Save' : 'Create'}
            </PrimaryButton>
          </>
        }
      >
        <form id="command-form" className="space-y-4" onSubmit={handleSubmit}>
          {editingId ? (
            <p className="text-left text-xs text-neutral-500">
              Command id:{' '}
              <span className="font-mono font-medium text-neutral-800">
                {editingId}
              </span>
            </p>
          ) : null}
          <div className="text-left">
            <label htmlFor="cmd-name" className={formLabelClass}>
              Command name
            </label>
            <input
              id="cmd-name"
              value={form.commandName}
              onChange={(e) =>
                setForm((f) => ({ ...f, commandName: e.target.value }))
              }
              className={formInputClass}
              required
            />
          </div>
          <div className="text-left">
            <label htmlFor="cmd-desc" className={formLabelClass}>
              Command description
            </label>
            <textarea
              id="cmd-desc"
              value={form.commandDescription}
              onChange={(e) =>
                setForm((f) => ({ ...f, commandDescription: e.target.value }))
              }
              className={`${formInputClass} min-h-[88px] resize-y`}
              rows={3}
            />
          </div>
          <div className="text-left">
            <label htmlFor="cmd-page" className={formLabelClass}>
              Page
            </label>
            <select
              id="cmd-page"
              value={form.pageId}
              onChange={(e) =>
                setForm((f) => ({ ...f, pageId: e.target.value }))
              }
              className={formSelectClass}
              required
            >
              {pages.map((p) => (
                <option key={p.pageId} value={p.pageId}>
                  {p.pageId} — {p.pageName}
                </option>
              ))}
            </select>
            <p className="mt-1 text-xs text-neutral-500">
              Page name: <span className="font-medium">{selectedPageName}</span>
            </p>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete command"
        message={
          deleteTarget
            ? `Remove ${deleteTarget.commandName} (${deleteTarget.commandId})?`
            : ''
        }
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) deleteCommand(deleteTarget.commandId)
          setDeleteTarget(null)
        }}
      />
    </AdminShell>
  )
}
