import { Link } from 'react-router-dom'
import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'

export function ManageMappingPicker() {
  return (
    <AdminShell variant="gradient">
      <div className="mx-auto max-w-3xl px-6 py-10">
        <AdminPageHeader
          breadcrumb="Admin - Manage mappings"
          title="Manage Mapping"
          subtitle="View and edit mapped Gestures."
        />
        <div className="flex min-h-[280px] items-center justify-center rounded-2xl border-2 border-neutral-400 bg-white px-8 py-16 shadow-sm">
          <div className="flex flex-wrap items-center justify-center gap-8">
            <Link
              to="/admin/mapping/operator"
              className="rounded-full bg-neutral-200 px-14 py-4 text-center text-base font-medium text-neutral-900 shadow-sm transition hover:bg-neutral-300"
            >
              Operator
            </Link>
            <Link
              to="/admin/mapping/viewer"
              className="rounded-full bg-neutral-200 px-14 py-4 text-center text-base font-medium text-neutral-900 shadow-sm transition hover:bg-neutral-300"
            >
              Viewer
            </Link>
          </div>
        </div>
      </div>
    </AdminShell>
  )
}
