import { useState } from 'react'
import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { ConfirmDialog } from '../components/ConfirmDialog'
import { DataTable } from '../components/DataTable'
import { Modal } from '../components/Modal'
import { PrimaryButton } from '../components/PrimaryButton'
import { formInputClass, formLabelClass } from '../components/formStyles'
import { useAdminData } from '../context/AdminDataContext'

const emptyForm = { label: '', gestureName: '', symbol: '' }

export function ManageGestures() {
  const { gestures, addGesture, updateGesture, deleteGesture } = useAdminData()
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [deleteTarget, setDeleteTarget] = useState(null)

  function openCreate() {
    setEditingId(null)
    setForm(emptyForm)
    setModalOpen(true)
  }

  function openEdit(g) {
    setEditingId(g.gestureId)
    setForm({
      label: g.label,
      gestureName: g.gestureName,
      symbol: g.symbol,
    })
    setModalOpen(true)
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.gestureName.trim() || !form.symbol.trim()) return
    if (editingId) {
      updateGesture(editingId, {
        label: form.label.trim() || form.gestureName,
        gestureName: form.gestureName,
        symbol: form.symbol,
      })
    } else {
      addGesture({
        gestureName: form.gestureName,
        symbol: form.symbol,
        ...(form.label.trim() ? { label: form.label.trim() } : {}),
      })
    }
    setModalOpen(false)
  }

  return (
    <AdminShell>
      <div className="mx-auto max-w-6xl px-6 py-8">
        <AdminPageHeader
          breadcrumb="Admin - Manage Gestures"
          title="Manage Gestures"
          subtitle="View and edit Gestures."
          right={
            <PrimaryButton onClick={openCreate}>+ Add gestures</PrimaryButton>
          }
        />
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
          <DataTable
            className="rounded-none border-0 shadow-none"
            rows={gestures}
            getRowKey={(r) => r.gestureId}
            columns={[
              { id: 'label', header: 'Label', cell: (r) => r.label },
              { id: 'gid', header: 'Gesture id', cell: (r) => r.gestureId },
              {
                id: 'name',
                header: 'Gesture name',
                cell: (r) => r.gestureName,
              },
              {
                id: 'sym',
                header: 'Gesture symbol',
                cell: (r) => (
                  <span className="text-lg" title={r.gestureName}>
                    {r.symbol}
                  </span>
                ),
                cellClassName: 'text-center sm:text-left',
              },
            ]}
            onEdit={openEdit}
            onDelete={setDeleteTarget}
          />
        </div>
      </div>

      <Modal
        open={modalOpen}
        title={editingId ? 'Edit gesture' : 'Add gesture'}
        onClose={() => setModalOpen(false)}
        footer={
          <>
            <button
              type="button"
              className="rounded-full border border-neutral-300 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-50"
              onClick={() => setModalOpen(false)}
            >
              Cancel
            </button>
            <PrimaryButton type="submit" form="gesture-form">
              {editingId ? 'Save' : 'Create'}
            </PrimaryButton>
          </>
        }
      >
        <form id="gesture-form" className="space-y-4" onSubmit={handleSubmit}>
          {editingId ? (
            <p className="text-left text-xs text-neutral-500">
              Gesture id:{' '}
              <span className="font-mono font-medium text-neutral-800">
                {editingId}
              </span>
            </p>
          ) : null}
          <div className="text-left">
            <label htmlFor="g-label" className={formLabelClass}>
              Label (optional)
            </label>
            <input
              id="g-label"
              value={form.label}
              onChange={(e) => setForm((f) => ({ ...f, label: e.target.value }))}
              className={formInputClass}
              placeholder="Auto if empty"
            />
          </div>
          <div className="text-left">
            <label htmlFor="g-name" className={formLabelClass}>
              Gesture name
            </label>
            <input
              id="g-name"
              value={form.gestureName}
              onChange={(e) =>
                setForm((f) => ({ ...f, gestureName: e.target.value }))
              }
              className={formInputClass}
              required
            />
          </div>
          <div className="text-left">
            <label htmlFor="g-symbol" className={formLabelClass}>
              Gesture symbol (emoji)
            </label>
            <input
              id="g-symbol"
              value={form.symbol}
              onChange={(e) => setForm((f) => ({ ...f, symbol: e.target.value }))}
              className={formInputClass}
              required
              placeholder="☝️"
            />
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete gesture"
        message={
          deleteTarget
            ? `Remove ${deleteTarget.gestureName} (${deleteTarget.gestureId})?`
            : ''
        }
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) deleteGesture(deleteTarget.gestureId)
          setDeleteTarget(null)
        }}
      />
    </AdminShell>
  )
}
