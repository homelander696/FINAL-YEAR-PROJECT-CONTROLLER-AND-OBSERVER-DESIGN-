import { Link } from 'react-router-dom'

export function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-50 font-sans">
      <h1 className="text-xl font-semibold text-neutral-800">SignBank Enterprise</h1>
      <Link
        to="/admin/login"
        className="font-medium text-[var(--color-primary)] hover:underline"
      >
        Admin Login
      </Link>
    </div>
  )
}
