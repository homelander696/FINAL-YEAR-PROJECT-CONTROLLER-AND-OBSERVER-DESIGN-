import { Link } from 'react-router-dom'
import { Eye, User, Settings } from 'lucide-react'
import { AdminShell } from '../components/AdminShell'
import { DashboardTile } from '../components/DashboardTile'

export function AdminDashboard() {
  return (
    <AdminShell>
      <p className="px-6 pt-4 text-xs text-neutral-400">Admin Dashboard</p>
      <div className="mx-auto max-w-4xl px-6 pb-16 pt-2">
        <div className="mb-8 flex items-start justify-between gap-4">
          <h1 className="text-3xl font-bold text-neutral-900">Admin Dashboard</h1>
          <Link
            to="/admin/login"
            className="text-base font-medium text-neutral-900 hover:text-[var(--color-primary)]"
          >
            Logout
          </Link>
        </div>

        <div className="rounded-2xl bg-white p-8 shadow-lg ring-1 ring-black/5">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <DashboardTile
              to="/admin/users"
              label="Manage Users"
              icon={Eye}
              tone="mint"
            />
            <DashboardTile
              to="/admin/commands"
              label="Manage Commands"
              icon={User}
              tone="sky"
            />
            <DashboardTile
              to="/admin/gestures"
              label="Manage Gestures"
              icon={User}
              tone="sky"
            />
            <DashboardTile
              to="/admin/pages"
              label="Manage pages"
              icon={User}
              tone="sky"
            />
            <DashboardTile
              to="/admin/analytics"
              label="View Analytics"
              icon={Settings}
              tone="lavender"
            />
            <DashboardTile
              to="/admin/mapping"
              label="Manage Mappings"
              icon={User}
              tone="sky"
            />
          </div>
        </div>
      </div>
    </AdminShell>
  )
}
