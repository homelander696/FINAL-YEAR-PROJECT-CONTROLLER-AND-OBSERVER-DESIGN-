import { useState } from 'react'
import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { ConfirmDialog } from '../components/ConfirmDialog'
import { DataTable } from '../components/DataTable'
import { Modal } from '../components/Modal'
import { PrimaryButton } from '../components/PrimaryButton'
import {
  formInputClass,
  formLabelClass,
  formSelectClass,
} from '../components/formStyles'
import { useAdminData } from '../context/AdminDataContext'

const emptyForm = { pageName: '', roleId: 'R001' }

export function ManagePages() {
  const { pages, addPage, updatePage, deletePage } = useAdminData()
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [deleteTarget, setDeleteTarget] = useState(null)

  function openCreate() {
    setEditingId(null)
    setForm(emptyForm)
    setModalOpen(true)
  }

  function openEdit(p) {
    setEditingId(p.pageId)
    setForm({ pageName: p.pageName, roleId: p.roleId })
    setModalOpen(true)
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.pageName.trim()) return
    if (editingId) {
      updatePage(editingId, {
        pageName: form.pageName.trim(),
        roleId: form.roleId,
      })
    } else {
      addPage({
        pageName: form.pageName.trim(),
        roleId: form.roleId,
      })
    }
    setModalOpen(false)
  }

  return (
    <AdminShell>
      <div className="mx-auto max-w-6xl px-6 py-8">
        <AdminPageHeader
          breadcrumb="Admin - Manage Pages"
          title="Manage Pages"
          subtitle="View and edit Pages."
          right={<PrimaryButton onClick={openCreate}>+ Add Pages</PrimaryButton>}
        />
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
          <DataTable
            className="rounded-none border-0 shadow-none"
            rows={pages}
            getRowKey={(r) => r.pageId}
            columns={[
              {
                id: 'pid',
                header: 'Page id',
                headerClassName: 'text-neutral-500 font-semibold normal-case',
                cell: (r) => (
                  <span className="text-neutral-500">{r.pageId}</span>
                ),
              },
              {
                id: 'pname',
                header: 'Page Name',
                cell: (r) => (
                  <span className="font-semibold text-neutral-900">
                    {r.pageName}
                  </span>
                ),
              },
              {
                id: 'rid',
                header: 'Role id',
                headerClassName: 'text-neutral-500 font-semibold normal-case',
                cell: (r) => (
                  <span className="text-neutral-500">{r.roleId}</span>
                ),
              },
            ]}
            onEdit={openEdit}
            onDelete={setDeleteTarget}
          />
        </div>
      </div>

      <Modal
        open={modalOpen}
        title={editingId ? 'Edit page' : 'Add page'}
        onClose={() => setModalOpen(false)}
        footer={
          <>
            <button
              type="button"
              className="rounded-full border border-neutral-300 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-50"
              onClick={() => setModalOpen(false)}
            >
              Cancel
            </button>
            <PrimaryButton type="submit" form="page-form">
              {editingId ? 'Save' : 'Create'}
            </PrimaryButton>
          </>
        }
      >
        <form id="page-form" className="space-y-4" onSubmit={handleSubmit}>
          {editingId ? (
            <p className="text-left text-xs text-neutral-500">
              Page id:{' '}
              <span className="font-mono font-medium text-neutral-800">
                {editingId}
              </span>
            </p>
          ) : null}
          <div className="text-left">
            <label htmlFor="page-name" className={formLabelClass}>
              Page name
            </label>
            <input
              id="page-name"
              value={form.pageName}
              onChange={(e) =>
                setForm((f) => ({ ...f, pageName: e.target.value }))
              }
              className={formInputClass}
              required
            />
          </div>
          <div className="text-left">
            <label htmlFor="page-role" className={formLabelClass}>
              Role id
            </label>
            <select
              id="page-role"
              value={form.roleId}
              onChange={(e) =>
                setForm((f) => ({ ...f, roleId: e.target.value }))
              }
              className={formSelectClass}
            >
              <option value="R001">R001 — Operator</option>
              <option value="R002">R002 — Viewer</option>
            </select>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete page"
        message={
          deleteTarget
            ? `Remove ${deleteTarget.pageName} (${deleteTarget.pageId})? Commands linked to this page will also be removed.`
            : ''
        }
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) deletePage(deleteTarget.pageId)
          setDeleteTarget(null)
        }}
      />
    </AdminShell>
  )
}
