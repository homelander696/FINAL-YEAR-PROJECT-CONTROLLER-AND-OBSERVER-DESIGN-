import { useState } from 'react'
import { AdminShell } from '../components/AdminShell'
import { AdminPageHeader } from '../components/AdminPageHeader'
import { ConfirmDialog } from '../components/ConfirmDialog'
import { DataTable } from '../components/DataTable'
import { Modal } from '../components/Modal'
import { PrimaryButton } from '../components/PrimaryButton'
import { RoleBadge } from '../components/RoleBadge'
import {
  formInputClass,
  formLabelClass,
  formSelectClass,
} from '../components/formStyles'
import { useAdminData } from '../context/AdminDataContext'

const emptyForm = {
  name: '',
  email: '',
  role: 'Operator',
  mappedGestures: '',
}

export function ManageUsers() {
  const { users, addUser, updateUser, deleteUser } = useAdminData()
  const [modalOpen, setModalOpen] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [deleteTarget, setDeleteTarget] = useState(null)

  function openCreate() {
    setEditingId(null)
    setForm(emptyForm)
    setModalOpen(true)
  }

  function openEdit(u) {
    setEditingId(u.id)
    setForm({
      name: u.name,
      email: u.email,
      role: u.role,
      mappedGestures: u.mappedGestures,
    })
    setModalOpen(true)
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.name.trim() || !form.email.trim()) return
    if (editingId) {
      updateUser(editingId, { ...form })
    } else {
      addUser({ ...form })
    }
    setModalOpen(false)
  }

  return (
    <AdminShell>
      <div className="mx-auto max-w-6xl px-6 py-8">
        <AdminPageHeader
          breadcrumb="Admin - Manage users"
          title="Manage Users"
          subtitle="View and edit user details, and their mapped Gestures."
          right={<PrimaryButton onClick={openCreate}>+ Add User</PrimaryButton>}
        />
        <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white shadow-sm">
          <DataTable
            className="rounded-none border-0 shadow-none"
            rows={users}
            getRowKey={(r) => r.id}
            columns={[
              {
                id: 'name',
                header: 'Name & email',
                cell: (r) => (
                  <div>
                    <div className="font-semibold text-neutral-900">{r.name}</div>
                    <div className="text-sm text-neutral-500">{r.email}</div>
                  </div>
                ),
              },
              {
                id: 'role',
                header: 'Role',
                cell: (r) => <RoleBadge role={r.role} />,
              },
              {
                id: 'gestures',
                header: 'Mapped gestures & commands',
                cell: (r) => r.mappedGestures,
              },
            ]}
            onEdit={openEdit}
            onDelete={setDeleteTarget}
          />
        </div>
      </div>

      <Modal
        open={modalOpen}
        title={editingId ? 'Edit user' : 'Add user'}
        onClose={() => setModalOpen(false)}
        footer={
          <>
            <button
              type="button"
              className="rounded-full border border-neutral-300 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-50"
              onClick={() => setModalOpen(false)}
            >
              Cancel
            </button>
            <PrimaryButton type="submit" form="user-form">
              {editingId ? 'Save' : 'Create'}
            </PrimaryButton>
          </>
        }
      >
        <form id="user-form" className="space-y-4" onSubmit={handleSubmit}>
          <div className="text-left">
            <label htmlFor="user-name" className={formLabelClass}>
              Name
            </label>
            <input
              id="user-name"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              className={formInputClass}
              required
            />
          </div>
          <div className="text-left">
            <label htmlFor="user-email" className={formLabelClass}>
              Email
            </label>
            <input
              id="user-email"
              type="email"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
              className={formInputClass}
              required
            />
          </div>
          <div className="text-left">
            <label htmlFor="user-role" className={formLabelClass}>
              Role
            </label>
            <select
              id="user-role"
              value={form.role}
              onChange={(e) =>
                setForm((f) => ({ ...f, role: e.target.value }))
              }
              className={formSelectClass}
            >
              <option value="Operator">Operator</option>
              <option value="Viewer">Viewer</option>
            </select>
          </div>
          <div className="text-left">
            <label htmlFor="user-gestures" className={formLabelClass}>
              Mapped gestures & commands
            </label>
            <input
              id="user-gestures"
              value={form.mappedGestures}
              onChange={(e) =>
                setForm((f) => ({ ...f, mappedGestures: e.target.value }))
              }
              className={formInputClass}
              placeholder="e.g. Check balance(One finger)"
            />
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        title="Delete user"
        message={
          deleteTarget
            ? `Remove ${deleteTarget.name} (${deleteTarget.email})? This cannot be undone.`
            : ''
        }
        onCancel={() => setDeleteTarget(null)}
        onConfirm={() => {
          if (deleteTarget) deleteUser(deleteTarget.id)
          setDeleteTarget(null)
        }}
      />
    </AdminShell>
  )
}
