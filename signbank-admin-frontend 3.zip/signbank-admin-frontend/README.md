# SignBank Enterprise — Admin Frontend

React admin UI for **SignBank Enterprise** (gesture-driven banking admin). This project is written in **JavaScript** (`.jsx` / `.js`) with Vite.

## What this app includes

### Pages and routes

| Route | Description |
|--------|-------------|
| `/` | Simple home with a link to admin login |
| `/admin/login` | Branded login screen; **Sign In** navigates to the dashboard (no real authentication) |
| `/admin` | Dashboard with six tiles and **Logout** |
| `/admin/users` | Manage users (table + modals) |
| `/admin/gestures` | Manage gestures (emoji symbols, IDs) |
| `/admin/pages` | Manage pages (linked to roles R001/R002) |
| `/admin/commands` | Manage commands (linked to pages) |
| `/admin/mapping` | Choose **Operator** or **Viewer** mapping |
| `/admin/mapping/operator` / `viewer` | Per-section command ↔ gesture ↔ symbol tables |
| `/admin/analytics` | Mock KPI cards and **Operations over time** line chart |

### Features

- **Tailwind CSS v4** via `@tailwindcss/vite` — layout, gradients, cards, tables, buttons.
- **React Router** — client-side routing for all admin URLs.
- **Lucide React** — icons (dashboard tiles, actions, analytics).
- **Recharts** — analytics line chart.
- **In-app CRUD (client-side only)** — data lives in React context (`AdminDataProvider`). You can create, edit, and delete:
  - Users, gestures, pages, commands
  - Mapping rows under Operator / Viewer (add row, edit, delete per section)
- **Modals** for create/edit; **confirm dialog** for deletes.
- **Seed data** in `src/data/*.js` — initial rows match the original UI mockups.

### Important limitations

- **No backend** — nothing is saved to a server; **refreshing the browser resets** all changes.
- **No real login** — credentials are not validated.
- Deleting a **page** also removes **commands** that reference that page (by design in the demo).

## Tech stack

- [Vite](https://vite.dev/) 8
- [React](https://react.dev/) 19 (JavaScript / JSX — no TypeScript)
- [Tailwind CSS](https://tailwindcss.com/) 4
- [React Router](https://reactrouter.com/)
- [Recharts](https://recharts.org/)
- [Lucide](https://lucide.dev/)
- [ESLint](https://eslint.org/) 9 with `eslint-plugin-react` (JSX), React Hooks, and React Refresh

## Project layout

```
src/
  main.jsx              # App entry, BrowserRouter + AdminDataProvider
  App.jsx               # Route definitions
  index.css             # Tailwind import + theme tokens
  components/           # Shell, table, modal, buttons, form class strings
  context/
    AdminDataContext.jsx  # Global state + CRUD helpers
  data/                 # Seed arrays (users, gestures, commands, pages, mappings, analytics)
  pages/                # One file per screen
  utils/
    ids.js              # nextPrefixedId('G'|'C'|'P', …), nextNumericId
vite.config.js
eslint.config.js
```

## Scripts

```bash
npm install    # install dependencies
npm run dev    # dev server (default http://localhost:5173)
npm run build  # production build to dist/
npm run preview # serve dist locally
npm run lint   # ESLint on .js / .jsx
```

## Migration note (TypeScript → JavaScript)

The codebase was converted from TypeScript to JavaScript: `.tsx`/`.ts` files became `.jsx`/`.js`, type annotations and `tsc` were removed, and `package.json` `build` now runs `vite build` only.

## Next steps (if you extend the project)

- Replace `AdminDataContext` calls with **REST or GraphQL** API clients.
- Add **auth** (e.g. JWT, session cookies) and protect `/admin/*` routes.
- Persist data (**localStorage** for demos, or a real database via your API).

---

*Built for the SignBank Enterprise admin UI mockups — manage users, gestures, commands, pages, mappings, and view analytics.*
