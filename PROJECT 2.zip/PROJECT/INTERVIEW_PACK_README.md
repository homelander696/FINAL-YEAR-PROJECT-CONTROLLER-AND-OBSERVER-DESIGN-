# Interview Pack – What’s Included

## 1. Top 20 Interview Questions
**File:** `INTERVIEW_QUESTIONS.md`

Twenty likely interview questions with answers based on the BrainBolt implementation: adaptive algorithm, ping-pong, scoring, idempotency, Redis, leaderboards, streak decay, flow, security, transactions, stateVersion, edge cases, Next.js, design system, consistency, indexes, scaling, and trade-offs.

---

## 2. Draw.io Architecture Diagram
**File:** `BrainBolt_Architecture.drawio`

- Open with **draw.io** (https://app.diagrams.net/) or **VS Code Draw.io extension**.
- Contains: Browser → Next.js Frontend → Express Backend → MongoDB & Redis, with API flow labels and a “How each part was handled” section on the same diagram.
- You can edit, add pages, or **Export as PDF** from draw.io: File → Export as → PDF.

---

## 3. PDF: Architecture & Implementation
**File:** `Architecture_And_Implementation.pdf.html`

- **To get a PDF:** Open this file in **Chrome or Edge** (double-click or drag into browser), then:
  - **Chrome/Edge:** `Ctrl+P` (Windows) or `Cmd+P` (Mac) → Destination: **Save as PDF** → Save.
- The HTML is print-optimized (margins, sections, page-break) so the saved PDF looks good.
- Content: high-level architecture, how each part of the task was handled (adaptive, score, streak, leaderboards, real-time, idempotency, edge cases), backend modules, API summary, cache strategy, frontend implementation, and DB indexes.

---

**Quick checklist for interview day**
- [ ] Read through `INTERVIEW_QUESTIONS.md` at least once.
- [ ] Open `BrainBolt_Architecture.drawio` and be able to explain each box and arrow.
- [ ] Generate PDF from `Architecture_And_Implementation.pdf.html` (Print → Save as PDF) and keep it for reference.
