# BrainBolt – Top 20 Interview Questions & Answers

Use these to prepare for your interview. Answers are based on the actual implementation.

---

## 1. How does your adaptive difficulty algorithm work, and why did you design it this way?

**Answer:** Difficulty is an integer from 1 to 10. On a **correct** answer we only **increase** difficulty if the user has at least 2 correct answers in a row (`streakRequiredToIncrease`). On a **wrong** answer we **decrease** difficulty only if the number of wrong answers in a recent window is greater than 1 (hysteresis band). This avoids ping-pong: alternating correct/wrong no longer flips difficulty every time. Bounds are clamped so difficulty never goes below 1 or above 10.

---

## 2. What is “ping-pong” in the context of adaptive difficulty, and how did you prevent it?

**Answer:** Ping-pong is when difficulty oscillates (e.g. 5 → 6 on correct, 6 → 5 on wrong, repeat). I used two stabilizers: (1) **Minimum streak to increase:** you need 2 correct in a row to move up, so one correct doesn’t immediately bump difficulty. (2) **Hysteresis:** we track recent wrong count in a small window; we only decrease difficulty when `recentWrong > hysteresisBand` (e.g. > 1), so a single wrong answer doesn’t drop the level.

---

## 3. How is the user’s score calculated? What factors does it include?

**Answer:** Score for a correct answer = **baseScore × difficultyWeight × streakMultiplier**. Wrong answers add 0. Difficulty weight is linear in difficulty (e.g. 0.5 to 2.0 for levels 1–10). Streak multiplier is `1 + streak × 0.2`, capped at a max (e.g. 5). So higher difficulty and longer streaks give more points; the cap prevents score from exploding.

---

## 4. How do you ensure the same answer isn’t counted twice (e.g. double-click or network retry)?

**Answer:** Answer submission is **idempotent** using an `answerIdempotencyKey` (e.g. `userId + questionId + timestamp` or a UUID). We store it in `AnswerLog` with a unique index on `(userId, idempotencyKey)`. A duplicate request with the same key finds the existing log and returns the same result without updating streak or score again.

---

## 5. Why did you use Redis in addition to MongoDB?

**Answer:** Redis is used as a **cache** to reduce DB load and latency: (1) **User state** – so we don’t read UserState from MongoDB on every “next question” request. (2) **Question pools per difficulty** – list of question IDs by difficulty. (3) **Leaderboards** – top-N by score and by streak, with a short TTL. We invalidate user state and leaderboard caches on every answer so the next request sees fresh data and real-time behaviour is preserved.

---

## 6. How do leaderboards stay “live” and show the user’s current rank?

**Answer:** (1) On every **submitAnswer** we update `LeaderboardScore` and `LeaderboardStreak` in the same transaction as user state, then **invalidate** the leaderboard Redis cache. (2) The **answer response** includes `leaderboardRankScore` and `leaderboardRankStreak` so the UI can show rank immediately. (3) The frontend **polls** the leaderboard APIs every few seconds so the list and the user’s position stay up to date.

---

## 7. How do you handle streak when the user is inactive for a long time?

**Answer:** We apply **streak decay**: if `lastAnswerAt` is older than a configured threshold (e.g. 30 minutes), we set the current streak to 0 before using it (e.g. when loading state or processing the next answer). So long inactivity resets the streak; we don’t double-count old streak for score.

---

## 8. Walk me through the flow from “user submits an answer” to “next question is shown.”

**Answer:** (1) Frontend sends POST `/v1/quiz/answer` with userId, questionId, answer, stateVersion, answerIdempotencyKey. (2) Backend checks idempotency; if duplicate, returns cached result. (3) Load question, verify answer (hash comparison). (4) Load user state, apply streak decay if needed. (5) Call adaptive algorithm (onCorrect/onWrong), compute score delta, new streak, new difficulty. (6) In a **transaction**: update UserState, insert AnswerLog, upsert LeaderboardScore and LeaderboardStreak. (7) Invalidate user state and leaderboard caches. (8) Return correct, newDifficulty, newStreak, scoreDelta, totalScore, ranks. (9) Frontend updates UI and calls GET `/v1/quiz/next` to fetch the next question.

---

## 9. Why store correctAnswerHash instead of the raw correct answer in the question?

**Answer:** So the backend never stores or sends the plain correct choice. We only store a hash (e.g. SHA-256 of the choice id). On submit we hash the user’s choice and compare; we never expose the correct answer in the API. This reduces risk of leaking answers if the API or DB is exposed.

---

## 10. How did you make the backend stateless?

**Answer:** All session and user state is in **MongoDB** (UserState, AnswerLog, LeaderboardScore, LeaderboardStreak) and optionally in **Redis** as cache. The Express app doesn’t keep in-memory state; every request is handled using DB/cache. So we can run multiple backend instances behind a load balancer without sticky sessions.

---

## 11. How do you protect the API from abuse?

**Answer:** **Rate limiting** with express-rate-limit on `/v1/`: e.g. 120 requests per minute per IP. This limits burst traffic and simple abuse. For production you’d typically add auth, per-user limits, and possibly CAPTCHA for sensitive actions.

---

## 12. Why use a transaction when submitting an answer?

**Answer:** We update four places: UserState, AnswerLog, LeaderboardScore, LeaderboardStreak. If any step fails after a partial write, we’d have inconsistent state (e.g. score updated but streak not). Using a MongoDB **transaction** ensures all four updates commit or none do, so streak, score, and leaderboards stay in sync.

---

## 13. What is the role of stateVersion?

**Answer:** stateVersion is incremented on every user-state update. The client can send it with the next request (e.g. in submitAnswer) for **optimistic UI** or debugging. In our implementation we don’t reject stale stateVersion; **idempotency** is enforced by answerIdempotencyKey. stateVersion is still useful for the client to know when its view is outdated.

---

## 14. How did you handle the case when there are no questions for the current difficulty?

**Answer:** When building the question pool for the user’s current difficulty, if no questions exist we return a response with `prompt: null`, `choices: null`, and a `message` (e.g. “No questions available for current difficulty”). The frontend shows that message instead of a question card. In practice we seed questions for all difficulties 1–10 so this is an edge case.

---

## 15. Why did you choose Next.js for the frontend?

**Answer:** Next.js gives (1) **SSR** for the landing page (better SEO and first paint), (2) **CSR** where we need it (quiz, metrics, leaderboard) with client-side data fetching, (3) **API rewrites** so the browser hits same origin and we proxy to the backend, (4) **Code splitting / dynamic imports** (e.g. QuizQuestion lazy-loaded), (5) TypeScript and a clear app-router structure.

---

## 16. Explain your design system and how you avoid hardcoded styles.

**Answer:** We use **design tokens** in a central CSS file (e.g. `design-tokens.css`): CSS variables for colors, spacing, radius, shadows, typography. Components use only these variables (e.g. `var(--spacing-4)`, `var(--color-brand-600)`). Tailwind is configured to use the same tokens (e.g. `token-4`, `brand-600`). So there are no magic numbers in components; changing the token file updates the whole UI and we support light/dark via a `.dark` class.

---

## 17. How do you ensure strong consistency for a user’s streak and score?

**Answer:** (1) All updates to UserState, AnswerLog, and leaderboard collections for a given answer happen inside a single MongoDB **transaction**. (2) We use **idempotency** so the same logical answer is never applied twice. (3) We **invalidate** the user’s state in Redis on every answer so the next read sees the latest DB state. So for a single user we get consistent streak and score; leaderboard is eventually consistent with short-lived cache.

---

## 18. What indexes did you add and why?

**Answer:** Examples: (1) **UserState:** `userId` (unique), `totalScore` desc, `maxStreak` desc – for lookups and leaderboard-style queries. (2) **AnswerLog:** unique on `(userId, idempotencyKey)` for idempotency, and `(userId, answeredAt)` for metrics. (3) **Question:** `difficulty` and `(difficulty, _id)` for “next question” by difficulty. (4) **LeaderboardScore / LeaderboardStreak:** `totalScore` desc and `maxStreak` desc for top-N queries.

---

## 19. How would you scale this system to many concurrent users?

**Answer:** (1) **Backend:** stateless app servers behind a load balancer; horizontal scaling. (2) **MongoDB:** replica set, read replicas for metrics/leaderboard reads if needed; sharding by userId if one DB becomes a bottleneck. (3) **Redis:** cluster or separate cache instances; keep cache TTLs and invalidation as is. (4) **Rate limiting:** per-user or per-API-key in addition to per-IP. (5) **Frontend:** CDN for static assets; Next.js can be deployed on Vercel or similar for auto-scaling.

---

## 20. Describe one trade-off you made and what you would improve next.

**Answer:** **Trade-off:** Leaderboard “real-time” is achieved by cache invalidation plus polling every few seconds, not WebSockets. So we avoid the complexity of a WebSocket server and scaling it, but there’s a few seconds delay before the list refreshes. **Improvement:** Add WebSockets or Server-Sent Events for live leaderboard updates when a user submits an answer, so all clients see the new rank without waiting for the next poll. Alternatively, we could shorten the poll interval at the cost of more requests.

---

**Good luck with your interview.**
