"""
Generates a dark ambient WAV track inspired by Death Note's eerie atmosphere.

Layers:
  1. Deep drone bass (40 Hz)
  2. Sustained mid-tone hum (80 Hz)
  3. Slow piano-like bell tones (pentatonic minor sequence)
  4. Soft high shimmer (overtone at 3x bass)
  5. Subtle noise floor for texture
  6. All amplitude-modulated with slow LFO for breathing effect

Output: assets/ryuk-theme.wav  (~60 seconds, 44100Hz, mono 16-bit)
"""

import wave, struct, math, random, os
import numpy as np

SAMPLE_RATE = 44100
DURATION    = 60          # seconds
NUM_SAMPLES = SAMPLE_RATE * DURATION
t           = np.linspace(0, DURATION, NUM_SAMPLES, endpoint=False)

# ── Helpers ──────────────────────────────────────────────────────────────────

def sine(freq, phase=0.0):
    return np.sin(2 * np.pi * freq * t + phase)

def env_adsr(attack, decay, sustain_level, release, total):
    """Simple ADSR envelope over total seconds."""
    a = int(attack  * SAMPLE_RATE)
    d = int(decay   * SAMPLE_RATE)
    r = int(release * SAMPLE_RATE)
    s = total - a - d - r
    if s < 0: s = 0
    env = np.concatenate([
        np.linspace(0, 1,             a),
        np.linspace(1, sustain_level, d),
        np.full(s, sustain_level),
        np.linspace(sustain_level, 0, r),
    ])
    return np.resize(env, total)

def bell_tone(freq, start_sec, dur_sec, amplitude=0.18):
    """A single piano/bell note placed at start_sec."""
    start  = int(start_sec * SAMPLE_RATE)
    n      = int(dur_sec   * SAMPLE_RATE)
    if start + n > NUM_SAMPLES:
        n = NUM_SAMPLES - start
    if n <= 0:
        return np.zeros(NUM_SAMPLES)

    local_t = np.linspace(0, dur_sec, n, endpoint=False)

    # Fundamental + harmonics (detuned slightly for warmth)
    wave_chunk  = np.sin(2 * np.pi * freq         * local_t)
    wave_chunk += np.sin(2 * np.pi * freq * 2.01  * local_t) * 0.4
    wave_chunk += np.sin(2 * np.pi * freq * 3.005 * local_t) * 0.2
    wave_chunk += np.sin(2 * np.pi * freq * 4.02  * local_t) * 0.08

    # Exponential decay envelope
    decay_env = np.exp(-local_t * (1.8 / dur_sec * 4))
    wave_chunk *= decay_env * amplitude

    out = np.zeros(NUM_SAMPLES)
    out[start:start + n] = wave_chunk
    return out

# ── Layer 1: Deep bass drone (two slightly detuned sines) ────────────────────
bass  = sine(40.0) * 0.30
bass += sine(40.3) * 0.15   # slight detune = beating / chorus effect
bass += sine(80.0) * 0.12   # octave up adds body

# ── Layer 2: Slow breathing LFO on bass (0.07 Hz) ────────────────────────────
lfo_bass  = (0.6 + 0.4 * np.sin(2 * np.pi * 0.07 * t))
bass *= lfo_bass

# ── Layer 3: Mid hum (pentatonic minor root) ─────────────────────────────────
mid  = sine(120.0) * 0.08
mid += sine(160.0) * 0.06
lfo_mid = (0.5 + 0.5 * np.sin(2 * np.pi * 0.05 * t + 1.2))
mid *= lfo_mid

# ── Layer 4: High shimmer overtone ───────────────────────────────────────────
shimmer  = sine(320.0, phase=0.7) * 0.04
shimmer += sine(480.0, phase=1.1) * 0.025
lfo_shim = (0.4 + 0.6 * np.sin(2 * np.pi * 0.13 * t + 2.3))
shimmer *= lfo_shim

# ── Layer 5: Bell melody — slow, eerie, pentatonic minor ─────────────────────
# Notes in Hz (D minor pentatonic: D, F, G, A, C)
notes = [146.83, 174.61, 196.00, 220.00, 261.63,
         293.66, 349.23, 392.00, 440.00]

melody_pattern = [
    (0,   notes[0], 3.5),
    (4,   notes[2], 3.0),
    (8,   notes[1], 3.5),
    (12,  notes[4], 4.0),
    (16,  notes[3], 3.0),
    (20,  notes[0], 3.5),
    (24,  notes[5], 4.0),
    (28,  notes[2], 3.0),
    (32,  notes[1], 4.0),
    (36,  notes[4], 3.5),
    (40,  notes[3], 3.0),
    (44,  notes[6], 4.0),
    (48,  notes[0], 3.5),
    (52,  notes[2], 3.0),
    (56,  notes[1], 4.0),
]

melody = np.zeros(NUM_SAMPLES)
for start, freq, dur in melody_pattern:
    melody += bell_tone(freq, start, dur, amplitude=0.22)

# ── Layer 6: Subtle noise texture ────────────────────────────────────────────
rng   = np.random.default_rng(42)
noise = rng.standard_normal(NUM_SAMPLES) * 0.006
# Low-pass: smooth the noise
kernel_size = 512
kernel = np.ones(kernel_size) / kernel_size
noise  = np.convolve(noise, kernel, mode='same')

# ── Mix all layers ────────────────────────────────────────────────────────────
mixed = bass + mid + shimmer + melody + noise

# Master fade-in / fade-out (3 seconds each)
fade_len = 3 * SAMPLE_RATE
mixed[:fade_len]  *= np.linspace(0, 1, fade_len)
mixed[-fade_len:] *= np.linspace(1, 0, fade_len)

# Normalize to 90% of max amplitude
peak  = np.max(np.abs(mixed))
if peak > 0:
    mixed = mixed / peak * 0.90

# ── Write WAV ────────────────────────────────────────────────────────────────
out_path = os.path.join(os.path.dirname(__file__), 'assets', 'ryuk-theme.wav')

samples_int16 = (mixed * 32767).astype(np.int16)

with wave.open(out_path, 'w') as wf:
    wf.setnchannels(1)
    wf.setsampwidth(2)
    wf.setframerate(SAMPLE_RATE)
    wf.writeframes(samples_int16.tobytes())

size_kb = os.path.getsize(out_path) // 1024
print(f"Generated: {out_path}  ({DURATION}s  {size_kb} KB)")
