/* ═══════════════════════════════════════════
   DEATH NOTE PORTFOLIO — script.js
═══════════════════════════════════════════ */

/* ─── Intro Overlay + Music ─── */
(function () {
  const overlay     = document.getElementById('introOverlay');
  const enterBtn    = document.getElementById('introEnter');
  const audio       = document.getElementById('bgMusic');
  const player      = document.getElementById('musicPlayer');
  const toggleBtn   = document.getElementById('musicToggle');
  const closeBtn    = document.getElementById('musicClose');
  const progress    = document.getElementById('musicProgress');

  /* Spawn falling feather/black particles */
  const particleContainer = document.getElementById('introParticles');
  const CHARS = ['✦', '✧', '◆', '◇', '⬥', '🪶'];
  for (let i = 0; i < 22; i++) {
    const p = document.createElement('span');
    p.className = 'intro-particle';
    p.textContent = CHARS[Math.floor(Math.random() * CHARS.length)];
    p.style.cssText = [
      `left: ${Math.random() * 100}%`,
      `animation-duration: ${4 + Math.random() * 8}s`,
      `animation-delay: ${Math.random() * 6}s`,
      `font-size: ${0.6 + Math.random() * 1.2}rem`,
      `color: ${Math.random() > 0.5 ? 'rgba(204,0,0,0.5)' : 'rgba(200,169,81,0.3)'}`,
    ].join(';');
    particleContainer.appendChild(p);
  }

  /* Enter: dismiss overlay, start music, show player */
  enterBtn.addEventListener('click', () => {
    overlay.classList.add('hidden');
    audio.volume = 0.35;
    audio.play().catch(() => {});   /* graceful fail if file missing */
    setTimeout(() => player.classList.add('visible'), 800);
  });

  /* Music toggle */
  toggleBtn.addEventListener('click', () => {
    if (audio.paused) {
      audio.play();
      player.classList.remove('paused');
    } else {
      audio.pause();
      player.classList.add('paused');
    }
  });

  /* Hide player */
  closeBtn.addEventListener('click', () => {
    player.classList.remove('visible');
    audio.pause();
  });

  /* Progress bar */
  audio.addEventListener('timeupdate', () => {
    if (!audio.duration) return;
    progress.style.width = `${(audio.currentTime / audio.duration) * 100}%`;
  });

  /* Reflect initial paused state */
  audio.addEventListener('pause', () => player.classList.add('paused'));
  audio.addEventListener('play',  () => player.classList.remove('paused'));
})();

/* ─── Navbar scroll effect ─── */
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
}, { passive: true });

/* ─── Mobile menu ─── */
const hamburger   = document.getElementById('hamburger');
let mobileMenu    = null;

function buildMobileMenu() {
  if (mobileMenu) return;
  mobileMenu = document.createElement('nav');
  mobileMenu.className = 'mobile-menu';

  const closeBtn = document.createElement('button');
  closeBtn.className = 'mobile-close';
  closeBtn.textContent = '✕';
  closeBtn.addEventListener('click', closeMobile);
  mobileMenu.appendChild(closeBtn);

  const links = [
    ['#about',        'About'],
    ['#skills',       'Skills'],
    ['#experience',   'Experience'],
    ['#projects',     'Projects'],
    ['#cp',           'Competitive'],
    ['#achievements', 'Achievements'],
    ['#contact',      'Contact'],
  ];

  links.forEach(([href, label]) => {
    const a = document.createElement('a');
    a.href = href;
    a.textContent = label;
    a.addEventListener('click', closeMobile);
    mobileMenu.appendChild(a);
  });

  document.body.appendChild(mobileMenu);
}

function openMobile() {
  buildMobileMenu();
  mobileMenu.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeMobile() {
  if (mobileMenu) mobileMenu.classList.remove('open');
  document.body.style.overflow = '';
}

hamburger.addEventListener('click', openMobile);

/* ─── Typewriter effect ─── */
const typewriterEl  = document.getElementById('typewriter');
const phrases       = [
  'Software Engineer',
  'Competitive Programmer',
  'Full-Stack Developer',
  'Backend Specialist',
];
let phraseIdx  = 0;
let charIdx    = 0;
let deleting   = false;
let twStarted  = false;

function typeStep() {
  const current = phrases[phraseIdx];

  if (!deleting) {
    typewriterEl.textContent = current.slice(0, charIdx + 1);
    charIdx++;
    if (charIdx === current.length) {
      deleting = true;
      setTimeout(typeStep, 1800);
      return;
    }
    setTimeout(typeStep, 85);
  } else {
    typewriterEl.textContent = current.slice(0, charIdx - 1);
    charIdx--;
    if (charIdx === 0) {
      deleting = false;
      phraseIdx = (phraseIdx + 1) % phrases.length;
      setTimeout(typeStep, 400);
      return;
    }
    setTimeout(typeStep, 45);
  }
}

/* Start typewriter after hero animations settle */
setTimeout(() => {
  twStarted = true;
  typeStep();
}, 2200);

/* ─── Scroll reveal with IntersectionObserver ─── */
const revealElements = document.querySelectorAll('.fade-in, .dn-quote');

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
    }
  });
}, {
  threshold: 0.12,
  rootMargin: '0px 0px -40px 0px',
});

revealElements.forEach((el) => revealObserver.observe(el));

/* ─── Hero parallax on scroll ─── */
const heroBg = document.querySelector('.hero-bg');
window.addEventListener('scroll', () => {
  if (!heroBg) return;
  const scrollY = window.scrollY;
  if (scrollY < window.innerHeight) {
    heroBg.style.transform = `scale(1.05) translateY(${scrollY * 0.25}px)`;
  }
}, { passive: true });

/* ─── 3D tilt on project cards ─── */
const tiltCards = document.querySelectorAll('[data-tilt]');

tiltCards.forEach((card) => {
  card.addEventListener('mousemove', (e) => {
    const rect    = card.getBoundingClientRect();
    const centerX = rect.left + rect.width  / 2;
    const centerY = rect.top  + rect.height / 2;
    const rotateX = ((e.clientY - centerY) / (rect.height / 2)) * -6;
    const rotateY = ((e.clientX - centerX) / (rect.width  / 2)) *  6;
    card.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(4px)`;
  });

  card.addEventListener('mouseleave', () => {
    card.style.transform = 'perspective(800px) rotateX(0deg) rotateY(0deg) translateZ(0)';
    card.style.transition = 'transform 0.5s ease';
  });

  card.addEventListener('mouseenter', () => {
    card.style.transition = 'transform 0.1s ease';
  });
});

/* ─── Smooth scroll for anchor links ─── */
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener('click', (e) => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offset = 70;
      const top = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top, behavior: 'smooth' });
    }
  });
});

/* ─── Stagger skill tags on reveal ─── */
const skillsNotebook = document.querySelector('.skills-notebook');
if (skillsNotebook) {
  const skillObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const tags = entry.target.querySelectorAll('.skill-tag');
        tags.forEach((tag, i) => {
          setTimeout(() => {
            tag.style.opacity    = '0';
            tag.style.transform  = 'translateY(12px)';
            tag.style.transition = `opacity 0.4s ease ${i * 0.04}s, transform 0.4s ease ${i * 0.04}s`;
            requestAnimationFrame(() => {
              tag.style.opacity   = '1';
              tag.style.transform = 'translateY(0)';
            });
          }, i * 30);
        });
        skillObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.2 });

  skillObserver.observe(skillsNotebook);
}

/* ─── Animated counter for CP stats ─── */
function animateCounter(el, target, duration) {
  const start     = performance.now();
  const startVal  = 0;

  function update(now) {
    const elapsed  = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased    = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(startVal + eased * (target - startVal));
    if (progress < 1) requestAnimationFrame(update);
  }

  requestAnimationFrame(update);
}

const cpStats = document.querySelectorAll('.cp-stat-value');
const cpObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      cpStats.forEach((el) => {
        const val = parseInt(el.textContent, 10);
        if (!isNaN(val)) animateCounter(el, val, 1600);
      });
      cpObserver.disconnect();
    }
  });
}, { threshold: 0.3 });

const cpSection = document.getElementById('cp');
if (cpSection) cpObserver.observe(cpSection);

/* ─── Active nav link highlight on scroll ─── */
const sections   = document.querySelectorAll('section[id], footer[id]');
const navAnchors = document.querySelectorAll('.nav-links a');

const navObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      navAnchors.forEach((a) => {
        a.classList.toggle('active', a.getAttribute('href') === `#${entry.target.id}`);
      });
    }
  });
}, { threshold: 0.4 });

sections.forEach((s) => navObserver.observe(s));
