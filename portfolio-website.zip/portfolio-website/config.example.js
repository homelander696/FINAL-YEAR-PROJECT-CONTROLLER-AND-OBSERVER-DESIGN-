/* ─────────────────────────────────────────────────────
   Portfolio Config  — EXAMPLE / TEMPLATE
   Copy this file to config.js and fill in your keys.
   Get your Web3Forms key at: https://web3forms.com
   ───────────────────────────────────────────────────── */
window.PORTFOLIO_CONFIG = {
  web3formsKey: 'YOUR_WEB3FORMS_ACCESS_KEY_HERE',
};
