"""
Anime-style photo converter with Death Note color grade.

Pipeline:
  1. Upscale slightly for higher quality processing
  2. Multiple passes of edge-preserving bilateral filter (skin smoothing)
  3. Adaptive edge mask via Canny on luminance channel
  4. Color quantization (posterization) for flat anime color blocks
  5. Merge smooth base + sharp edges
  6. Death Note color grade:
     - Desaturate slightly
     - Boost contrast & shadows
     - Push shadows toward deep red/black
     - Add a subtle warm highlight
  7. Final sharpening pass
  8. Save as PNG
"""

import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import sys
import os


# ── helpers ──────────────────────────────────────────────────────────────────

def pil_to_cv(img):
    return cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)

def cv_to_pil(img):
    return Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))

def posterize(img_bgr, levels=6):
    """Reduce colors to `levels` steps per channel (anime flat-color look)."""
    factor = 255.0 / (levels - 1)
    out = np.round(img_bgr / factor) * factor
    return np.clip(out, 0, 255).astype(np.uint8)


# ── main conversion ──────────────────────────────────────────────────────────

def anime_convert(src_path, dst_path):
    # Load
    img_pil = Image.open(src_path).convert("RGB")

    # 1. Upscale to improve edge quality
    W, H = img_pil.size
    scale = 2.0
    img_pil = img_pil.resize((int(W * scale), int(H * scale)), Image.LANCZOS)

    img = pil_to_cv(img_pil)

    # 2. Bilateral filter — multiple passes for strong smoothing while keeping edges
    smooth = img.copy()
    for _ in range(7):
        smooth = cv2.bilateralFilter(smooth, d=9, sigmaColor=75, sigmaSpace=75)

    # 3. Edge mask from the smoothed image
    gray = cv2.cvtColor(smooth, cv2.COLOR_BGR2GRAY)
    # Gaussian blur before Canny to reduce noise
    gray_blur = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(gray_blur, threshold1=35, threshold2=100)
    # Dilate slightly so lines are visible at display size
    kernel = np.ones((2, 2), np.uint8)
    edges = cv2.dilate(edges, kernel, iterations=1)
    # Invert: white background, black lines
    edge_inv = cv2.bitwise_not(edges)
    # Convert to 3-channel mask
    edge_mask = cv2.cvtColor(edge_inv, cv2.COLOR_GRAY2BGR)

    # 4. Posterize the smooth image
    flat = posterize(smooth, levels=7)

    # 5. Merge: multiply flat colors with edge mask
    # edge_mask is 0 where lines are, 255 elsewhere
    anime_raw = (flat.astype(np.float32) * (edge_mask.astype(np.float32) / 255.0))
    anime_raw = np.clip(anime_raw, 0, 255).astype(np.uint8)

    # 6. Convert back to PIL for color grading
    result = cv_to_pil(anime_raw)

    # ── Death Note color grade ──────────────────────────────────────────────

    # a) Slight desaturation (anime skin tones are muted)
    result = ImageEnhance.Color(result).enhance(0.82)

    # b) Contrast boost
    result = ImageEnhance.Contrast(result).enhance(1.3)

    # c) Slightly reduce brightness to push into darker anime palette
    result = ImageEnhance.Brightness(result).enhance(0.88)

    # d) Shadow color grade — push deep shadows toward dark red/black
    #    by blending with a deep crimson layer in the shadows
    grade_layer = Image.new("RGB", result.size, (35, 0, 0))   # deep red shadow
    # Build luminance-based mask: bright pixels = transparent, dark = opaque
    gray_pil = result.convert("L")
    shadow_mask = gray_pil.point(lambda p: max(0, 180 - p) * 2)  # 0 at bright, strong at dark
    result.paste(grade_layer, mask=shadow_mask)

    # e) Subtle warm gold highlight for rim/specular areas
    highlight_layer = Image.new("RGB", result.size, (255, 220, 140))
    highlight_mask = gray_pil.point(lambda p: max(0, (p - 210) * 4))  # only very bright pixels
    result.paste(highlight_layer, mask=highlight_mask)

    # f) Slight sharpening to crisp up the anime lines
    result = result.filter(ImageFilter.UnsharpMask(radius=1.2, percent=140, threshold=2))

    # 7. Downscale back to original size
    result = result.resize((W, H), Image.LANCZOS)

    # Save
    result.save(dst_path, "PNG", optimize=True)
    print(f"Saved: {dst_path}  ({W}x{H})")


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "assets/ratan-selfie.png"
    dst = sys.argv[2] if len(sys.argv) > 2 else "assets/ratan-anime.png"
    print(f"Converting {src} → {dst} ...")
    anime_convert(src, dst)
    print("Done.")
