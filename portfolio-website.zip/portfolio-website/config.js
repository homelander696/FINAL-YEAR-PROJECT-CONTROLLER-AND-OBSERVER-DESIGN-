/* ─────────────────────────────────────────────────────
   Portfolio Config  — DO NOT commit this file to git!
   Copy config.example.js → config.js and fill in your keys.
   ───────────────────────────────────────────────────── */
window.PORTFOLIO_CONFIG = {
  web3formsKey: '9e10c144-feef-4239-a770-4749eee3b0eb',
};
