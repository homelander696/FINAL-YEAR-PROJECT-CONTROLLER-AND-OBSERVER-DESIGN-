# Anime-Themed Developer Portfolio — LLM Prompt

> Copy everything inside the code block below and paste it into any LLM.
> Fill in every `[BRACKETED]` placeholder before sending.

---

```
I want you to build a single-page anime-themed developer portfolio website using only HTML, CSS,
and vanilla JavaScript (no frameworks). Here is the full specification:

═══════════════════════════════════════════════════════════════
STEP 1 — ANIME THEME: [REPLACE WITH YOUR ANIME NAME]
═══════════════════════════════════════════════════════════════

Define the following based on your chosen anime:

| Property              | Value                                                      |
| --------------------- | ---------------------------------------------------------- |
| Primary background    | [e.g. #0a0a0a, #0d0d1a, #0a0f0a]                          |
| Secondary background  | [slightly lighter shade of primary]                        |
| Accent color          | [e.g. #cc0000, #0066ff, #00ff88, #a855f7]                  |
| Accent dark           | [darker shade of accent]                                   |
| Accent glow           | [rgba version of accent at ~40% opacity]                   |
| Secondary accent      | [e.g. gold #c8a951, cyan #00d4ff, orange #ff6b00]          |
| Text color            | [e.g. #f0ece0, #e0e8ff, #d4ffd4]                          |
| Text muted            | [dimmer version of text color]                             |
| Heading font          | [Google Fonts — dramatic/stylized, e.g. Cinzel Decorative] |
| Subheading font       | [Google Fonts — clean serif/sans, e.g. Cinzel]             |
| Body font             | [Google Fonts — readable, e.g. Crimson Text]               |
| Notebook/artifact     | [in-universe item for the Skills section label,            |
|                       |  e.g. "DEATH NOTE", "SHINOBI SCROLL", "TITAN CODEX"]      |

Section label prefix style (e.g. "Rule I.", "Chapter I.", "Arc I.", "Jutsu I."):
[YOUR CHOICE]

═══════════════════════════════════════════════════════════════
STEP 2 — ANIME WALLPAPERS
═══════════════════════════════════════════════════════════════

Provide 4 anime wallpaper images saved in an assets/ folder:

| Variable      | Filename            | Used in section    | Description of ideal image        |
| ------------- | ------------------- | ------------------ | ---------------------------------- |
| Hero BG       | assets/img-hero.png | Hero               | Wide dramatic scene, dark sky/bg   |
| Experience BG | assets/img-exp.png  | Experience         | Single character, side-profile     |
| CP BG         | assets/img-cp.png   | Competitive Prog.  | Intense close-up or duel scene     |
| (unused slot) | assets/img-4.png    | (spare / about)    | Any dramatic character art         |

Your personal photos:
| Variable        | Filename                  | Used in section         |
| --------------- | ------------------------- | ----------------------- |
| Profile photo   | assets/your-anime.png     | About section           |
| Background photo| assets/your-bg-photo.png  | Contact section         |

Note: Run the anime conversion script below on your real photo first to get your-anime.png.

═══════════════════════════════════════════════════════════════
STEP 3 — DEVELOPER INFORMATION
═══════════════════════════════════════════════════════════════

Full name:       [YOUR FULL NAME]
Email:           [YOUR EMAIL]
Phone:           [YOUR PHONE]
Location:        [YOUR CITY / COLLEGE]
GitHub URL:      [URL]
LinkedIn URL:    [URL]
LeetCode URL:    [URL]
LeetCode handle: [HANDLE]
LeetCode solved: [NUMBER]
LeetCode rating: [NUMBER]
Codeforces URL:  [URL]
CF handle:       [HANDLE]
CF solved:       [NUMBER]
CF rating:       [NUMBER]
Total problems:  [NUMBER]

Typewriter role titles (comma separated):
[e.g. Software Engineer, Competitive Programmer, Full-Stack Developer, Backend Specialist]

Hero eyebrow text (small text above name):
[e.g. "The New World Order of Code", "Believe It.", "I'll become the greatest developer"]

Education:
- College: [NAME]
  Degree:  [e.g. B.Tech Electrical Engineering]
  CPI/GPA: [VALUE]
  Years:   [e.g. 2022–2026]

Experience (add more blocks if needed):
- Company:  [NAME]
  Role:     [TITLE]
  Period:   [e.g. Jan 2026 — Present]
  Bullet 1: [DESCRIPTION]
  Bullet 2: [DESCRIPTION]
  Bullet 3: [DESCRIPTION]
  Bullet 4: [DESCRIPTION]
  Tags:     [comma-separated tech list]

Skills:
  Languages:       [list]
  Backend:         [list]
  Frontend:        [list]
  Databases:       [list]
  DevOps & Tools:  [list]

Projects (exactly 3):
  Project 1:
    Name:   [NAME]
    Desc:   [1–2 sentence description]
    Stack:  [comma separated]
    GitHub: [URL]
    Live:   [URL or NONE]

  Project 2:
    Name:   [NAME]
    Desc:   [1–2 sentence description]
    Stack:  [comma separated]
    GitHub: [URL]
    Live:   [URL or NONE]

  Project 3:
    Name:   [NAME]
    Desc:   [1–2 sentence description]
    Stack:  [comma separated]
    GitHub: [URL]
    Live:   [URL or NONE]

Achievements (list each with a short sub-description):
  - [TITLE] · [CONTEXT / detail]
  - [TITLE] · [CONTEXT / detail]
  - [TITLE] · [CONTEXT / detail]

Positions of Responsibility:
  - [ROLE] · [CONTEXT]
  - [ROLE] · [CONTEXT]

═══════════════════════════════════════════════════════════════
STEP 4 — ANIME QUOTES (software-engineering adapted)
═══════════════════════════════════════════════════════════════

Each is a real in-universe quote twisted to fit the developer world.
Format each as: "quote text" — Character Name

Hero section quote       (power / ambition → code):
"[QUOTE]" — [CHARACTER]

About section quote      (identity / solitude → developer mindset):
"[QUOTE]" — [CHARACTER]

Skills section quote     (mastery / strength → technical skill):
"[QUOTE]" — [CHARACTER]

Experience section quote (commitment / no turning back → production/deployment):
"[QUOTE]" — [CHARACTER]

Projects section quote   (creation / will → building things):
"[QUOTE]" — [CHARACTER]

CP section quote         (logic / intelligence → algorithms):
"[QUOTE]" — [CHARACTER]

Footer quote             (life / death → code living on):
"[QUOTE]" — [CHARACTER]

Style all quotes as:
- Blockquote with accent-colored left border (3px solid)
- Dark card background slightly lighter than page background
- Italic body text in main text color
- Character attribution in secondary accent color, Cinzel/subheading font
- Large faded opening-quote character (accent-dark, 30% opacity) as decorative ::before
- Subtle flicker animation on the left border when .is-visible (scroll reveal)

═══════════════════════════════════════════════════════════════
STEP 5 — REQUIRED SECTIONS (build in this order)
═══════════════════════════════════════════════════════════════

── 1. NAVBAR ───────────────────────────────────────────────────
- position: fixed; top: 0
- Transparent by default
- On scroll > 60px: add .scrolled → background rgba(primary, 0.92) + backdrop-filter: blur(12px)
  + box-shadow: 0 1px 0 accent-dark
- Logo: initials in heading font, accent color, text-shadow glow
- Nav links: uppercase, letter-spacing, accent underline slides in on hover
- .active class on current section link (set by IntersectionObserver in JS)
- Hamburger (3 bars) on mobile → full-screen overlay menu built in JS

── 2. HERO ─────────────────────────────────────────────────────
- min-height: 100vh; display: flex; align-items: center; justify-content: center
- Background: img-hero.png, scale(1.05), parallax translateY(scrollY * 0.25)
- Dark gradient overlay (primary → primary 75% → accent-dark 15%)
- Eyebrow text: small uppercase letter-spaced, accent color, fadeDown animation
- Name: heading font, clamp(2.8rem, 8vw, 6rem), letter-by-letter stagger animation
  (each <span> animates from opacity:0 + translateY(40px) → visible, staggered 100ms apart)
- Subtitle: typewriter effect (see JS section), min-height so layout doesn't jump
- Blinking cursor after typewriter text (accent color, CSS animation)
- Anime quote block
- Two CTA buttons: btn-primary (solid accent) + btn-secondary (outlined, gold/secondary)
  Both lift on hover (translateY -2px) with glow box-shadow
- Scroll indicator: "SCROLL" text + animated vertical line (scaleY pulses)
- All hero content animates in sequentially with CSS animation-delay

── 3. ABOUT ────────────────────────────────────────────────────
- Two-column grid: text (1fr) | photo (fixed ~380px wide)
- Section title with label prefix (e.g. "Rule I." or "Chapter I.")
- Bio text in body font, muted color; important words in white bold
- Social links row: icon SVG + label, outlined gold border, hover glow
- Photo (.photo-frame):
    * img height ~520px, object-fit: cover, object-position: top center
    * filter: grayscale(55%) contrast(1.25) brightness(0.8) sepia(15%)
    * Hover: slightly less grayscale
    * .photo-scanlines: repeating-linear-gradient horizontal lines overlay (z-index 2)
    * .photo-red-tint: accent rgba overlay, mix-blend-mode: color-dodge (z-index 3)
    * .photo-vignette: radial-gradient dark edges overlay (z-index 4)
    * 4 corner brackets (.photo-corner-tl/tr/bl/br): accent border, expand width/height on hover (z-index 5)
    * ::after glitch: clip-path + translateX distortion animation on hover (z-index 6)
    * ::before name plate: character name in secondary accent at bottom (z-index 7)
- Anime quote block below the grid

── 4. SKILLS ───────────────────────────────────────────────────
- Section title with label prefix
- Anime quote block
- .skills-notebook container:
    * border: 1px solid rgba(accent, 0.2)
    * background: secondary-bg
    * ::before pseudo: artifact label (e.g. "DEATH NOTE") centered on top border
    * padding: 2.5rem
- Each skill group:
    * group title: § number + category name, uppercase, letter-spaced, muted
    * .skills-tags: flex-wrap row of .skill-tag pills
    * .skill-tag: border accent 25% opacity, muted text, dark bg
    * .skill-tag:hover: border full accent, white text, box-shadow glow, translateY(-2px)
    * Groups separated by faint horizontal rule
- On scroll entry: each tag stagger-animates in (translateY 12px→0, opacity 0→1, delay = index * 30ms)

── 5. EXPERIENCE ───────────────────────────────────────────────
- .exp-bg-img: img-exp.png, absolute right side, 40% width, opacity 0.07
- Section title with label prefix
- Anime quote block
- .timeline:
    * .timeline-dot: accent circle, box-shadow glow
    * .timeline-connector: vertical line, gradient accent → transparent
    * .timeline-card: dark bg, accent border 20% opacity, hover accent border + shadow
    * .timeline-header: company name (secondary accent, heading font) | date badge (outlined, right)
    * Role subtitle in accent color
    * .timeline-points li: bullet using em-dash in accent color as ::before
    * .timeline-tags: small filled accent-dark badge chips

── 6. PROJECTS ─────────────────────────────────────────────────
- Section title with label prefix
- Anime quote block
- 3-column grid (gap 1.5rem), collapses to 1-column on mobile
- Each .project-card:
    * background: secondary-bg; border: 1px solid rgba(accent, 0.15)
    * hover: border accent full, box-shadow 0 8px 40px rgba(accent, 0.2)
    * data-tilt attribute for JS 3D tilt effect
    * .project-number: huge faded heading (01/02/03), accent-dark 35% opacity → 70% on hover
    * .project-title, .project-desc (muted), .project-stack (secondary accent tags)
    * .project-links: GitHub link (icon + text) + Live Demo ↗ link (accent colored)

── 7. COMPETITIVE PROGRAMMING ──────────────────────────────────
- Full-section background: img-cp.png + dark gradient overlay
- Section title (white), anime quote block
- 3-column: [platform card] [center badge] [platform card]
- .cp-card: dark glass bg, accent border, hover glow
    * Platform name (secondary accent, heading font)
    * Handle (muted, small)
    * Two stats side-by-side: large number (heading font) + small label
    * "View Profile ↗" button: outlined accent → solid on hover
- .cp-badge-circle: circular, accent border, pulsing box-shadow animation
    * Shows total problems solved + "Problems Solved" label
- Animated counters: numbers count up on scroll (easeOutCubic, 1600ms)

── 8. ACHIEVEMENTS ─────────────────────────────────────────────
- Dark section background
- Section title with label prefix
- Stacked list of .achievement-item:
    * emoji icon (1.6rem) + title (bold, white) + description (muted)
    * Separated by faint horizontal border
    * Hover: slight padding-left increase + faint accent background wash

── 9. CONTACT ──────────────────────────────────────────────────
- Full-section background: your-bg-photo.png
    * filter: grayscale(70%) contrast(1.1)
    * Overlay: dark gradient (primary 96% → accent-dark 12%)
- Two-column layout: contact details | social links
- .contact-item: label (accent, uppercase tiny) over value (white)
    * Hover: slide right via padding-left transition
- .contact-social-link: large heading-font text, muted → accent on hover
    * letter-spacing expands on hover

── 10. FOOTER ──────────────────────────────────────────────────
- Thin gradient rule (transparent → accent → transparent)
- Name in accent color, heading font, letter-spaced
- Anime footer quote block
- Copyright line (very muted, small)

═══════════════════════════════════════════════════════════════
STEP 6 — JAVASCRIPT FEATURES (implement all of these)
═══════════════════════════════════════════════════════════════

1. Sticky nav:
   window.addEventListener('scroll') → toggle .scrolled on #navbar at scrollY > 60

2. Mobile menu:
   Build DOM on first open (nav element with close button + all section links)
   Open: classList.add('open') + body overflow hidden
   Close: on link click or close button

3. Typewriter:
   Cycle through roles array. Type forward ~85ms/char, pause 1800ms at full length,
   delete ~45ms/char, pause 400ms before next phrase. Blinking | cursor via CSS.
   Start after 2200ms (after hero letter animation settles).

4. Scroll reveal:
   IntersectionObserver on all .fade-in elements (threshold 0.12, rootMargin -40px bottom)
   When intersecting: add .is-visible → opacity 1, translateY 0 (base state is opacity:0, translateY:30px)

5. Hero parallax:
   On scroll, if scrollY < window.innerHeight:
   heroBg.style.transform = `scale(1.05) translateY(${scrollY * 0.25}px)`

6. Project card 3D tilt:
   mousemove: rotateX = -(clientY - centerY) / (height/2) * 6
              rotateY =  (clientX - centerX) / (width/2)  * 6
   mouseleave: reset to identity, transition 0.5s ease
   mouseenter: transition 0.1s ease (snappy follow)

7. Skill tag stagger:
   IntersectionObserver on .skills-notebook (threshold 0.2)
   When visible: forEach tag → set opacity:0, translateY:12px, then requestAnimationFrame
   to restore with transition delay = index * 30ms

8. CP stat counters:
   IntersectionObserver on #cp section (threshold 0.3)
   When visible: each .cp-stat-value → read parseInt, animateCounter(el, target, 1600ms)
   easeOutCubic: progress = 1 - Math.pow(1 - t, 3)

9. Active nav link:
   IntersectionObserver on all section[id] + footer[id] (threshold 0.4)
   When intersecting: toggle .active on matching .nav-links a[href="#id"]

10. Smooth scroll:
    All a[href^="#"] → preventDefault, scrollTo with offset = 70 (navbar height), behavior smooth

═══════════════════════════════════════════════════════════════
STEP 7 — CSS RULES (implement all of these)
═══════════════════════════════════════════════════════════════

- All colors as CSS custom properties on :root (--black, --accent, --gold, etc.)
- Custom scrollbar: width 6px, accent-dark thumb, primary track
- body::before: fixed noise texture (SVG feTurbulence, opacity 0.03, pointer-events none, z-index 9999)
- body cursor: small accent dot via SVG data URI background
- ::selection: accent-dark background, white text
- .fade-in: opacity 0, translateY 30px, transition 0.7s
- .fade-in.is-visible: opacity 1, translateY 0
- .dn-quote.is-visible: left-border flicker animation (accent ↔ accent-dark, 3s infinite)
- All section paddings: 7rem 0
- .section-dark: secondary background color
- Section rule dividers (top/bottom): 1px gradient line (transparent → accent → transparent)
- Fully responsive breakpoints:
    * 900px: single-column about, single-column cp, single-column contact, hamburger nav
    * 600px: reduced section padding, smaller hero font, reduced container padding

═══════════════════════════════════════════════════════════════
STEP 8 — FILE OUTPUT
═══════════════════════════════════════════════════════════════

Output three complete files:

1. index.html  — all 10 sections with correct semantic structure
2. style.css   — all styles, variables, animations, responsive rules
3. script.js   — all 10 JS features listed above

Rules:
- Zero external JS libraries
- Zero CSS frameworks
- Google Fonts via <link> only
- All image paths relative: assets/filename.png
- No inline styles except one-off overrides (e.g. z-index on a container)
- Comments separating each major section in all three files

═══════════════════════════════════════════════════════════════
STEP 9 — ANIME PHOTO CONVERSION (run this Python script first)
═══════════════════════════════════════════════════════════════

Save as convert_anime.py, install deps with:
  pip install opencv-python Pillow

Then run:
  python3 convert_anime.py assets/your-real-photo.png assets/your-anime.png

Script:

import cv2, numpy as np, sys
from PIL import Image, ImageEnhance, ImageFilter

def pil_to_cv(img): return cv2.cvtColor(np.array(img.convert("RGB")), cv2.COLOR_RGB2BGR)
def cv_to_pil(img): return Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))

def posterize(img, levels=7):
    f = 255.0 / (levels - 1)
    return np.clip(np.round(img / f) * f, 0, 255).astype(np.uint8)

def convert(src, dst):
    pil = Image.open(src).convert("RGB")
    W, H = pil.size
    pil = pil.resize((W*2, H*2), Image.LANCZOS)
    img = pil_to_cv(pil)
    smooth = img.copy()
    for _ in range(7): smooth = cv2.bilateralFilter(smooth, 9, 75, 75)
    gray = cv2.GaussianBlur(cv2.cvtColor(smooth, cv2.COLOR_BGR2GRAY), (5,5), 0)
    edges = cv2.dilate(cv2.Canny(gray, 35, 100), np.ones((2,2), np.uint8), iterations=1)
    edge_mask = cv2.cvtColor(cv2.bitwise_not(edges), cv2.COLOR_GRAY2BGR)
    flat = posterize(smooth)
    anime = np.clip(flat.astype(np.float32) * (edge_mask.astype(np.float32)/255), 0, 255).astype(np.uint8)
    result = cv_to_pil(anime)
    result = ImageEnhance.Color(result).enhance(0.82)
    result = ImageEnhance.Contrast(result).enhance(1.3)
    result = ImageEnhance.Brightness(result).enhance(0.88)
    gray_pil = result.convert("L")
    result.paste(Image.new("RGB", result.size, (35,0,0)), mask=gray_pil.point(lambda p: max(0, 180-p)*2))
    result.paste(Image.new("RGB", result.size, (255,220,140)), mask=gray_pil.point(lambda p: max(0,(p-210)*4)))
    result = result.filter(ImageFilter.UnsharpMask(radius=1.2, percent=140, threshold=2))
    result.resize((W,H), Image.LANCZOS).save(dst, "PNG")
    print(f"Saved {dst}")

convert(sys.argv[1], sys.argv[2])
```

---

## Quick Reference — Fill-In Checklist

Before pasting the prompt, confirm you've filled in:

- [ ] Anime name and color palette
- [ ] All 4 wallpaper filenames
- [ ] Your name, email, phone, location
- [ ] All social profile URLs and handles
- [ ] LeetCode + Codeforces stats
- [ ] Typewriter role titles
- [ ] Hero eyebrow text
- [ ] Education details
- [ ] Work experience bullets and tech tags
- [ ] All 5 skill groups
- [ ] 3 projects with GitHub + live links
- [ ] Achievements and responsibilities
- [ ] 7 adapted anime quotes
- [ ] Photo filenames (real + anime-converted)

## Example Anime Themes

| Anime | Bg | Accent | Secondary | Heading Font |
|---|---|---|---|---|
| Death Note | `#0a0a0a` | `#cc0000` | `#c8a951` | Cinzel Decorative |
| Naruto | `#0a0a0f` | `#ff6b00` | `#ffd700` | Cinzel Decorative |
| Attack on Titan | `#0d0d0d` | `#8b6914` | `#c0c0c0` | MedievalSharp |
| Demon Slayer | `#0a0010` | `#ff4499` | `#00ccff` | Sawarabi Mincho |
| Jujutsu Kaisen | `#080810` | `#6600ff` | `#00ffcc` | Cinzel Decorative |
| One Piece | `#0a0f1a` | `#ff3300` | `#ffd700` | Pirata One |
| Bleach | `#0a0a12` | `#4444ff` | `#ffffff` | Cinzel Decorative |
