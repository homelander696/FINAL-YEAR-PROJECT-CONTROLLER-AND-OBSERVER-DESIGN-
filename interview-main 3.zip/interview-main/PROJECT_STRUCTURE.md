# Project Structure – Components and How They Connect

This document explains the layout of the **Interview Insights** codebase and how the frontend, backend, and data flow connect.

---

## High-level architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend (React + Vite)                   │
│  Browser → React app → api() / fetch → Backend API                │
└─────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTP (JSON), JWT in Authorization
                                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Backend (Node + Express)                     │
│  server.js → routes (auth, companies) → middleware → MongoDB      │
└─────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Mongoose
                                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                      MongoDB (Atlas / local)                      │
│  Collections: users, companies (with rounds), otps                │
└─────────────────────────────────────────────────────────────────┘
```

- **Frontend:** Single-page app (SPA). All API calls go to one base URL (e.g. `http://localhost:5000`). Auth: JWT stored in `localStorage`; sent as `Authorization: Bearer <token>`.
- **Backend:** REST API. Auth middleware checks JWT and sets `req.user`. Routes read/write MongoDB via Mongoose. Optional AI: Gemini service for summarize and suggest-questions.

---

## Repository layout

```
interview-main/
├── backend/                 # Node + Express API
│   ├── config/              # DB connection
│   ├── middleware/          # Auth (JWT, admin)
│   ├── models/              # Mongoose schemas (User, Company, Otp)
│   ├── routes/              # auth.js, companies.js
│   ├── services/            # gemini.js (AI)
│   ├── utils/               # mailer.js
│   ├── server.js            # Entry, CORS, mount routes
│   ├── .env.example
│   └── package.json
│
├── frontend/                # React + Vite SPA
│   ├── public/              # Static assets (e.g. brands/)
│   ├── src/
│   │   ├── components/      # Reusable UI
│   │   ├── pages/           # Route-level views
│   │   ├── api.js           # HTTP helper + token
│   │   ├── auth.js          # User state (localStorage)
│   │   ├── App.jsx          # Routes + MarketingHome + NotFound
│   │   └── main.jsx         # React root, Router
│   ├── index.html
│   └── package.json
│
├── user_guide.md            # How to run and use the app
├── interview_questions.md   # Suggest-questions feature and examples
└── PROJECT_STRUCTURE.md      # This file
```

---

## Frontend structure

### Entry and routing

- **main.jsx** – Renders `<App />` inside `BrowserRouter` and an error boundary. Imports `index.css` (Tailwind).
- **App.jsx** – Defines all `<Route>`s and the **MarketingHome** (landing) and **NotFound** components. No backend calls on landing; protected routes use `<ProtectedRoute>`.

### Pages (route-level views)

| Route | Component | Purpose |
|-------|-----------|--------|
| `/` | MarketingHome (in App.jsx) | Landing: hero, company logos (links to Wikipedia), Get started / Login |
| `/login` | Login.jsx | Login form; also handles Signup and Forgot tabs (OTP flow) |
| `/signup` | Login with defaultTab="signup" | Same as Login, signup tab focused |
| `/dashboard` | UserDashboard.jsx | Explore approved experiences + My Submissions, search |
| `/company/:id` | CompanyDetail.jsx | One experience: rounds, Summarize, Suggest questions |
| `/add-experience` | AddExperience.jsx | Form: company, college, year, rounds; submit for approval |
| `/admin` | AdminDashboard.jsx | Admin: Pending / All, Approve, Reject, Delete |
| `*` | NotFound (in App.jsx) | 404 with “Go to home” |

### Components (reusable UI)

| Component | Role |
|-----------|------|
| **Navbar** | Logo, Dashboard / Add Experience (for users), Admin (for admin), user initials, Login/Signup or Logout; mobile hamburger + drawer |
| **ProtectedRoute** | Wraps routes that need login; redirects to `/login` or `/` if role not allowed |
| **Modal** | Overlay + title + children; used for Summary and Suggest questions, and Admin confirmations |
| **Toast** | Fixed toast for success/error (Admin) |
| **Spinner** | Loading indicator (Lucide Loader2) |
| **EmptyState** | Icon + title + description + optional CTA for empty lists |

### Data and auth (no backend in these files)

- **api.js** – `api(path, { method, body, auth })`: `fetch` to `VITE_API_URL` + path, JSON body, `Authorization: Bearer <token>` when `auth` is true. On 4xx/5xx reads `msg` or `error` from JSON and throws. Exports `getToken`, `setToken`, `clearToken`.
- **auth.js** – `authStore`: in-memory `user` plus sync with `localStorage` for `user` and `token`; `setUser`, `setToken`, `clear`, `logout` (clear + redirect to `/`).

### How frontend and backend connect

- **Auth:** Login/Signup/Forgot call `POST /api/auth/*`. On success, frontend stores `token` and `user` and redirects. Every other API call uses `api()` which sends the stored token. Backend `requireAuth` middleware verifies JWT and sets `req.user`.
- **Companies:**  
  - List: `GET /api/companies` (admin can filter by status), `GET /api/companies/mine`.  
  - One: `GET /api/companies/:id`.  
  - Create: `POST /api/companies` with `{ name, college, year, rounds }`.  
  - AI: `GET /api/companies/:id/summarize`, `GET /api/companies/:id/suggest-questions`.  
  - Admin: `PATCH /api/companies/:id/approve`, `PATCH /api/companies/:id/reject`, `DELETE /api/companies/:id`.

---

## Backend structure

### Entry and middleware

- **server.js** – Loads `dotenv`, creates Express app, `express.json()`, CORS (origin from `FRONTEND_URL`), mounts `/api/auth` and `/api/companies`, health `GET /`, then `connectDB()` and `app.listen(PORT)`. Logs: `[Server]`, `[DB]`.
- **middleware/auth.js** – `requireAuth`: reads `Authorization: Bearer <token>`, verifies JWT with `JWT_SECRET`, sets `req.user = { id, role }`; on failure returns 401 and logs. `requireAdmin`: returns 403 if `req.user.role !== "admin"`.

### Routes

- **routes/auth.js** – No auth middleware on these:
  - `POST /api/auth/signup/request-otp` – body: name, email, password → create OTP, send email.
  - `POST /api/auth/signup/verify-otp` – body: email, otp → create user, delete OTP.
  - `POST /api/auth/login` – body: email, password → returns token, user, redirect.
  - `POST /api/auth/forgot/request-otp` – body: email → OTP for reset.
  - `POST /api/auth/forgot/reset` – body: email, otp, newPassword → update user, delete OTP.
- **routes/companies.js** – All under `requireAuth`; some use `requireAdmin`:
  - `POST /` – create company (pending), body: name, rounds, year, college.
  - `GET /` – list (admin: filter by status; user: approved only).
  - `GET /mine` – list by `createdBy = req.user.id`.
  - `GET /pending` – admin, pending only.
  - `GET /:id/summarize` – same access as `GET /:id`, returns AI summary.
  - `GET /:id/suggest-questions` – same access, returns 10 questions.
  - `GET /:id` – one company (admin: any; user: approved or own).
  - `PATCH /:id/approve`, `PATCH /:id/reject` – admin.
  - `DELETE /:id` – admin.

Helpers in companies.js: `getCompanyIfAllowed(req, res)` (load company and enforce same visibility as GET `:id`), `buildExperienceText(c)` (string for Gemini).

### Models (Mongoose)

- **User** – name, email, password (hashed), role (user | admin).
- **Company** – name, rounds (array of { title, notes, result }), status (pending | approved | rejected), rejectionReason, createdBy (ref User), year, college; timestamps.
- **Otp** – email, otp, expireAt, data (e.g. signup payload or reset flag).

### Services

- **services/gemini.js** – Uses `GEMINI_API_KEY` and `@google/generative-ai` (Gemini 2.0 Flash). `generateSummary(experienceText)` returns a short bullet summary; `generateSuggestQuestions(experienceText)` returns an array of 10 question strings. Called only from companies routes; errors lead to 502.

### Config and utils

- **config/db.js** – `connectDB()`: `mongoose.connect(MONGO_URI)`.
- **utils/mailer.js** – Nodemailer transport from env; `sendOtpEmail(to, otp)`.

---

## Data flow examples

1. **Login** – User submits email/password → `POST /api/auth/login` → backend checks User, bcrypt, JWT sign → frontend stores token + user, redirects to dashboard or admin.
2. **View experience** – User opens `/company/123` → `GET /api/companies/123` with Bearer token → backend `getCompanyIfAllowed` loads company and checks access → returns company + rounds → CompanyDetail renders; “Summarize” / “Suggest questions” call the same ID with `/summarize` and `/suggest-questions`, which use `buildExperienceText` and Gemini.
3. **Admin approve** – Admin clicks Approve on a card → `PATCH /api/companies/:id/approve` with Bearer token → `requireAdmin` then update status → frontend updates list.

---

## Summary

- **Frontend:** React app with pages (landing, login/signup, dashboard, company detail, add experience, admin) and shared components (Navbar, Modal, Toast, Spinner, EmptyState, ProtectedRoute). Talks to backend via `api()` and JWT.
- **Backend:** Express API with auth and companies routes, Mongoose models (User, Company, Otp), and optional Gemini service for summary and suggest-questions. Logs use `[Server]`, `[DB]`, `[Auth]`, `[Companies]`, `[Gemini]`.
- **Connection:** REST + JSON, JWT in header, CORS for frontend origin. No WebSockets; all state from API responses and localStorage (token/user).
