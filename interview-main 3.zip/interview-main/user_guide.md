# User Guide – Interview Insights Platform

This guide explains how to run the project locally and how to use the application as a user.

---

## Prerequisites

- **Node.js** (v20.x or later recommended). Check with `node -v`.
- **npm** (comes with Node). Check with `npm -v`.
- **MongoDB** – A MongoDB database (e.g. [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) free tier). You need a connection URI.
- **Google Gemini API key** (optional but required for AI features: Summarize and Suggest questions). Get one from [Google AI Studio](https://aistudio.google.com/apikey).

---

## How to Run the Project

### 1. Clone and open the project

```bash
cd /path/to/interview-main
```

### 2. Backend setup

1. **Install dependencies**

   ```bash
   cd backend
   npm install
   ```

2. **Configure environment**

   - Copy the example env file:
     ```bash
     cp .env.example .env
     ```
   - Edit `.env` and set at least:
     - `MONGO_URI` – Your MongoDB connection string (e.g. from Atlas).
     - `JWT_SECRET` – Any long random string for signing tokens.
     - `ADMIN_EMAIL` – The email that will get admin role on signup.
     - `GEMINI_API_KEY` – Your Gemini API key (needed for Summarize and Suggest questions).
   - Optionally set: `PORT` (default 5000), `FRONTEND_URL` (default http://localhost:5173), `OTP_EXPIRE_MIN`, and SMTP vars if you use email OTP.

3. **Start the backend**

   ```bash
   npm run dev
   ```

   You should see logs like `[DB] Connected` and `[Server] Listening on port 5000`. Leave this terminal running.

### 3. Frontend setup

1. **Open a new terminal** and go to the frontend folder:

   ```bash
   cd frontend
   npm install
   ```

2. **Configure environment (optional)**

   - Create `frontend/.env` if the API is not at `http://localhost:5000`:
     ```
     VITE_API_URL=http://localhost:5000
     ```

3. **Start the frontend**

   ```bash
   npm run dev
   ```

   Vite will show a URL, usually **http://localhost:5173**. Open it in your browser.

### 4. Use the app

- **Landing:** http://localhost:5173/ – Hero, company logos (click to open Wikipedia), Get started / Login.
- **Sign up:** Click “Get started” or go to `/signup`. Enter name, email, password → Request OTP → Check email → Enter OTP → Verify. Then log in.
- **Log in:** `/login` – Email + password. “Forgot” uses OTP to reset password.
- **Dashboard:** After login you are redirected to `/dashboard`. Use “Explore” to see approved experiences and “My Submissions” to see your own (pending/approved/rejected). Search works on both.
- **Add experience:** Click “Add Experience” (or go to `/add-experience`). Fill company name, optional college and year, then add rounds (title, notes, result). Submit for approval.
- **View an experience:** Click a company card to open its detail page. You see rounds, notes, and status. Use **Summarize** for an AI summary and **Suggest questions** for top 10 questions to prepare (requires `GEMINI_API_KEY`).
- **Admin:** Log in with the email set as `ADMIN_EMAIL`. You get “Dashboard” → Admin panel. There you can see “Pending” and “All”, and Approve / Reject / Delete submissions.

---

## Production build

- **Frontend:** From `frontend/` run `npm run build`. Output is in `frontend/dist`. Serve with any static host (e.g. Vercel, Netlify) and set `VITE_API_URL` to your backend URL.
- **Backend:** Set all env vars on the server and run `npm start` (or `node server.js`). Ensure `FRONTEND_URL` matches your frontend origin for CORS.

---

## Troubleshooting

- **“vite: command not found”** – Run `npm install` in the `frontend` folder.
- **“MongoDB connection failed”** – Check `MONGO_URI` in `backend/.env` and that the IP is allowed in Atlas (e.g. 0.0.0.0/0 for dev).
- **“Summary unavailable” / “Suggestions unavailable”** – Set `GEMINI_API_KEY` in `backend/.env`.
- **401 on API calls** – Log in again; the JWT may have expired (default 5h).
