"""
NinjaScope Music Generator
Generates a Naruto-inspired ambient ninja melody using numpy sine waves.
Outputs: ../frontend/public/music/ninja-theme.wav
"""

import numpy as np
import wave
import struct
import os

SAMPLE_RATE = 44100
MASTER_VOLUME = 0.35

def note_freq(note: str) -> float:
    """Convert note name (e.g. 'A4', 'E5') to frequency in Hz."""
    notes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    name = note[:-1]
    octave = int(note[-1])
    semitone = notes.index(name)
    # A4 = 440 Hz, MIDI note 69
    midi = (octave + 1) * 12 + semitone
    return 440.0 * (2.0 ** ((midi - 69) / 12.0))

def sine_wave(freq: float, duration: float, volume: float = 1.0, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    # Add slight overtones for a richer, flute-like sound
    wave = (
        np.sin(2 * np.pi * freq * t) * 0.6
        + np.sin(2 * np.pi * freq * 2 * t) * 0.25
        + np.sin(2 * np.pi * freq * 3 * t) * 0.10
        + np.sin(2 * np.pi * freq * 0.5 * t) * 0.05
    )
    # Envelope: fade in and out
    fade = int(sample_rate * min(0.05, duration * 0.1))
    if fade > 0:
        wave[:fade] *= np.linspace(0, 1, fade)
        wave[-fade:] *= np.linspace(1, 0, fade)
    return wave * volume

def rest(duration: float, sample_rate: int = SAMPLE_RATE) -> np.ndarray:
    return np.zeros(int(sample_rate * duration))

def build_melody() -> np.ndarray:
    """
    Naruto-inspired pentatonic melody in A minor pentatonic.
    Loosely inspired by the mood of the Naruto main theme.
    Notes: A3, C4, D4, E4, G4, A4, C5, E5
    """
    BPM = 90
    beat = 60.0 / BPM

    # (note_or_rest, beats, volume_multiplier)
    melody_score = [
        # Phrase 1 — opening
        ('E4', 1.0,  0.9),
        ('A4', 0.5,  0.85),
        ('G4', 0.5,  0.8),
        ('E4', 1.0,  0.9),
        ('D4', 1.5,  0.85),
        ('R',  0.5,  0),
        # Phrase 2
        ('C4', 0.75, 0.8),
        ('D4', 0.75, 0.85),
        ('E4', 0.5,  0.9),
        ('A4', 2.0,  1.0),
        ('R',  0.5,  0),
        # Phrase 3 — climbing
        ('A3', 0.5,  0.75),
        ('C4', 0.5,  0.78),
        ('E4', 0.5,  0.82),
        ('G4', 0.5,  0.88),
        ('A4', 1.0,  1.0),
        ('C5', 1.5,  0.95),
        ('R',  0.5,  0),
        # Phrase 4 — descending resolution
        ('A4', 0.75, 0.9),
        ('G4', 0.75, 0.85),
        ('E4', 0.5,  0.8),
        ('D4', 0.5,  0.78),
        ('C4', 0.5,  0.75),
        ('A3', 2.0,  0.85),
        ('R',  1.0,  0),
        # Phrase 5 — emotional bridge
        ('E5', 0.5,  1.0),
        ('D5', 0.5,  0.95),
        ('C5', 1.0,  0.9),
        ('A4', 0.5,  0.88),
        ('G4', 0.5,  0.85),
        ('E4', 1.5,  0.9),
        ('R',  0.5,  0),
        # Phrase 6 — restatement
        ('E4', 1.0,  0.9),
        ('A4', 0.5,  0.85),
        ('G4', 0.5,  0.8),
        ('E4', 1.0,  0.85),
        ('A4', 3.0,  0.95),
        ('R',  1.0,  0),
    ]

    # Ambient drone layer (low A2 hum throughout)
    drone_freq = note_freq('A2')
    total_beats = sum(b for _, b, _ in melody_score)
    total_duration = total_beats * beat
    t_drone = np.linspace(0, total_duration, int(SAMPLE_RATE * total_duration), endpoint=False)
    drone = (
        np.sin(2 * np.pi * drone_freq * t_drone) * 0.12
        + np.sin(2 * np.pi * drone_freq * 2 * t_drone) * 0.06
    )

    # Build melody
    segments = []
    for entry in melody_score:
        sym, beats, vol = entry
        dur = beats * beat
        if sym == 'R':
            segments.append(rest(dur))
        else:
            segments.append(sine_wave(note_freq(sym), dur, vol * MASTER_VOLUME))

    melody = np.concatenate(segments)

    # Mix melody + drone
    min_len = min(len(melody), len(drone))
    mixed = melody[:min_len] + drone[:min_len] * MASTER_VOLUME

    # Normalise
    peak = np.max(np.abs(mixed))
    if peak > 0:
        mixed = mixed / peak * 0.90

    # Fade in/out entire track
    fade_secs = 2.0
    fade_samples = int(SAMPLE_RATE * fade_secs)
    mixed[:fade_samples] *= np.linspace(0, 1, fade_samples)
    mixed[-fade_samples:] *= np.linspace(1, 0, fade_samples)

    return mixed

def save_wav(data: np.ndarray, path: str, sample_rate: int = SAMPLE_RATE) -> None:
    int_data = (data * 32767).astype(np.int16)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with wave.open(path, 'w') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(struct.pack(f'<{len(int_data)}h', *int_data))
    print(f"[NinjaScope] Music saved → {path}")

if __name__ == '__main__':
    output_path = os.path.join(
        os.path.dirname(__file__),
        '..', 'frontend', 'public', 'music', 'ninja-theme.wav'
    )
    print("[NinjaScope] Composing ninja melody...")
    audio = build_melody()
    save_wav(audio, os.path.abspath(output_path))
    duration = len(audio) / SAMPLE_RATE
    print(f"[NinjaScope] Done! Duration: {duration:.1f}s  —  Believe it! 🍥")
