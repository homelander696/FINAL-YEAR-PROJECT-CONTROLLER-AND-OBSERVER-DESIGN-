const express = require('express');
const router = express.Router();
const { getUser, getUserRepos } = require('../controllers/githubController');

router.get('/user/:username', getUser);
router.get('/user/:username/repos', getUserRepos);

module.exports = router;
