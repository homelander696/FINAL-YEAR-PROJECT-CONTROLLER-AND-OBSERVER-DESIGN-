const express = require('express');
const router = express.Router();
const axios = require('axios');

router.post('/summarize', async (req, res) => {
  const { profile, repos } = req.body;
  if (!profile) return res.status(400).json({ error: 'Profile data required.' });

  const langCount = {};
  repos?.forEach((r) => {
    if (r.language) langCount[r.language] = (langCount[r.language] || 0) + 1;
  });
  const topLangs = Object.entries(langCount).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const totalStars = repos?.reduce((a, r) => a + (r.stargazers_count || 0), 0) ?? 0;
  const totalForks = repos?.reduce((a, r) => a + (r.forks_count || 0), 0) ?? 0;
  const topRepos = repos?.slice(0, 5).map((r) => `${r.name}(★${r.stargazers_count})`).join(', ') ?? '';
  const avgStars = repos?.length ? (totalStars / repos.length).toFixed(1) : 0;

  const prompt = `You are a Naruto-themed GitHub analyzer named ShinobiAI. Analyze this GitHub profile:

Name: ${profile.name || profile.login} (@${profile.login})
Bio: ${profile.bio || 'No bio provided'}
Followers: ${profile.followers} | Following: ${profile.following}
Public Repos: ${profile.public_repos} | Public Gists: ${profile.public_gists || 0}
Total Stars Earned: ${totalStars} | Total Forks: ${totalForks}
Avg Stars per Repo: ${avgStars}
Top Languages: ${topLangs.map(([l, c]) => `${l}(${c} repos)`).join(', ') || 'Unknown'}
Most Starred Repos: ${topRepos}
Account Age: joined ${profile.created_at ? new Date(profile.created_at).getFullYear() : 'unknown'}

Return ONLY valid JSON, no markdown, no explanation:
{
  "ninja_rank": "one of: Genin | Chunin | Jonin | ANBU | Kage",
  "ninja_title": "creative ninja title based on their code style e.g. Shadow JS Weaver",
  "summary": "3 sentence Naruto-flavored summary of their coding journey and style",
  "strengths": ["3 specific strengths based on their stats"],
  "weakness": "one specific improvement area",
  "special_jutsu": "their signature skill named as a Naruto jutsu e.g. Python Shadow Clone Jutsu",
  "chakra_level": <integer 0-100 based on overall activity score>,
  "personality": "Which Naruto character they code like and why (1 sentence)",
  "insights": ["3 specific data-driven insights from their stats"],
  "verdict": "one punchy one-liner verdict in Naruto style"
}`;

  try {
    const { data } = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      { contents: [{ parts: [{ text: prompt }] }] },
      { timeout: 20000 }
    );

    const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('No JSON found in AI response');
    res.json(JSON.parse(match[0]));
  } catch (err) {
    res.status(500).json({ error: 'AI jutsu failed: ' + (err.response?.data?.error?.message || err.message) });
  }
});

router.post('/compare', async (req, res) => {
  const { profile1, repos1, profile2, repos2 } = req.body;
  if (!profile1 || !profile2) return res.status(400).json({ error: 'Two profiles required.' });

  const summarize = (profile, repos) => {
    const totalStars = repos?.reduce((a, r) => a + (r.stargazers_count || 0), 0) ?? 0;
    const langCount = {};
    repos?.forEach((r) => { if (r.language) langCount[r.language] = (langCount[r.language] || 0) + 1; });
    const topLang = Object.entries(langCount).sort((a, b) => b[1] - a[1])[0]?.[0] || 'Unknown';
    return { name: profile.name || profile.login, repos: profile.public_repos, followers: profile.followers, stars: totalStars, topLang };
  };

  const s1 = summarize(profile1, repos1);
  const s2 = summarize(profile2, repos2);

  const prompt = `Compare these two GitHub profiles in Naruto ninja battle style:

Shinobi 1: ${s1.name} — ${s1.repos} repos, ${s1.followers} followers, ${s1.stars} total stars, top language: ${s1.topLang}
Shinobi 2: ${s2.name} — ${s2.repos} repos, ${s2.followers} followers, ${s2.stars} total stars, top language: ${s2.topLang}

Return ONLY valid JSON:
{
  "winner": "login of the stronger GitHub shinobi based on overall activity",
  "battle_summary": "2 sentence Naruto-battle-style comparison",
  "shinobi1_rank": "Genin/Chunin/Jonin/ANBU/Kage",
  "shinobi2_rank": "Genin/Chunin/Jonin/ANBU/Kage",
  "shinobi1_jutsu": "their signature jutsu",
  "shinobi2_jutsu": "their signature jutsu",
  "verdict": "Who wins and why in one dramatic Naruto-style sentence"
}`;

  try {
    const { data } = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      { contents: [{ parts: [{ text: prompt }] }] },
      { timeout: 20000 }
    );
    const raw = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('No JSON in response');
    res.json(JSON.parse(match[0]));
  } catch (err) {
    res.status(500).json({ error: 'Compare jutsu failed: ' + err.message });
  }
});

module.exports = router;
