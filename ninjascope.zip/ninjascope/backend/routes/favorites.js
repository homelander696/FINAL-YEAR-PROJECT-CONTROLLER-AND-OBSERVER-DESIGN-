const express = require('express');
const router = express.Router();
const FavoriteProfile = require('../models/FavoriteProfile');

// Get all favorites
router.get('/', async (req, res) => {
  try {
    const favorites = await FavoriteProfile.find().sort({ createdAt: -1 });
    res.json(favorites);
  } catch {
    res.status(500).json({ error: 'Failed to retrieve your ninja squad.' });
  }
});

// Add a favorite
router.post('/', async (req, res) => {
  const { username, name, avatar_url, html_url, bio, public_repos, followers, following } = req.body;
  if (!username) return res.status(400).json({ error: 'Username is required to join your squad.' });
  try {
    const favorite = await FavoriteProfile.findOneAndUpdate(
      { username: username.toLowerCase() },
      { username: username.toLowerCase(), name, avatar_url, html_url, bio, public_repos, followers, following },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    res.status(201).json(favorite);
  } catch {
    res.status(500).json({ error: 'Could not add shinobi to your squad.' });
  }
});

// Remove a favorite
router.delete('/:username', async (req, res) => {
  try {
    await FavoriteProfile.findOneAndDelete({ username: req.params.username.toLowerCase() });
    res.json({ message: 'Shinobi removed from your squad.' });
  } catch {
    res.status(500).json({ error: 'Failed to remove shinobi.' });
  }
});

module.exports = router;
