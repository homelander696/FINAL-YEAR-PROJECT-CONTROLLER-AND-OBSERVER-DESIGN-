const axios = require('axios');

const githubApi = axios.create({
  baseURL: 'https://api.github.com',
  headers: {
    Accept: 'application/vnd.github+json',
    ...(process.env.GITHUB_TOKEN && {
      Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
    }),
  },
});

const getUser = async (req, res) => {
  const { username } = req.params;
  try {
    const { data } = await githubApi.get(`/users/${username}`);
    res.json(data);
  } catch (err) {
    const status = err.response?.status || 500;
    const message =
      status === 404
        ? `Shinobi "${username}" not found in the Ninja Registry!`
        : 'The GitHub API is unavailable. Try again later.';
    res.status(status).json({ error: message });
  }
};

const getUserRepos = async (req, res) => {
  const { username } = req.params;
  const { sort = 'stars', per_page = 30 } = req.query;
  try {
    const { data } = await githubApi.get(`/users/${username}/repos`, {
      params: { sort, per_page, direction: 'desc' },
    });
    res.json(data);
  } catch (err) {
    const status = err.response?.status || 500;
    res.status(status).json({ error: 'Failed to fetch scrolls (repos) from the Ninja Registry.' });
  }
};

module.exports = { getUser, getUserRepos };
