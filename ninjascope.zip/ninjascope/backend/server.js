require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const rateLimit = require('express-rate-limit');

const githubRoutes = require('./routes/github');
const favoritesRoutes = require('./routes/favorites');
const aiRoutes = require('./routes/ai');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: ['http://localhost:5173', 'http://localhost:3000'] }));
app.use(express.json());

const limiter = rateLimit({ windowMs: 60 * 1000, max: 60, message: { error: 'Too many jutsu! Slow down, shinobi.' } });
app.use('/api/', limiter);

app.use('/api/github', githubRoutes);
app.use('/api/favorites', favoritesRoutes);
app.use('/api/ai', aiRoutes);

app.get('/api/health', (_, res) => res.json({ status: 'ok', message: 'NinjaScope backend is alive — Believe it!' }));

app.use((req, res) => res.status(404).json({ error: 'This jutsu does not exist.' }));

mongoose
  .connect(process.env.MONGODB_URI, {
    dbName: 'ninjascope',
    serverSelectionTimeoutMS: 8000,
    socketTimeoutMS: 45000,
  })
  .then(() => {
    console.log('🍥 MongoDB connected — Konoha database online');
    app.listen(PORT, () => console.log(`⚡ NinjaScope backend running on port ${PORT}`));
  })
  .catch((err) => {
    console.warn('⚠️  MongoDB connection failed. Starting without database:', err.message);
    app.listen(PORT, () => console.log(`⚡ NinjaScope backend running on port ${PORT} (no DB)`));
  });
