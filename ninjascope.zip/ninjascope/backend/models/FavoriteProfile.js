const mongoose = require('mongoose');

const favoriteProfileSchema = new mongoose.Schema(
  {
    username: { type: String, required: true, unique: true, lowercase: true, trim: true },
    name: { type: String, default: '' },
    avatar_url: { type: String, default: '' },
    html_url: { type: String, default: '' },
    bio: { type: String, default: '' },
    public_repos: { type: Number, default: 0 },
    followers: { type: Number, default: 0 },
    following: { type: Number, default: 0 },
  },
  { timestamps: true }
);

module.exports = mongoose.model('FavoriteProfile', favoriteProfileSchema);
