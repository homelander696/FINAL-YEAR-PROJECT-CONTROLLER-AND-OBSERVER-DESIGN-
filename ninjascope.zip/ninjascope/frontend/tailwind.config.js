/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        ninja: {
          dark: '#0d1b2a',
          darker: '#060f18',
          navy: '#1a2d45',
          orange: '#ff6b00',
          'orange-light': '#ff8c38',
          gold: '#f39c12',
          red: '#c0392b',
          'red-light': '#e74c3c',
          green: '#27ae60',
          teal: '#16a085',
          purple: '#8e44ad',
          muted: '#7f8c8d',
          light: '#ecf0f1',
          card: '#112233',
          'card-light': '#f8f4ef',
          'bg-light': '#fff8f0',
        },
      },
      fontFamily: {
        cinzel: ['"Cinzel"', 'serif'],
        noto: ['"Noto Serif JP"', 'serif'],
        sans: ['"Inter"', 'sans-serif'],
      },
      animation: {
        'spin-slow': 'spin 8s linear infinite',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'float': 'float 6s ease-in-out infinite',
        'chakra': 'chakra 4s linear infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'slide-up': 'slideUp 0.5s ease-out',
        'fade-in': 'fadeIn 0.6s ease-out',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-15px)' },
        },
        chakra: {
          '0%': { transform: 'rotate(0deg)', boxShadow: '0 0 10px #ff6b00' },
          '50%': { boxShadow: '0 0 30px #f39c12, 0 0 60px #ff6b00' },
          '100%': { transform: 'rotate(360deg)', boxShadow: '0 0 10px #ff6b00' },
        },
        glow: {
          from: { textShadow: '0 0 5px #ff6b00, 0 0 10px #ff6b00' },
          to: { textShadow: '0 0 20px #f39c12, 0 0 40px #ff6b00, 0 0 60px #ff6b00' },
        },
        slideUp: {
          from: { opacity: 0, transform: 'translateY(30px)' },
          to: { opacity: 1, transform: 'translateY(0)' },
        },
        fadeIn: {
          from: { opacity: 0 },
          to: { opacity: 1 },
        },
      },
      backgroundImage: {
        'ninja-gradient': 'linear-gradient(135deg, #0d1b2a 0%, #1a2d45 50%, #0d1b2a 100%)',
        'orange-gradient': 'linear-gradient(135deg, #ff6b00, #f39c12)',
        'card-gradient': 'linear-gradient(145deg, #112233, #0d1b2a)',
        'light-gradient': 'linear-gradient(135deg, #fff8f0 0%, #ffe8cc 50%, #fff8f0 100%)',
      },
      boxShadow: {
        'ninja': '0 0 20px rgba(255,107,0,0.3), 0 4px 20px rgba(0,0,0,0.5)',
        'ninja-lg': '0 0 40px rgba(255,107,0,0.5), 0 8px 40px rgba(0,0,0,0.7)',
        'card': '0 4px 30px rgba(0,0,0,0.4)',
      },
    },
  },
  plugins: [],
};
