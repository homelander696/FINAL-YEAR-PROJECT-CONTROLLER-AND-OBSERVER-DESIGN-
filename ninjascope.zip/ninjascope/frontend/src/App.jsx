import { Toaster } from 'react-hot-toast';
import { ThemeProvider } from './context/ThemeContext';
import ChakraBackground from './components/ChakraBackground';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Footer from './components/Footer';
import MusicPlayer from './components/MusicPlayer';
import TechStackModal from './components/TechStackModal';

export default function App() {
  return (
    <ThemeProvider>
      <div className="relative min-h-screen">
        <ChakraBackground />
        <Navbar />
        <Home />
        <Footer />
        <MusicPlayer />
        <TechStackModal />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#112233',
              color: '#ecf0f1',
              border: '1px solid rgba(255,107,0,0.3)',
              fontFamily: 'Inter, sans-serif',
              fontSize: '13px',
            },
          }}
        />
      </div>
    </ThemeProvider>
  );
}
