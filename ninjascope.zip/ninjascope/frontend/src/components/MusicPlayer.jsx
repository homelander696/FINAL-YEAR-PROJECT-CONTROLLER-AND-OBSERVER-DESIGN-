import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function MusicPlayer() {
  const audioRef = useRef(null);
  const [muted, setMuted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.loop = true;
    audio.volume = 0.25;

    // Autoplay — browsers may block until user interaction
    const tryPlay = () => {
      audio.play().then(() => {
        setPlaying(true);
      }).catch(() => {
        // Will play after first user interaction
      });
    };

    tryPlay();

    // Fallback: try on first user click
    const onInteraction = () => {
      if (!playing) {
        audio.play().then(() => setPlaying(true)).catch(() => {});
      }
      document.removeEventListener('click', onInteraction);
      document.removeEventListener('keydown', onInteraction);
    };
    document.addEventListener('click', onInteraction);
    document.addEventListener('keydown', onInteraction);

    return () => {
      document.removeEventListener('click', onInteraction);
      document.removeEventListener('keydown', onInteraction);
    };
  }, []);

  const toggle = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (muted) {
      audio.muted = false;
      if (!playing) {
        audio.play().then(() => setPlaying(true)).catch(() => {});
      }
      setMuted(false);
    } else {
      audio.muted = true;
      setMuted(true);
    }
    setShowToast(true);
    setTimeout(() => setShowToast(false), 2000);
  };

  return (
    <>
      <audio ref={audioRef} src="/music/ninja-theme.wav" preload="auto" />

      {/* Floating music button */}
      <motion.button
        onClick={toggle}
        whileHover={{ scale: 1.15 }}
        whileTap={{ scale: 0.9 }}
        title={muted ? 'Unmute ninja theme' : 'Mute ninja theme'}
        className="fixed bottom-24 right-5 z-50 w-12 h-12 rounded-full border border-ninja-orange/50 bg-ninja-navy/90 backdrop-blur-sm shadow-ninja flex items-center justify-center text-xl"
      >
        <motion.span
          animate={!muted && playing ? { scale: [1, 1.2, 1] } : {}}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          {muted ? '🔇' : '🎵'}
        </motion.span>
      </motion.button>

      {/* Toast */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="fixed bottom-40 right-5 z-50 px-4 py-2 rounded-lg bg-ninja-navy border border-ninja-orange/40 text-xs text-ninja-muted shadow-ninja"
          >
            {muted ? '🔇 Music silenced' : '🎵 Ninja theme playing'}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
