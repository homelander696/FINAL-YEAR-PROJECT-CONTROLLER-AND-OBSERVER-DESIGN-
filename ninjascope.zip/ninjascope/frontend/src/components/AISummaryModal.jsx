import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiX, FiZap } from 'react-icons/fi';
import { summarizeProfile } from '../api/ai';
import { useTheme } from '../context/ThemeContext';

const RANK_META = {
  Genin:  { color: '#22c55e', emoji: '🌱', desc: 'Beginner Shinobi' },
  Chunin: { color: '#3b82f6', emoji: '⚡', desc: 'Intermediate Ninja' },
  Jonin:  { color: '#a855f7', emoji: '🔥', desc: 'Elite Ninja' },
  ANBU:   { color: '#f59e0b', emoji: '🗡️', desc: 'Shadow Operative' },
  Kage:   { color: '#ff6b00', emoji: '👑', desc: 'Village Legend' },
};

function ChakraRing({ level }) {
  const clampedLevel = Math.min(100, Math.max(0, level));
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference - (clampedLevel / 100) * circumference;

  return (
    <div className="relative w-36 h-36 flex items-center justify-center mx-auto">
      <svg width="144" height="144" className="absolute -rotate-90">
        <circle cx="72" cy="72" r={radius} fill="none" stroke="rgba(255,107,0,0.15)" strokeWidth="10" />
        <motion.circle
          cx="72" cy="72" r={radius}
          fill="none" stroke="url(#chakraGrad)" strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: dashOffset }}
          transition={{ duration: 2, ease: 'easeOut' }}
        />
        <defs>
          <linearGradient id="chakraGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#ff6b00" />
            <stop offset="100%" stopColor="#f39c12" />
          </linearGradient>
        </defs>
      </svg>
      <div className="text-center z-10">
        <div className="text-2xl font-black font-cinzel text-ninja-orange">{clampedLevel}</div>
        <div className="text-[10px] text-ninja-muted uppercase tracking-widest">Chakra</div>
      </div>
    </div>
  );
}

export default function AISummaryModal({ profile, repos }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState(null);
  const [error, setError] = useState(null);
  const { isDark } = useTheme();

  const runSummarize = async () => {
    setOpen(true);
    if (summary) return;
    setLoading(true);
    setError(null);
    try {
      const { data } = await summarizeProfile(profile, repos);
      setSummary(data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to summon the AI Jutsu.');
    } finally {
      setLoading(false);
    }
  };

  const rank = summary ? (RANK_META[summary.ninja_rank] || RANK_META.Chunin) : null;

  return (
    <>
      <motion.button
        onClick={runSummarize}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-cinzel font-bold text-sm
                   border-2 border-ninja-orange/60 text-ninja-orange
                   hover:bg-ninja-orange/10 transition-all duration-200"
      >
        <FiZap className="text-ninja-orange" />
        AI Jutsu — Summarize
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4"
            style={{ background: 'rgba(6,15,24,0.9)', backdropFilter: 'blur(8px)' }}
            onClick={() => setOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.85, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.85, y: 40 }}
              transition={{ type: 'spring', stiffness: 300, damping: 28 }}
              onClick={(e) => e.stopPropagation()}
              className={`relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl border-2 shadow-2xl
                          ${isDark ? 'bg-ninja-darker border-ninja-orange/40' : 'bg-white border-orange-300'}`}
              style={{ isolation: 'isolate' }}
            >
              {/* Header */}
              <div className={`sticky top-0 z-10 px-6 py-5 border-b flex items-center justify-between
                              ${isDark ? 'bg-ninja-darker border-ninja-navy' : 'bg-white border-orange-100'}`}
                   style={{ boxShadow: '0 2px 16px rgba(0,0,0,0.4)' }}>
                <div>
                  <h2 className={`font-cinzel text-2xl font-black tracking-wide text-ninja-orange`}>
                    ⚡ ShinobiAI Analysis
                  </h2>
                  <p className={`text-xs mt-1 font-noto italic ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>
                    Powered by Gemini 2.5 Flash — Naruto Edition
                  </p>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className={`p-2 rounded-lg transition-colors ${isDark ? 'text-ninja-muted hover:text-white hover:bg-ninja-navy' : 'text-gray-400 hover:text-gray-900 hover:bg-gray-100'}`}
                >
                  <FiX className="text-xl" />
                </button>
              </div>

              {/* Loading */}
              {loading && (
                <div className="flex flex-col items-center justify-center py-20 gap-4">
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                    className="text-5xl"
                  >
                    🌀
                  </motion.div>
                  <p className={`font-cinzel text-sm ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>
                    Channeling chakra... analyzing shinobi...
                  </p>
                </div>
              )}

              {/* Error */}
              {error && !loading && (
                <div className="p-8 text-center">
                  <p className="text-red-400 font-noto text-sm">💨 {error}</p>
                  <button
                    onClick={() => { setSummary(null); setLoading(false); runSummarize(); }}
                    className="mt-4 ninja-btn text-xs"
                  >
                    Try Again
                  </button>
                </div>
              )}

              {/* Results */}
              {summary && !loading && (
                <div className="p-6 space-y-6">
                  {/* Rank + Chakra */}
                  <div className="flex flex-col sm:flex-row items-center gap-6">
                    <ChakraRing level={summary.chakra_level} />
                    <div className="flex-1 text-center sm:text-left">
                      <div className="flex items-center gap-2 justify-center sm:justify-start flex-wrap mb-1">
                        <span className="text-2xl">{rank.emoji}</span>
                        <span className="font-cinzel font-black text-xl" style={{ color: rank.color }}>
                          {summary.ninja_rank}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded-full border ${isDark ? 'border-ninja-navy text-ninja-muted' : 'border-orange-200 text-gray-500'}`}>
                          {rank.desc}
                        </span>
                      </div>
                      <h3 className={`font-cinzel font-bold text-lg mb-2 ${isDark ? 'text-white' : 'text-ninja-dark'}`}>
                        "{summary.ninja_title}"
                      </h3>
                      <p className={`text-sm font-noto leading-relaxed ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>
                        {summary.summary}
                      </p>
                    </div>
                  </div>

                  {/* Special Jutsu */}
                  <div className="rounded-xl border border-ninja-orange/30 bg-ninja-orange/5 p-4 text-center">
                    <p className={`text-xs uppercase tracking-widest font-cinzel mb-1 ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>Signature Jutsu</p>
                    <p className="text-ninja-orange font-bold font-cinzel text-lg">🌀 {summary.special_jutsu}</p>
                  </div>

                  {/* Personality */}
                  {summary.personality && (
                    <div className={`rounded-xl p-4 border ${isDark ? 'bg-ninja-navy/40 border-ninja-navy' : 'bg-orange-50 border-orange-100'}`}>
                      <p className="text-xs uppercase tracking-widest font-cinzel text-ninja-orange mb-1">Codes Like...</p>
                      <p className={`text-sm font-noto italic ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>{summary.personality}</p>
                    </div>
                  )}

                  {/* Strengths & Weakness */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className={`rounded-xl p-4 border ${isDark ? 'bg-ninja-card border-ninja-navy' : 'bg-white border-orange-100 shadow-sm'}`}>
                      <p className="text-xs uppercase tracking-widest font-cinzel text-green-400 mb-3">⚡ Strengths</p>
                      <ul className="space-y-1.5">
                        {summary.strengths?.map((s, i) => (
                          <li key={i} className={`text-xs flex items-start gap-2 ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>
                            <span className="text-green-400 mt-0.5">✓</span> {s}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className={`rounded-xl p-4 border ${isDark ? 'bg-ninja-card border-ninja-navy' : 'bg-white border-orange-100 shadow-sm'}`}>
                      <p className="text-xs uppercase tracking-widest font-cinzel text-ninja-red mb-3">💨 Weakness</p>
                      <p className={`text-xs ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>{summary.weakness}</p>
                    </div>
                  </div>

                  {/* Insights */}
                  <div>
                    <p className="text-xs uppercase tracking-widest font-cinzel text-ninja-orange mb-3">🔍 Scroll Insights</p>
                    <div className="space-y-2">
                      {summary.insights?.map((ins, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.1 }}
                          className={`flex items-start gap-3 p-3 rounded-lg border text-xs ${isDark ? 'bg-ninja-navy/40 border-ninja-navy text-ninja-muted' : 'bg-orange-50 border-orange-100 text-gray-600'}`}
                        >
                          <span className="text-ninja-orange font-bold">0{i + 1}</span>
                          {ins}
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {/* Verdict */}
                  {summary.verdict && (
                    <div className="text-center py-4 border-t border-ninja-orange/20">
                      <p className={`text-sm font-noto italic ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>
                        <span className="text-ninja-orange text-lg">"</span>
                        {summary.verdict}
                        <span className="text-ninja-orange text-lg">"</span>
                      </p>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
