import { motion } from 'framer-motion';
import { useTheme } from '../context/ThemeContext';

export default function Footer() {
  const { isDark } = useTheme();
  return (
    <motion.footer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.5 }}
      className="w-full mt-16 border-t border-ninja-navy/60 py-8 text-center"
    >
      <div className="max-w-3xl mx-auto px-4 space-y-3">
        {/* Naruto spiral */}
        <div className="text-3xl">🍥</div>

        <p className="font-cinzel text-lg font-bold text-ninja-orange tracking-wider">
          NinjaScope
        </p>

        <p className={`text-xs font-noto italic ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>
          "The path to becoming Hokage is never easy — but your GitHub profile speaks volumes."
        </p>

        <div className="section-divider" />

        <p className={`text-xs ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>
          Crafted with ⚡ chakra and ❤️ by{' '}
          <a
            href="https://github.com/Shani-Kr-Gupta"
            target="_blank"
            rel="noreferrer"
            className="text-ninja-orange hover:text-ninja-orange-light font-semibold font-cinzel transition-colors"
          >
            Shani Kr Gupta
          </a>
        </p>

        <div className="flex justify-center gap-4 mt-2">
          <a
            href="https://github.com/Shani-Kr-Gupta"
            target="_blank"
            rel="noreferrer"
            className={`flex items-center gap-1.5 text-xs hover:text-ninja-orange transition-colors ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.44 9.8 8.2 11.37.6.1.82-.26.82-.57v-2c-3.34.72-4.04-1.61-4.04-1.61-.55-1.38-1.34-1.75-1.34-1.75-1.09-.74.08-.73.08-.73 1.2.08 1.84 1.24 1.84 1.24 1.07 1.83 2.8 1.3 3.48.99.1-.78.42-1.3.76-1.6-2.67-.3-5.47-1.33-5.47-5.93 0-1.31.47-2.38 1.24-3.22-.12-.3-.54-1.52.12-3.18 0 0 1.01-.32 3.3 1.23a11.5 11.5 0 0 1 3-.4c1.02.01 2.04.14 3 .4 2.28-1.55 3.29-1.23 3.29-1.23.66 1.66.24 2.88.12 3.18.77.84 1.24 1.91 1.24 3.22 0 4.61-2.81 5.63-5.48 5.92.43.37.81 1.1.81 2.22v3.29c0 .32.22.68.82.57C20.57 21.8 24 17.3 24 12 24 5.37 18.63 0 12 0z"/>
            </svg>
            @Shani-Kr-Gupta
          </a>
        </div>

        <p className={`text-[10px] mt-4 ${isDark ? 'text-ninja-muted/50' : 'text-gray-400'}`}>
          NinjaScope © {new Date().getFullYear()} — Powered by GitHub API &amp; MERN Stack
        </p>
      </div>
    </motion.footer>
  );
}
