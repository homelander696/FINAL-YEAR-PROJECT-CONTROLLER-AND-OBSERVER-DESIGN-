import { useRef, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Text, OrbitControls } from '@react-three/drei';
import { useTheme } from '../context/ThemeContext';

const LANG_COLORS = {
  JavaScript: '#f1e05a', TypeScript: '#3178c6', Python: '#3572A5',
  Java: '#b07219', 'C++': '#f34b7d', C: '#6e5494', Go: '#00ADD8',
  Rust: '#dea584', Ruby: '#701516', PHP: '#4F5D95', Swift: '#fa7343',
  Kotlin: '#A97BFF', HTML: '#e34c26', CSS: '#563d7c', Shell: '#89e051',
};

function Bar({ position, height, color, label, pct }) {
  const meshRef = useRef();
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.4 + position[0]) * 0.05;
    }
  });

  const h = Math.max(height, 0.15);
  const hexToRgb = (hex) => {
    const r = parseInt(hex.slice(1, 3), 16) / 255;
    const g = parseInt(hex.slice(3, 5), 16) / 255;
    const b = parseInt(hex.slice(5, 7), 16) / 255;
    return [r, g, b];
  };
  const [r, g, b] = hexToRgb(color || '#ff6b00');

  return (
    <group position={position}>
      {/* Bar */}
      <mesh ref={meshRef} position={[0, h / 2, 0]} castShadow>
        <boxGeometry args={[0.55, h, 0.55]} />
        <meshStandardMaterial color={color} metalness={0.3} roughness={0.4} />
      </mesh>

      {/* Glowing top */}
      <mesh position={[0, h, 0]}>
        <sphereGeometry args={[0.18, 16, 16]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={1.5}
          transparent
          opacity={0.9}
        />
      </mesh>

      {/* Percentage label */}
      <Text
        position={[0, h + 0.45, 0]}
        fontSize={0.22}
        color="#ff6b00"
        anchorX="center"
        anchorY="bottom"
        font={undefined}
      >
        {pct}%
      </Text>

      {/* Lang label */}
      <Text
        position={[0, -0.25, 0]}
        fontSize={0.18}
        color="#ecf0f1"
        anchorX="center"
        anchorY="top"
        maxWidth={0.8}
        font={undefined}
      >
        {label}
      </Text>
    </group>
  );
}

function Scene({ langs }) {
  const total = langs.reduce((a, [, c]) => a + c, 0);
  const maxCount = Math.max(...langs.map(([, c]) => c), 1);
  const spacing = 1.1;
  const offset = ((langs.length - 1) * spacing) / 2;

  useFrame((state, delta) => {});

  return (
    <>
      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 10, 5]} intensity={1.2} castShadow />
      <pointLight position={[-4, 4, 4]} intensity={0.8} color="#ff6b00" />
      <pointLight position={[4, 4, -4]} intensity={0.5} color="#f39c12" />

      {/* Ground grid */}
      <gridHelper args={[12, 12, '#1a2d45', '#1a2d45']} position={[0, 0, 0]} />

      {langs.map(([lang, count], i) => {
        const pct = Math.round((count / total) * 100);
        const height = (count / maxCount) * 3.5;
        const color = LANG_COLORS[lang] || '#ff6b00';
        return (
          <Bar
            key={lang}
            position={[i * spacing - offset, 0, 0]}
            height={height}
            color={color}
            label={lang}
            pct={pct}
          />
        );
      })}

      <OrbitControls
        enablePan={false}
        minPolarAngle={Math.PI / 6}
        maxPolarAngle={Math.PI / 2.2}
        autoRotate
        autoRotateSpeed={0.6}
      />
    </>
  );
}

export default function ThreeLangChart({ repos }) {
  const { isDark } = useTheme();

  const langCount = {};
  repos?.forEach((r) => {
    if (r.language) langCount[r.language] = (langCount[r.language] || 0) + 1;
  });
  const langs = Object.entries(langCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 7);

  if (!langs.length) return null;

  return (
    <div className={`ninja-card p-5 max-w-2xl mx-auto`}>
      <h3 className={`text-xs font-cinzel text-ninja-orange uppercase tracking-widest mb-1`}>
        🌐 3D Jutsu Mastery Chart
      </h3>
      <p className={`text-[11px] mb-3 font-noto italic ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>
        Drag to rotate · Scroll to zoom
      </p>
      <div
        className="w-full rounded-xl overflow-hidden"
        style={{ height: '300px', background: isDark ? '#060f18' : '#0d1b2a' }}
      >
        <Canvas
          camera={{ position: [0, 3, 7], fov: 50 }}
          shadows
          gl={{ antialias: true }}
        >
          <Suspense fallback={null}>
            <Scene langs={langs} />
          </Suspense>
        </Canvas>
      </div>
    </div>
  );
}
