import { motion } from 'framer-motion';
import { FiStar, FiGitBranch, FiEye, FiExternalLink } from 'react-icons/fi';

const LANG_COLORS = {
  JavaScript: '#f1e05a', TypeScript: '#3178c6', Python: '#3572A5',
  Java: '#b07219', 'C++': '#f34b7d', C: '#555', Go: '#00ADD8',
  Rust: '#dea584', Ruby: '#701516', PHP: '#4F5D95', Swift: '#fa7343',
  Kotlin: '#A97BFF', HTML: '#e34c26', CSS: '#563d7c', Shell: '#89e051',
  Dart: '#00B4AB', Vue: '#41b883', React: '#61DAFB',
};

export default function RepoCard({ repo, index }) {
  const langColor = LANG_COLORS[repo.language] || '#8b949e';
  const updatedAt = new Date(repo.updated_at).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="ninja-card p-5 flex flex-col gap-3 group"
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <a
          href={repo.html_url}
          target="_blank"
          rel="noreferrer"
          className="font-semibold font-cinzel text-ninja-orange hover:text-ninja-orange-light transition-colors flex items-center gap-1 text-sm leading-tight"
        >
          {repo.name}
          <FiExternalLink className="opacity-0 group-hover:opacity-100 text-xs transition-opacity" />
        </a>
        {repo.fork && (
          <span className="text-[10px] px-2 py-0.5 rounded-full border border-ninja-muted/40 text-ninja-muted flex-shrink-0">
            forked
          </span>
        )}
      </div>

      {/* Description */}
      {repo.description && (
        <p className="text-ninja-muted text-xs leading-relaxed line-clamp-2">
          {repo.description}
        </p>
      )}

      {/* Topics */}
      {repo.topics?.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {repo.topics.slice(0, 4).map((t) => (
            <span
              key={t}
              className="text-[10px] px-2 py-0.5 rounded-full bg-ninja-orange/10 text-ninja-orange border border-ninja-orange/20"
            >
              {t}
            </span>
          ))}
        </div>
      )}

      {/* Footer stats */}
      <div className="flex items-center gap-4 mt-auto text-xs text-ninja-muted flex-wrap">
        {repo.language && (
          <span className="flex items-center gap-1.5">
            <span
              className="w-2.5 h-2.5 rounded-full inline-block"
              style={{ backgroundColor: langColor }}
            />
            {repo.language}
          </span>
        )}
        {repo.stargazers_count > 0 && (
          <span className="flex items-center gap-1 hover:text-ninja-gold transition-colors">
            <FiStar className="text-ninja-gold" /> {repo.stargazers_count.toLocaleString()}
          </span>
        )}
        {repo.forks_count > 0 && (
          <span className="flex items-center gap-1">
            <FiGitBranch className="text-ninja-teal" /> {repo.forks_count.toLocaleString()}
          </span>
        )}
        {repo.watchers_count > 0 && (
          <span className="flex items-center gap-1">
            <FiEye className="text-ninja-muted" /> {repo.watchers_count.toLocaleString()}
          </span>
        )}
        <span className="ml-auto text-[10px]">Updated {updatedAt}</span>
      </div>
    </motion.div>
  );
}
