import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis,
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, Cell
} from 'recharts';
import { FiSearch, FiX, FiAward } from 'react-icons/fi';
import { fetchUser, fetchRepos } from '../api/github';
import { compareProfiles } from '../api/ai';
import { useTheme } from '../context/ThemeContext';
import toast from 'react-hot-toast';

const COLORS = { p1: '#ff6b00', p2: '#3b82f6' };

function normalize(val, max) {
  return max > 0 ? Math.round((val / max) * 100) : 0;
}

function buildRadarData(p1, repos1, p2, repos2) {
  const stars1 = repos1.reduce((a, r) => a + (r.stargazers_count || 0), 0);
  const stars2 = repos2.reduce((a, r) => a + (r.stargazers_count || 0), 0);
  const maxStars = Math.max(stars1, stars2, 1);
  const maxRepos = Math.max(p1.public_repos, p2.public_repos, 1);
  const maxFollowers = Math.max(p1.followers, p2.followers, 1);
  const forks1 = repos1.reduce((a, r) => a + (r.forks_count || 0), 0);
  const forks2 = repos2.reduce((a, r) => a + (r.forks_count || 0), 0);
  const maxForks = Math.max(forks1, forks2, 1);
  const langs1 = new Set(repos1.map((r) => r.language).filter(Boolean)).size;
  const langs2 = new Set(repos2.map((r) => r.language).filter(Boolean)).size;
  const maxLangs = Math.max(langs1, langs2, 1);

  return [
    { stat: 'Stars', [p1.login]: normalize(stars1, maxStars), [p2.login]: normalize(stars2, maxStars) },
    { stat: 'Repos', [p1.login]: normalize(p1.public_repos, maxRepos), [p2.login]: normalize(p2.public_repos, maxRepos) },
    { stat: 'Followers', [p1.login]: normalize(p1.followers, maxFollowers), [p2.login]: normalize(p2.followers, maxFollowers) },
    { stat: 'Forks', [p1.login]: normalize(forks1, maxForks), [p2.login]: normalize(forks2, maxForks) },
    { stat: 'Languages', [p1.login]: normalize(langs1, maxLangs), [p2.login]: normalize(langs2, maxLangs) },
  ];
}

function buildBarData(p1, repos1, p2, repos2) {
  const stars1 = repos1.reduce((a, r) => a + (r.stargazers_count || 0), 0);
  const stars2 = repos2.reduce((a, r) => a + (r.stargazers_count || 0), 0);
  return [
    { name: 'Repos', [p1.login]: p1.public_repos, [p2.login]: p2.public_repos },
    { name: 'Followers', [p1.login]: p1.followers, [p2.login]: p2.followers },
    { name: 'Following', [p1.login]: p1.following, [p2.login]: p2.following },
    { name: 'Total Stars', [p1.login]: stars1, [p2.login]: stars2 },
  ];
}

export default function CompareSection() {
  const { isDark } = useTheme();
  const [open, setOpen] = useState(false);
  const [u1, setU1] = useState('');
  const [u2, setU2] = useState('');
  const [data, setData] = useState(null);
  const [aiResult, setAiResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);

  const textMuted = isDark ? 'text-ninja-muted' : 'text-gray-500';
  const textMain = isDark ? 'text-white' : 'text-ninja-dark';
  const cardBg = isDark ? 'bg-ninja-card border-ninja-navy' : 'bg-white border-orange-100 shadow-sm';

  const runCompare = async () => {
    if (!u1.trim() || !u2.trim()) return toast.error('Enter two usernames!');
    setLoading(true);
    setData(null);
    setAiResult(null);
    try {
      const [r1u, r1r, r2u, r2r] = await Promise.all([
        fetchUser(u1.trim()), fetchRepos(u1.trim()),
        fetchUser(u2.trim()), fetchRepos(u2.trim()),
      ]);
      setData({ p1: r1u.data, repos1: r1r.data, p2: r2u.data, repos2: r2r.data });
      toast.success('Ninja duel loaded!', { icon: '⚔️' });
    } catch (err) {
      toast.error(err.response?.data?.error || 'Could not load one of the profiles.');
    } finally {
      setLoading(false);
    }
  };

  const runAiCompare = async () => {
    if (!data) return;
    setAiLoading(true);
    try {
      const { data: res } = await compareProfiles(data.p1, data.repos1, data.p2, data.repos2);
      setAiResult(res);
    } catch {
      toast.error('AI compare failed.');
    } finally {
      setAiLoading(false);
    }
  };

  const radarData = data ? buildRadarData(data.p1, data.repos1, data.p2, data.repos2) : [];
  const barData = data ? buildBarData(data.p1, data.repos1, data.p2, data.repos2) : [];
  const axisColor = isDark ? '#7f8c8d' : '#9ca3af';
  const gridColor = isDark ? '#1a2d45' : '#f3f4f6';

  return (
    <>
      <motion.button
        onClick={() => setOpen(true)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-cinzel font-bold text-sm
                   border-2 border-blue-500/60 text-blue-400
                   hover:bg-blue-500/10 transition-all duration-200"
      >
        ⚔️ Compare Ninjas
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-3"
            style={{ background: 'rgba(6,15,24,0.92)', backdropFilter: 'blur(8px)' }}
            onClick={() => setOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              onClick={(e) => e.stopPropagation()}
              className={`relative w-full max-w-3xl max-h-[92vh] overflow-y-auto rounded-2xl border shadow-ninja-lg
                          ${isDark ? 'bg-ninja-darker border-ninja-orange/30' : 'bg-white border-orange-200'}`}
            >
              {/* Header */}
              <div className={`sticky top-0 z-10 px-6 py-4 border-b flex items-center justify-between backdrop-blur-sm
                              ${isDark ? 'bg-ninja-darker/95 border-ninja-navy' : 'bg-white/95 border-orange-100'}`}>
                <h2 className="font-cinzel text-xl font-bold text-ninja-orange">⚔️ Ninja Duel</h2>
                <button onClick={() => setOpen(false)} className={isDark ? 'text-ninja-muted hover:text-white' : 'text-gray-400 hover:text-gray-900'}>
                  <FiX className="text-xl" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                {/* Search inputs */}
                <div className="grid grid-cols-2 gap-3">
                  {[{ val: u1, set: setU1, label: 'Shinobi 1' }, { val: u2, set: setU2, label: 'Shinobi 2' }].map(({ val, set, label }) => (
                    <div key={label} className="relative">
                      <FiSearch className={`absolute left-3 top-1/2 -translate-y-1/2 ${textMuted}`} />
                      <input
                        className="ninja-input pl-9 text-sm"
                        placeholder={label + ' username'}
                        value={val}
                        onChange={(e) => set(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && runCompare()}
                      />
                    </div>
                  ))}
                </div>
                <motion.button
                  onClick={runCompare}
                  disabled={loading}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="ninja-btn w-full text-sm disabled:opacity-50"
                >
                  {loading ? '⚡ Loading battle data...' : '⚔️ Start Ninja Duel!'}
                </motion.button>

                {/* Results */}
                {data && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">

                    {/* Profile avatars side by side */}
                    <div className="grid grid-cols-2 gap-4">
                      {[{ p: data.p1, color: COLORS.p1 }, { p: data.p2, color: COLORS.p2 }].map(({ p, color }) => (
                        <div key={p.login} className={`rounded-xl p-4 border text-center ${cardBg}`}>
                          <img src={p.avatar_url} alt={p.login} className="w-16 h-16 rounded-full mx-auto mb-2 border-2" style={{ borderColor: color }} />
                          <p className={`font-cinzel font-bold text-sm ${textMain}`}>{p.name || p.login}</p>
                          <p className={`text-xs font-mono ${textMuted}`}>@{p.login}</p>
                          <div className="flex justify-center gap-3 mt-2 text-xs">
                            <span className={textMuted}>⭐ {data[p.login === data.p1.login ? 'repos1' : 'repos2'].reduce((a, r) => a + r.stargazers_count, 0)}</span>
                            <span className={textMuted}>👥 {p.followers}</span>
                            <span className={textMuted}>📜 {p.public_repos}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Radar chart */}
                    <div className={`rounded-xl p-4 border ${cardBg}`}>
                      <p className="text-xs font-cinzel text-ninja-orange uppercase tracking-widest mb-3">🕸️ Chakra Radar</p>
                      <ResponsiveContainer width="100%" height={260}>
                        <RadarChart data={radarData}>
                          <PolarGrid stroke={gridColor} />
                          <PolarAngleAxis dataKey="stat" tick={{ fill: axisColor, fontSize: 11 }} />
                          <Radar name={data.p1.login} dataKey={data.p1.login} stroke={COLORS.p1} fill={COLORS.p1} fillOpacity={0.25} />
                          <Radar name={data.p2.login} dataKey={data.p2.login} stroke={COLORS.p2} fill={COLORS.p2} fillOpacity={0.25} />
                          <Legend wrapperStyle={{ fontSize: '12px' }} />
                          <Tooltip contentStyle={{ background: '#0d1b2a', border: '1px solid #ff6b00', borderRadius: '8px', fontSize: '12px' }} />
                        </RadarChart>
                      </ResponsiveContainer>
                    </div>

                    {/* Bar chart */}
                    <div className={`rounded-xl p-4 border ${cardBg}`}>
                      <p className="text-xs font-cinzel text-ninja-orange uppercase tracking-widest mb-3">📊 Stats Battle</p>
                      <ResponsiveContainer width="100%" height={220}>
                        <BarChart data={barData} layout="vertical">
                          <XAxis type="number" tick={{ fill: axisColor, fontSize: 10 }} />
                          <YAxis type="category" dataKey="name" tick={{ fill: axisColor, fontSize: 11 }} width={80} />
                          <Tooltip contentStyle={{ background: '#0d1b2a', border: '1px solid #ff6b00', borderRadius: '8px', fontSize: '12px' }} />
                          <Legend wrapperStyle={{ fontSize: '12px' }} />
                          <Bar dataKey={data.p1.login} fill={COLORS.p1} radius={[0, 4, 4, 0]} />
                          <Bar dataKey={data.p2.login} fill={COLORS.p2} radius={[0, 4, 4, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    {/* AI Battle verdict */}
                    <motion.button
                      onClick={runAiCompare}
                      disabled={aiLoading}
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl font-cinzel font-bold text-sm
                                 border-2 border-ninja-orange/60 text-ninja-orange hover:bg-ninja-orange/10 transition-all disabled:opacity-50"
                    >
                      {aiLoading ? <><span className="animate-spin">🌀</span> AI analyzing battle...</> : '🤖 AI Battle Verdict'}
                    </motion.button>

                    {aiResult && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="rounded-xl border border-ninja-orange/40 bg-ninja-orange/5 p-5 space-y-4"
                      >
                        <div className="flex items-center gap-2">
                          <FiAward className="text-ninja-gold text-xl" />
                          <p className="font-cinzel font-bold text-ninja-orange">Winner: @{aiResult.winner}</p>
                        </div>
                        <p className={`text-sm font-noto italic ${textMuted}`}>{aiResult.battle_summary}</p>
                        <div className="grid grid-cols-2 gap-3">
                          {[{ login: data.p1.login, rank: aiResult.shinobi1_rank, jutsu: aiResult.shinobi1_jutsu },
                            { login: data.p2.login, rank: aiResult.shinobi2_rank, jutsu: aiResult.shinobi2_jutsu }].map((s) => (
                            <div key={s.login} className={`p-3 rounded-lg border text-xs ${cardBg}`}>
                              <p className={`font-cinzel font-bold mb-0.5 ${textMain}`}>@{s.login}</p>
                              <p className="text-ninja-orange">{s.rank}</p>
                              <p className={textMuted}>{s.jutsu}</p>
                            </div>
                          ))}
                        </div>
                        <div className="text-center border-t border-ninja-orange/20 pt-3">
                          <p className={`text-xs font-noto italic ${textMuted}`}>
                            <span className="text-ninja-orange">"</span>{aiResult.verdict}<span className="text-ninja-orange">"</span>
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </motion.div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
