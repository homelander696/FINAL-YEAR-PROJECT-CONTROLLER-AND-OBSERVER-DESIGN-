import { motion, AnimatePresence } from 'framer-motion';
import { FiX } from 'react-icons/fi';

export default function FavoritesList({ favorites, onSelect, onRemove }) {
  if (!favorites?.length) return null;

  return (
    <div className="w-full max-w-2xl mx-auto">
      <h3 className="text-xs font-cinzel text-ninja-orange uppercase tracking-widest mb-3 text-center">
        🌀 Your Ninja Squad
      </h3>
      <div className="flex flex-wrap gap-2 justify-center">
        <AnimatePresence>
          {favorites.map((fav) => (
            <motion.div
              key={fav.username}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-ninja-navy border border-ninja-orange/30 hover:border-ninja-orange/60 transition-colors cursor-pointer group"
              onClick={() => onSelect(fav.username)}
            >
              <img
                src={fav.avatar_url}
                alt={fav.username}
                className="w-5 h-5 rounded-full"
              />
              <span className="text-xs text-ninja-light group-hover:text-ninja-orange transition-colors">
                {fav.username}
              </span>
              <button
                onClick={(e) => { e.stopPropagation(); onRemove(fav.username); }}
                className="text-ninja-muted hover:text-red-400 transition-colors ml-0.5"
              >
                <FiX className="text-xs" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
