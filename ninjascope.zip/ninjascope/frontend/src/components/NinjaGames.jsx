import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiX } from 'react-icons/fi';
import { useTheme } from '../context/ThemeContext';

// ─── Game 1: Repo Roulette ────────────────────────────────────────────────────
const LANGUAGES = ['JavaScript', 'TypeScript', 'Python', 'Java', 'Go', 'Rust', 'C++', 'Ruby', 'PHP', 'Swift'];
const LANG_COLORS = {
  JavaScript: '#f1e05a', TypeScript: '#3178c6', Python: '#3572A5',
  Java: '#b07219', Go: '#00ADD8', Rust: '#dea584', 'C++': '#f34b7d',
  Ruby: '#701516', PHP: '#4F5D95', Swift: '#fa7343',
};

function RepoRoulette({ repos, onClose }) {
  const { isDark } = useTheme();
  const validRepos = repos?.filter((r) => r.language && r.description) || [];
  const [idx, setIdx] = useState(0);
  const [guess, setGuess] = useState(null);
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(0);
  const [done, setDone] = useState(false);
  const ROUNDS = Math.min(8, validRepos.length);

  const repo = validRepos[idx] || null;
  const choices = repo
    ? (() => {
        const correct = repo.language;
        const others = LANGUAGES.filter((l) => l !== correct).sort(() => Math.random() - 0.5).slice(0, 3);
        return [...others, correct].sort(() => Math.random() - 0.5);
      })()
    : [];

  const handleGuess = (lang) => {
    if (guess) return;
    setGuess(lang);
    if (lang === repo.language) setScore((s) => s + 1);
    setTimeout(() => {
      if (round + 1 >= ROUNDS) { setDone(true); return; }
      setIdx((i) => (i + 1) % validRepos.length);
      setRound((r) => r + 1);
      setGuess(null);
    }, 1200);
  };

  const cardBg = isDark ? 'bg-ninja-card border-ninja-navy' : 'bg-white border-orange-100 shadow-sm';
  const textMain = isDark ? 'text-white' : 'text-ninja-dark';
  const textMuted = isDark ? 'text-ninja-muted' : 'text-gray-500';

  if (!validRepos.length) return (
    <div className="p-8 text-center">
      <p className={`${textMuted} font-noto`}>Need repos with languages & descriptions to play!</p>
    </div>
  );

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <p className={`font-cinzel text-sm ${textMuted}`}>Round {round + 1}/{ROUNDS}</p>
        <p className="font-cinzel font-bold text-ninja-orange">Score: {score}</p>
      </div>

      {done ? (
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center py-6 space-y-3">
          <div className="text-5xl">{score >= ROUNDS * 0.7 ? '🎉' : '💨'}</div>
          <p className={`font-cinzel text-xl font-bold ${textMain}`}>{score}/{ROUNDS}</p>
          <p className={`font-noto italic text-sm ${textMuted}`}>
            {score === ROUNDS ? "Perfect! You're a Code Kage!" : score >= ROUNDS * 0.7 ? "Jonin-level knowledge!" : "Keep training, Genin!"}
          </p>
          <button onClick={() => { setIdx(0); setRound(0); setScore(0); setGuess(null); setDone(false); }} className="ninja-btn text-xs">
            Play Again
          </button>
        </motion.div>
      ) : repo ? (
        <>
          <div className={`rounded-xl p-5 border ${cardBg}`}>
            <p className={`text-xs uppercase tracking-widest font-cinzel text-ninja-orange mb-2`}>📜 {repo.name}</p>
            <p className={`text-sm font-noto leading-relaxed ${textMuted}`}>{repo.description}</p>
            {repo.stargazers_count > 0 && (
              <p className={`text-xs mt-2 ${textMuted}`}>⭐ {repo.stargazers_count} stars</p>
            )}
          </div>
          <p className={`text-xs font-cinzel uppercase tracking-widest text-center ${textMuted}`}>What language is this written in?</p>
          <div className="grid grid-cols-2 gap-2">
            {choices.map((lang) => {
              let cls = `p-3 rounded-xl border font-cinzel text-sm font-bold transition-all cursor-pointer text-center `;
              if (!guess) cls += isDark ? 'border-ninja-navy hover:border-ninja-orange hover:text-ninja-orange text-ninja-muted' : 'border-orange-200 hover:border-ninja-orange hover:text-ninja-orange text-gray-600';
              else if (lang === repo.language) cls += 'border-green-400 text-green-400 bg-green-400/10';
              else if (lang === guess) cls += 'border-red-400 text-red-400 bg-red-400/10';
              else cls += isDark ? 'border-ninja-navy text-ninja-muted opacity-40' : 'border-orange-100 text-gray-400 opacity-40';
              return (
                <button key={lang} onClick={() => handleGuess(lang)} className={cls} style={lang === repo.language && guess ? { borderColor: LANG_COLORS[lang] } : {}}>
                  <span className="mr-1" style={{ color: LANG_COLORS[lang] }}>●</span>
                  {lang}
                </button>
              );
            })}
          </div>
        </>
      ) : null}
    </div>
  );
}

// ─── Game 2: Chakra Typing ────────────────────────────────────────────────────
const TYPING_QUOTES = [
  "I'm not gonna run away, I never go back on my word!",
  "Those who break the rules are scum, but those who abandon their friends are worse than scum.",
  "A dropout will beat a genius through hard work.",
  "In this world, wherever there is light, there are also shadows.",
  "Hard work is worthless for those that don't believe in themselves.",
  "Failing doesn't give you a reason to give up, as long as you believe.",
];

function ChakraTyping({ onClose }) {
  const { isDark } = useTheme();
  const [quoteIdx, setQuoteIdx] = useState(Math.floor(Math.random() * TYPING_QUOTES.length));
  const [input, setInput] = useState('');
  const [started, setStarted] = useState(false);
  const [finished, setFinished] = useState(false);
  const [startTime, setStartTime] = useState(null);
  const [wpm, setWpm] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef(null);
  const target = TYPING_QUOTES[quoteIdx];

  const reset = useCallback(() => {
    clearInterval(timerRef.current);
    setInput('');
    setStarted(false);
    setFinished(false);
    setStartTime(null);
    setWpm(0);
    setElapsed(0);
    setQuoteIdx(Math.floor(Math.random() * TYPING_QUOTES.length));
  }, []);

  const handleInput = (e) => {
    const val = e.target.value;
    if (!started) {
      setStarted(true);
      const t = Date.now();
      setStartTime(t);
      timerRef.current = setInterval(() => setElapsed(((Date.now() - t) / 1000).toFixed(1)), 100);
    }
    setInput(val);
    if (val === target) {
      clearInterval(timerRef.current);
      setFinished(true);
      const mins = (Date.now() - startTime) / 60000;
      setWpm(Math.round(target.split(' ').length / mins));
    }
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  const accuracy = input.length > 0
    ? Math.round((input.split('').filter((c, i) => c === target[i]).length / input.length) * 100)
    : 100;

  const textMuted = isDark ? 'text-ninja-muted' : 'text-gray-500';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between text-xs font-cinzel">
        <span className={textMuted}>{started && !finished ? `⏱ ${elapsed}s` : '⏱ Ready'}</span>
        <span className="text-ninja-orange">🎯 Accuracy: {accuracy}%</span>
      </div>

      {/* Target text with colored overlay */}
      <div className={`rounded-xl p-4 border font-mono text-sm leading-relaxed select-none
                       ${isDark ? 'bg-ninja-navy/40 border-ninja-navy' : 'bg-orange-50 border-orange-100'}`}>
        {target.split('').map((char, i) => {
          let color = isDark ? '#7f8c8d' : '#9ca3af';
          if (i < input.length) color = input[i] === char ? '#22c55e' : '#ef4444';
          return <span key={i} style={{ color }}>{char}</span>;
        })}
      </div>

      {finished ? (
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center space-y-3 py-4">
          <div className="text-4xl">🏆</div>
          <p className="font-cinzel text-2xl font-black text-ninja-orange">{wpm} WPM</p>
          <p className={`text-xs font-noto italic ${textMuted}`}>
            {wpm >= 80 ? "Shadow Clone speed! You're a Kage!" : wpm >= 50 ? "Jonin-level typing, Dattebayo!" : "Keep training your fingers, Genin!"}
          </p>
          <button onClick={reset} className="ninja-btn text-xs">Try Another Quote</button>
        </motion.div>
      ) : (
        <textarea
          className="ninja-input w-full h-24 resize-none font-mono text-sm"
          placeholder="Start typing to begin the Chakra challenge..."
          value={input}
          onChange={handleInput}
          spellCheck={false}
          autoComplete="off"
        />
      )}
    </div>
  );
}

// ─── Game 3: Stat Showdown ────────────────────────────────────────────────────
const FAMOUS_NINJAS = [
  { login: 'torvalds', name: 'Linus Torvalds', repos: 8, followers: 220000, stars: 50000 },
  { login: 'gaearon', name: 'Dan Abramov', repos: 263, followers: 85000, stars: 32000 },
  { login: 'sindresorhus', name: 'Sindre Sorhus', repos: 1100, followers: 80000, stars: 120000 },
  { login: 'tj', name: 'TJ Holowaychuk', repos: 300, followers: 30000, stars: 55000 },
  { login: 'defunkt', name: 'Chris Wanstrath', repos: 107, followers: 19000, stars: 4000 },
  { login: 'antirez', name: 'Salvatore Sanfilippo', repos: 30, followers: 22000, stars: 75000 },
  { login: 'mrdoob', name: 'Ricardo Cabello', repos: 100, followers: 29000, stars: 98000 },
  { login: 'addyosmani', name: 'Addy Osmani', repos: 250, followers: 47000, stars: 28000 },
];

const CATEGORIES = [
  { key: 'repos', label: 'More Repos', emoji: '📜' },
  { key: 'followers', label: 'More Followers', emoji: '👥' },
  { key: 'stars', label: 'More Stars', emoji: '⭐' },
];

function StatShowdown({ onClose }) {
  const { isDark } = useTheme();
  const [score, setScore] = useState(0);
  const [round, setRound] = useState(0);
  const [picked, setPicked] = useState(null);
  const [feedback, setFeedback] = useState(null);
  const [done, setDone] = useState(false);
  const ROUNDS = 6;

  const getPair = () => {
    const shuffled = [...FAMOUS_NINJAS].sort(() => Math.random() - 0.5);
    return [shuffled[0], shuffled[1]];
  };
  const [pair, setPair] = useState(() => getPair());
  const [cat] = useState(() => CATEGORIES[Math.floor(Math.random() * CATEGORIES.length)]);

  const handlePick = (idx) => {
    if (picked !== null) return;
    setPicked(idx);
    const winner = pair[0][cat.key] > pair[1][cat.key] ? 0 : 1;
    const correct = idx === winner;
    if (correct) setScore((s) => s + 1);
    setFeedback({ correct, winner });
    setTimeout(() => {
      if (round + 1 >= ROUNDS) { setDone(true); return; }
      setRound((r) => r + 1);
      setPair(getPair());
      setPicked(null);
      setFeedback(null);
    }, 1400);
  };

  const textMain = isDark ? 'text-white' : 'text-ninja-dark';
  const textMuted = isDark ? 'text-ninja-muted' : 'text-gray-500';
  const cardBg = isDark ? 'bg-ninja-card border-ninja-navy' : 'bg-white border-orange-100 shadow-sm';

  if (done) return (
    <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="text-center py-8 space-y-3">
      <div className="text-5xl">{score >= 5 ? '🥷' : '💨'}</div>
      <p className={`font-cinzel text-2xl font-black text-ninja-orange`}>{score}/{ROUNDS}</p>
      <p className={`font-noto italic text-sm ${textMuted}`}>
        {score === ROUNDS ? "You're a GitHub Kage! All correct!" : score >= 4 ? "Jonin-level knowledge!" : "Train harder, young Genin!"}
      </p>
      <button onClick={() => { setScore(0); setRound(0); setPicked(null); setFeedback(null); setPair(getPair()); setDone(false); }} className="ninja-btn text-xs">
        Play Again
      </button>
    </motion.div>
  );

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between text-xs font-cinzel">
        <span className={textMuted}>Round {round + 1}/{ROUNDS}</span>
        <span className="text-ninja-orange">Score: {score}</span>
      </div>

      <div className={`text-center p-3 rounded-xl border ${isDark ? 'bg-ninja-navy/40 border-ninja-navy' : 'bg-orange-50 border-orange-100'}`}>
        <p className={`font-cinzel text-sm font-bold ${textMain}`}>
          {cat.emoji} Who has {cat.label}?
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {pair.map((ninja, i) => {
          let borderClass = isDark ? 'border-ninja-navy hover:border-ninja-orange' : 'border-orange-200 hover:border-ninja-orange';
          if (picked !== null) {
            if (i === feedback?.winner) borderClass = 'border-green-400 bg-green-400/10';
            else if (i === picked && !feedback?.correct) borderClass = 'border-red-400 bg-red-400/10';
          }
          return (
            <button key={ninja.login} onClick={() => handlePick(i)}
              className={`rounded-xl p-4 border text-center transition-all cursor-pointer ${cardBg} ${borderClass}`}>
              <p className={`font-cinzel font-bold text-sm mb-1 ${textMain}`}>{ninja.name}</p>
              <p className={`text-xs font-mono ${textMuted}`}>@{ninja.login}</p>
              {picked !== null && (
                <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-ninja-orange text-xs font-bold mt-2">
                  {cat.emoji} {ninja[cat.key].toLocaleString()}
                </motion.p>
              )}
            </button>
          );
        })}
      </div>
      {picked !== null && (
        <motion.p initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
          className={`text-center text-sm font-cinzel font-bold ${feedback?.correct ? 'text-green-400' : 'text-red-400'}`}>
          {feedback?.correct ? '✓ Correct! Dattebayo!' : '✗ Wrong! Train harder!'}
        </motion.p>
      )}
    </div>
  );
}

// ─── Main NinjaGames Component ────────────────────────────────────────────────
const GAMES = [
  { id: 'roulette', label: 'Repo Roulette', emoji: '🎰', desc: 'Guess the language from the description' },
  { id: 'typing', label: 'Chakra Typing', emoji: '⌨️', desc: 'Type Naruto quotes at ninja speed' },
  { id: 'showdown', label: 'Stat Showdown', emoji: '⚔️', desc: 'Guess which famous dev has more' },
];

export default function NinjaGames({ repos }) {
  const { isDark } = useTheme();
  const [open, setOpen] = useState(false);
  const [activeGame, setActiveGame] = useState(null);

  const textMuted = isDark ? 'text-ninja-muted' : 'text-gray-500';
  const textMain = isDark ? 'text-white' : 'text-ninja-dark';
  const cardBg = isDark ? 'bg-ninja-card border-ninja-navy' : 'bg-white border-orange-100 shadow-sm';

  return (
    <>
      <motion.button
        onClick={() => setOpen(true)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-cinzel font-bold text-sm
                   border-2 border-green-500/60 text-green-400
                   hover:bg-green-500/10 transition-all duration-200"
      >
        🎮 Ninja Games
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4"
            style={{ background: 'rgba(6,15,24,0.92)', backdropFilter: 'blur(8px)' }}
            onClick={() => { if (!activeGame) setOpen(false); }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.88, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.88 }}
              onClick={(e) => e.stopPropagation()}
              className={`relative w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl border shadow-ninja-lg
                          ${isDark ? 'bg-ninja-darker border-ninja-orange/30' : 'bg-white border-orange-200'}`}
            >
              {/* Header */}
              <div className={`sticky top-0 z-10 px-6 py-4 border-b flex items-center justify-between backdrop-blur-sm
                              ${isDark ? 'bg-ninja-darker/95 border-ninja-navy' : 'bg-white/95 border-orange-100'}`}>
                <div className="flex items-center gap-3">
                  {activeGame && (
                    <button onClick={() => setActiveGame(null)} className={`text-xs font-cinzel ${textMuted} hover:text-ninja-orange`}>
                      ← Back
                    </button>
                  )}
                  <h2 className="font-cinzel text-xl font-bold text-ninja-orange">
                    {activeGame ? GAMES.find(g => g.id === activeGame)?.emoji + ' ' + GAMES.find(g => g.id === activeGame)?.label : '🎮 Ninja Games'}
                  </h2>
                </div>
                <button onClick={() => { setOpen(false); setActiveGame(null); }} className={isDark ? 'text-ninja-muted hover:text-white' : 'text-gray-400 hover:text-gray-900'}>
                  <FiX className="text-xl" />
                </button>
              </div>

              <div className="p-6">
                <AnimatePresence mode="wait">
                  {!activeGame ? (
                    <motion.div key="menu" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-3">
                      <p className={`text-xs font-noto italic text-center ${textMuted} mb-4`}>
                        "Even the greatest ninja started with a single game. Dattebayo!"
                      </p>
                      {GAMES.map((g) => (
                        <motion.button
                          key={g.id}
                          onClick={() => setActiveGame(g.id)}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          className={`w-full text-left p-4 rounded-xl border transition-all ${cardBg} hover:border-ninja-orange/60`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{g.emoji}</span>
                            <div>
                              <p className={`font-cinzel font-bold text-sm ${textMain}`}>{g.label}</p>
                              <p className={`text-xs ${textMuted}`}>{g.desc}</p>
                            </div>
                          </div>
                        </motion.button>
                      ))}
                    </motion.div>
                  ) : (
                    <motion.div key={activeGame} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
                      {activeGame === 'roulette' && <RepoRoulette repos={repos} onClose={() => setActiveGame(null)} />}
                      {activeGame === 'typing' && <ChakraTyping onClose={() => setActiveGame(null)} />}
                      {activeGame === 'showdown' && <StatShowdown onClose={() => setActiveGame(null)} />}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
