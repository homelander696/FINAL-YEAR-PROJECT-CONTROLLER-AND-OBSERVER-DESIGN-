import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiX } from 'react-icons/fi';

const STACK = [
  {
    icon: '⚛️',
    name: 'React',
    category: 'Frontend',
    color: '#61DAFB',
    quote: 'Fast as the Flying Thunder God Jutsu — react before the enemy blinks!',
  },
  {
    icon: '⚡',
    name: 'Vite',
    category: 'Build Tool',
    color: '#646CFF',
    quote: 'Swift as Minato — zero to dev server in milliseconds, Dattebayo!',
  },
  {
    icon: '🎨',
    name: 'Tailwind CSS',
    category: 'Styling',
    color: '#38BDF8',
    quote: 'Utility-first like a shinobi toolkit — every class a kunai ready to throw!',
  },
  {
    icon: '🌀',
    name: 'Framer Motion',
    category: 'Animations',
    color: '#FF4ECD',
    quote: 'Smoother than Itachi\'s genjutsu — animations that deceive the eye!',
  },
  {
    icon: '🟢',
    name: 'Node.js',
    category: 'Backend',
    color: '#68A063',
    quote: 'Non-blocking like a Leaf shinobi in shadow clone — handles thousands at once!',
  },
  {
    icon: '🚂',
    name: 'Express.js',
    category: 'Framework',
    color: '#ffffff',
    quote: 'Lightweight as a substitution jutsu — routes requests before you blink!',
  },
  {
    icon: '🍃',
    name: 'MongoDB',
    category: 'Database',
    color: '#47A248',
    quote: 'Flexible as Water Style — stores any shinobi\'s data without rigid schemas!',
  },
  {
    icon: '🐍',
    name: 'Python + NumPy',
    category: 'Music Generator',
    color: '#3572A5',
    quote: 'Summoned like Gamabunta — composed the ninja melody from pure sine waves!',
  },
  {
    icon: '🐙',
    name: 'GitHub REST API',
    category: 'Data Source',
    color: '#f39c12',
    quote: 'Our Akashic Records — every shinobi\'s code scrolls live here!',
  },
];

export default function TechStackModal() {
  const [open, setOpen] = useState(false);

  return (
    <>
      {/* Floating Surprise Jutsu button */}
      <motion.button
        onClick={() => setOpen(true)}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl font-cinzel font-bold text-sm
                   bg-orange-gradient text-white shadow-ninja-lg flex items-center gap-2"
        title="Surprise Jutsu!"
      >
        <motion.span
          animate={{ rotate: [0, 15, -15, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          🌀
        </motion.span>
        Surprise Jutsu!
      </motion.button>

      {/* Modal */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4"
            style={{ background: 'rgba(6,15,24,0.85)', backdropFilter: 'blur(6px)' }}
            onClick={() => setOpen(false)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.8, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.8, y: 40 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-3xl max-h-[85vh] overflow-y-auto rounded-2xl border border-ninja-orange/30 bg-ninja-darker shadow-ninja-lg"
            >
              {/* Header */}
              <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b border-ninja-navy bg-ninja-darker/95 backdrop-blur-sm">
                <div>
                  <h2 className="font-cinzel text-xl font-bold text-ninja-orange">
                    🌀 Surprise Jutsu!
                  </h2>
                  <p className="text-xs text-ninja-muted mt-0.5 font-noto italic">
                    "The tech behind NinjaScope — revealed!"
                  </p>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  className="text-ninja-muted hover:text-white transition-colors p-1"
                >
                  <FiX className="text-xl" />
                </button>
              </div>

              {/* Tech cards */}
              <div className="p-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {STACK.map((tech, i) => (
                  <motion.div
                    key={tech.name}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.07 }}
                    className="ninja-card p-4 flex flex-col gap-2 group hover:scale-[1.02] transition-transform"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{tech.icon}</span>
                      <div>
                        <p className="font-cinzel font-bold text-sm" style={{ color: tech.color }}>
                          {tech.name}
                        </p>
                        <p className="text-[10px] text-ninja-muted uppercase tracking-widest">
                          {tech.category}
                        </p>
                      </div>
                    </div>
                    <p className="text-xs text-ninja-muted leading-relaxed italic font-noto">
                      "{tech.quote}"
                    </p>
                  </motion.div>
                ))}
              </div>

              {/* Footer */}
              <div className="px-6 pb-5 text-center">
                <p className="text-xs text-ninja-muted font-noto italic">
                  Built with ❤️ and chakra by{' '}
                  <a
                    href="https://github.com/Shani-Kr-Gupta"
                    target="_blank"
                    rel="noreferrer"
                    className="text-ninja-orange hover:underline"
                  >
                    Shani Kr Gupta
                  </a>
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
