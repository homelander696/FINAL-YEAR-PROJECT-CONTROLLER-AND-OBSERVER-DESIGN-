import { motion } from 'framer-motion';
import { useTheme } from '../context/ThemeContext';

export default function ThemeToggle() {
  const { isDark, toggleTheme } = useTheme();

  return (
    <motion.button
      onClick={toggleTheme}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      title={isDark ? 'Switch to Konoha Day mode' : 'Switch to Night Village mode'}
      className="relative w-14 h-7 rounded-full border border-ninja-orange/40 bg-ninja-navy overflow-hidden cursor-pointer flex items-center px-1 transition-colors duration-300"
      style={{ background: isDark ? '#1a2d45' : '#ffe8cc' }}
    >
      <motion.div
        animate={{ x: isDark ? 0 : 26 }}
        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
        className="w-5 h-5 rounded-full flex items-center justify-center text-sm shadow-lg"
        style={{ background: isDark ? '#0d1b2a' : '#ff6b00' }}
      >
        {isDark ? '🌙' : '☀️'}
      </motion.div>
    </motion.button>
  );
}
