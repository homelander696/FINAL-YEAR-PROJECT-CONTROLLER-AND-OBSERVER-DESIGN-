import { motion } from 'framer-motion';
import ThemeToggle from './ThemeToggle';
import { useTheme } from '../context/ThemeContext';

export default function Navbar() {
  const { isDark } = useTheme();

  return (
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full sticky top-0 z-40 border-b border-ninja-navy/60 bg-ninja-darker/80 backdrop-blur-md"
    >
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <motion.span
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
            className="text-2xl select-none"
          >
            🍥
          </motion.span>
          <div>
            <span className="font-cinzel font-bold text-lg text-ninja-orange tracking-wider">
              NinjaScope
            </span>
            <p className={`text-[10px] font-noto hidden sm:block ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>
              The Shinobi's GitHub
            </p>
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-4">
          <span className={`hidden md:block text-xs font-noto italic ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>
            "Believe it!"
          </span>
          <ThemeToggle />
          <a
            href="https://github.com/Shani-Kr-Gupta"
            target="_blank"
            rel="noreferrer"
            className={`text-xs font-cinzel hidden sm:block transition-colors hover:text-ninja-orange ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}
          >
            By Shani
          </a>
        </div>
      </div>
    </motion.nav>
  );
}
