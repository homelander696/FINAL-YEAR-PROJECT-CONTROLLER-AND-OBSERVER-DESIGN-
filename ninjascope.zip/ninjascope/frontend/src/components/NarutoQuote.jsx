import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '../context/ThemeContext';

const QUOTES = [
  { text: "I'm not gonna run away, I never go back on my word!", author: 'Naruto Uzumaki' },
  { text: "Those who break the rules are scum, but those who abandon their friends are worse than scum.", author: 'Kakashi Hatake' },
  { text: "A dropout will beat a genius through hard work.", author: 'Rock Lee' },
  { text: "In this world, wherever there is light, there are also shadows.", author: 'Itachi Uchiha' },
  { text: "The true measure of a shinobi is not how he lives, but how he dies.", author: 'Jiraiya' },
  { text: "When people get hurt, they learn to hate. When people hurt others, they become hated and racked with guilt. But knowing that pain allows people to be kind.", author: 'Nagato (Pain)' },
  { text: "Hard work is worthless for those that don't believe in themselves.", author: 'Naruto Uzumaki' },
  { text: "The moment people come to know love, they run the risk of carrying hate.", author: 'Obito Uchiha' },
  { text: "Failing doesn't give you a reason to give up, as long as you believe.", author: 'Naruto Uzumaki' },
  { text: "It is not wise to judge others based on your own preconceptions and by their appearance.", author: 'Itachi Uchiha' },
];

export default function NarutoQuote({ interval = 8000 }) {
  const [idx, setIdx] = useState(() => Math.floor(Math.random() * QUOTES.length));
  const { isDark } = useTheme();

  useEffect(() => {
    const timer = setInterval(() => {
      setIdx((prev) => (prev + 1) % QUOTES.length);
    }, interval);
    return () => clearInterval(timer);
  }, [interval]);

  const quote = QUOTES[idx];

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-6">
      <AnimatePresence mode="wait">
        <motion.div
          key={idx}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <p className={`ninja-quote-text text-sm font-noto italic leading-relaxed ${isDark ? 'text-ninja-muted' : 'text-gray-700'}`}>
            <span className="text-ninja-orange text-lg">"</span>
            {quote.text}
            <span className="text-ninja-orange text-lg">"</span>
          </p>
          <p className={`ninja-quote-author mt-2 text-xs font-cinzel tracking-widest uppercase ${isDark ? 'text-ninja-orange/70' : 'text-orange-600'}`}>
            — {quote.author}
          </p>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
