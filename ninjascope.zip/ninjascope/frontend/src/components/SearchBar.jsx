import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiSearch } from 'react-icons/fi';

export default function SearchBar({ onSearch, loading }) {
  const [value, setValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmed = value.trim();
    if (trimmed) onSearch(trimmed);
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="w-full max-w-xl mx-auto"
    >
      <div className="relative flex items-center gap-3">
        <div className="relative flex-1">
          <FiSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-ninja-orange text-lg pointer-events-none" />
          <input
            className="ninja-input pl-12 pr-4"
            type="text"
            placeholder="Believe it! Search a Shinobi username..."
            value={value}
            onChange={(e) => setValue(e.target.value)}
            disabled={loading}
          />
        </div>
        <motion.button
          type="submit"
          disabled={loading || !value.trim()}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="ninja-btn whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <span className="animate-spin">🌀</span> Searching...
            </span>
          ) : (
            'Search Jutsu!'
          )}
        </motion.button>
      </div>
    </motion.form>
  );
}
