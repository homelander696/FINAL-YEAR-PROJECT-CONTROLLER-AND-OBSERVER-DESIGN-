import { motion } from 'framer-motion';
import {
  FiUsers, FiUserCheck, FiBook, FiMapPin, FiLink, FiTwitter,
  FiCalendar, FiHeart, FiSlash
} from 'react-icons/fi';
import { useTheme } from '../context/ThemeContext';

const STAT = ({ icon: Icon, label, value, color = 'text-ninja-orange' }) => (
  <div className="ninja-stat-box flex flex-col items-center gap-1 p-3 rounded-xl bg-ninja-darker/60 border border-ninja-navy/60 min-w-[80px]">
    <Icon className={`text-xl ${color}`} />
    <span className="ninja-stat-value text-lg font-bold font-cinzel text-white">{value?.toLocaleString() ?? '—'}</span>
    <span className="ninja-stat-label text-xs text-ninja-muted uppercase tracking-wider">{label}</span>
  </div>
);

export default function ProfileCard({ profile, isFavorite, onToggleFavorite }) {
  const { isDark } = useTheme();

  const joinDate = profile.created_at
    ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
    : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="ninja-card p-6 max-w-2xl mx-auto"
    >
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
        {/* Avatar with chakra ring */}
        <div className="relative flex-shrink-0">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
            className="absolute inset-0 rounded-full"
            style={{
              background: 'conic-gradient(#ff6b00, #f39c12, #ff6b00, transparent, #ff6b00)',
              padding: '3px',
              borderRadius: '50%',
              width: '108px',
              height: '108px',
            }}
          />
          <img
            src={profile.avatar_url}
            alt={profile.login}
            className="relative w-24 h-24 rounded-full border-4 border-ninja-dark object-cover z-10"
            style={{ margin: '6px' }}
          />
        </div>

        {/* Info */}
        <div className="flex-1 text-center sm:text-left">
          <div className="flex items-center justify-center sm:justify-start gap-3 flex-wrap">
            <h2 className={`text-2xl font-bold font-cinzel ${isDark ? 'text-white' : 'text-ninja-dark'}`}>
              {profile.name || profile.login}
            </h2>
            <motion.button
              onClick={() => onToggleFavorite(profile)}
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
              title={isFavorite ? 'Remove from Squad' : 'Add to Squad'}
              className="text-xl"
            >
              {isFavorite ? (
                <FiHeart className="text-red-400 fill-red-400" />
              ) : (
                <FiSlash className={`transition-colors hover:text-red-400 ${isDark ? 'text-ninja-muted' : 'text-gray-400'}`} />
              )}
            </motion.button>
          </div>

          <a
            href={profile.html_url}
            target="_blank"
            rel="noreferrer"
            className="text-ninja-orange/80 hover:text-ninja-orange text-sm font-mono transition-colors"
          >
            @{profile.login}
          </a>

          {profile.bio && (
            <p className={`mt-2 text-sm leading-relaxed max-w-md ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>
              {profile.bio}
            </p>
          )}

          {/* Meta info */}
          <div className={`flex flex-wrap gap-3 mt-3 justify-center sm:justify-start text-xs ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>
            {profile.location && (
              <span className="flex items-center gap-1">
                <FiMapPin className="text-ninja-orange" /> {profile.location}
              </span>
            )}
            {profile.blog && (
              <a
                href={profile.blog.startsWith('http') ? profile.blog : `https://${profile.blog}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 hover:text-ninja-orange transition-colors"
              >
                <FiLink className="text-ninja-orange" />
                {profile.blog.replace(/^https?:\/\//, '')}
              </a>
            )}
            {profile.twitter_username && (
              <a
                href={`https://twitter.com/${profile.twitter_username}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 hover:text-ninja-orange transition-colors"
              >
                <FiTwitter className="text-ninja-orange" /> @{profile.twitter_username}
              </a>
            )}
            {joinDate && (
              <span className="flex items-center gap-1">
                <FiCalendar className="text-ninja-orange" /> Joined {joinDate}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-6 flex flex-wrap gap-3 justify-center">
        <STAT icon={FiBook} label="Repos" value={profile.public_repos} />
        <STAT icon={FiUsers} label="Followers" value={profile.followers} color="text-ninja-gold" />
        <STAT icon={FiUserCheck} label="Following" value={profile.following} color="text-ninja-teal" />
        {profile.public_gists > 0 && (
          <STAT icon={FiBook} label="Gists" value={profile.public_gists} color="text-ninja-purple" />
        )}
      </div>

      {/* GitHub link button */}
      <div className="mt-5 flex justify-center">
        <motion.a
          href={profile.html_url}
          target="_blank"
          rel="noreferrer"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="ninja-btn text-sm flex items-center gap-2"
        >
          <span>⚡</span> View on GitHub
        </motion.a>
      </div>
    </motion.div>
  );
}
