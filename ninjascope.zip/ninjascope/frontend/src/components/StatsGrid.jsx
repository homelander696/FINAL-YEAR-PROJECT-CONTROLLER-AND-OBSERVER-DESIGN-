import { motion } from 'framer-motion';
import { useTheme } from '../context/ThemeContext';

const LANG_COLORS = {
  JavaScript: '#f1e05a', TypeScript: '#3178c6', Python: '#3572A5',
  Java: '#b07219', 'C++': '#f34b7d', C: '#555', Go: '#00ADD8',
  Rust: '#dea584', Ruby: '#701516', PHP: '#4F5D95', Swift: '#fa7343',
  Kotlin: '#A97BFF', HTML: '#e34c26', CSS: '#563d7c', Shell: '#89e051',
};

export default function StatsGrid({ repos }) {
  const { isDark } = useTheme();
  if (!repos?.length) return null;

  // Total stars
  const totalStars = repos.reduce((acc, r) => acc + (r.stargazers_count || 0), 0);
  const totalForks = repos.reduce((acc, r) => acc + (r.forks_count || 0), 0);

  // Top languages
  const langCount = {};
  repos.forEach((r) => {
    if (r.language) langCount[r.language] = (langCount[r.language] || 0) + 1;
  });
  const topLangs = Object.entries(langCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);
  const totalLangRepos = topLangs.reduce((acc, [, c]) => acc + c, 0);

  const mostStarred = [...repos].sort((a, b) => b.stargazers_count - a.stargazers_count)[0];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="max-w-2xl mx-auto grid grid-cols-1 sm:grid-cols-2 gap-4"
    >
      {/* Stars & Forks */}
      <div className="ninja-card p-5">
        <h3 className="text-xs font-cinzel text-ninja-orange uppercase tracking-widest mb-4">
          ⭐ Scroll Stats
        </h3>
        <div className="flex gap-6">
          <div>
            <p className={`text-2xl font-bold font-cinzel ${isDark ? 'text-white' : 'text-ninja-dark'}`}>{totalStars.toLocaleString()}</p>
            <p className={`text-xs mt-0.5 ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>Total Stars</p>
          </div>
          <div>
            <p className="text-2xl font-bold font-cinzel text-ninja-teal">{totalForks.toLocaleString()}</p>
            <p className={`text-xs mt-0.5 ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>Total Forks</p>
          </div>
        </div>
        {mostStarred && (
          <div className="mt-4 pt-4 border-t border-ninja-navy/60">
            <p className={`text-xs ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>Most starred scroll:</p>
            <a
              href={mostStarred.html_url}
              target="_blank"
              rel="noreferrer"
              className="text-sm text-ninja-orange hover:text-ninja-orange-light transition-colors font-mono"
            >
              {mostStarred.name} ★ {mostStarred.stargazers_count}
            </a>
          </div>
        )}
      </div>

      {/* Language breakdown */}
      {topLangs.length > 0 && (
        <div className="ninja-card p-5">
          <h3 className="text-xs font-cinzel text-ninja-orange uppercase tracking-widest mb-4">
            🥷 Jutsu Mastery
          </h3>
          <div className="space-y-2">
            {topLangs.map(([lang, count]) => {
              const pct = Math.round((count / totalLangRepos) * 100);
              const color = LANG_COLORS[lang] || '#8b949e';
              return (
                <div key={lang}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className={`flex items-center gap-1.5 ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                      {lang}
                    </span>
                    <span className={isDark ? 'text-ninja-muted' : 'text-gray-500'}>{pct}%</span>
                  </div>
                  <div className={`h-1.5 rounded-full overflow-hidden ${isDark ? 'bg-ninja-darker' : 'bg-orange-100'}`}>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ duration: 0.8, delay: 0.3 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </motion.div>
  );
}
