import axios from 'axios';

const api = axios.create({ baseURL: '/api/ai' });

export const summarizeProfile = (profile, repos) =>
  api.post('/summarize', { profile, repos });

export const compareProfiles = (profile1, repos1, profile2, repos2) =>
  api.post('/compare', { profile1, repos1, profile2, repos2 });
