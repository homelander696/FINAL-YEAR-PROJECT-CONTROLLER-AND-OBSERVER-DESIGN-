import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

export const fetchUser = (username) => api.get(`/github/user/${username}`);
export const fetchRepos = (username, sort = 'stars') =>
  api.get(`/github/user/${username}/repos`, { params: { sort, per_page: 30 } });

export const getFavorites = () => api.get('/favorites');
export const addFavorite = (profile) => api.post('/favorites', profile);
export const removeFavorite = (username) => api.delete(`/favorites/${username}`);
