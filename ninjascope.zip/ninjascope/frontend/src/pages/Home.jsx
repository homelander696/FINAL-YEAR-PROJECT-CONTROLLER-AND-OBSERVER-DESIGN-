import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import toast from 'react-hot-toast';
import { useTheme } from '../context/ThemeContext';

import SearchBar from '../components/SearchBar';
import ProfileCard from '../components/ProfileCard';
import RepoCard from '../components/RepoCard';
import StatsGrid from '../components/StatsGrid';
import NarutoQuote from '../components/NarutoQuote';
import FavoritesList from '../components/FavoritesList';
import AISummaryModal from '../components/AISummaryModal';
import ThreeLangChart from '../components/ThreeLangChart';
import CompareSection from '../components/CompareSection';
import NinjaGames from '../components/NinjaGames';

import { fetchUser, fetchRepos, getFavorites, addFavorite, removeFavorite } from '../api/github';

const SORT_OPTIONS = [
  { value: 'stars', label: '⭐ Most Starred' },
  { value: 'updated', label: '🕐 Recently Updated' },
  { value: 'pushed', label: '⚡ Recently Pushed' },
  { value: 'full_name', label: '🔤 Name (A-Z)' },
];

export default function Home() {
  const { isDark } = useTheme();
  const [profile, setProfile] = useState(null);
  const [repos, setRepos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [repoSort, setRepoSort] = useState('stars');
  const [favorites, setFavorites] = useState([]);
  const [favUsernames, setFavUsernames] = useState(new Set());
  const [showAll, setShowAll] = useState(false);

  const loadFavorites = useCallback(async () => {
    try {
      const { data } = await getFavorites();
      setFavorites(data);
      setFavUsernames(new Set(data.map((f) => f.username)));
    } catch { /* MongoDB may not be running */ }
  }, []);

  useEffect(() => { loadFavorites(); }, [loadFavorites]);

  const handleSearch = async (username) => {
    setLoading(true);
    setProfile(null);
    setRepos([]);
    setShowAll(false);
    try {
      const [userRes, reposRes] = await Promise.all([
        fetchUser(username),
        fetchRepos(username, repoSort),
      ]);
      setProfile(userRes.data);
      setRepos(reposRes.data);
      toast.success(`Shinobi ${userRes.data.name || username} found!`, { icon: '🥷' });
    } catch (err) {
      const msg = err.response?.data?.error || 'Could not find this shinobi. Check the username.';
      toast.error(msg, { icon: '💨' });
    } finally {
      setLoading(false);
    }
  };

  const handleSortChange = async (sort) => {
    setRepoSort(sort);
    if (!profile) return;
    try {
      const { data } = await fetchRepos(profile.login, sort);
      setRepos(data);
    } catch {
      toast.error('Failed to reload scrolls.', { icon: '📜' });
    }
  };

  const handleToggleFavorite = async (p) => {
    if (favUsernames.has(p.login)) {
      try {
        await removeFavorite(p.login);
        toast('Removed from your squad.', { icon: '👋' });
        loadFavorites();
      } catch { toast.error('Failed to remove shinobi.'); }
    } else {
      try {
        await addFavorite({
          username: p.login, name: p.name, avatar_url: p.avatar_url,
          html_url: p.html_url, bio: p.bio, public_repos: p.public_repos,
          followers: p.followers, following: p.following,
        });
        toast.success('Added to your ninja squad! 🌀', { icon: '❤️' });
        loadFavorites();
      } catch { toast.error('Could not add to squad.'); }
    }
  };

  const displayedRepos = showAll ? repos : repos.slice(0, 9);

  return (
    <main className="relative z-10 min-h-screen">
      {/* Hero */}
      <section className="max-w-5xl mx-auto px-4 pt-16 pb-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="text-6xl mb-4"
          >
            🍥
          </motion.div>

          <h1 className={`font-cinzel font-black text-4xl sm:text-5xl md:text-6xl mb-3 leading-tight ${isDark ? 'text-white' : 'text-ninja-dark'}`}>
            Ninja<span className="text-ninja-orange animate-glow">Scope</span>
          </h1>

          <p className={`font-noto text-base sm:text-lg max-w-xl mx-auto mb-2 ${isDark ? 'text-ninja-muted' : 'text-gray-600'}`}>
            Discover the GitHub scrolls of any shinobi across the five nations.
          </p>

          <p className={`text-xs font-noto italic mb-8 ${isDark ? 'text-ninja-orange/60' : 'text-orange-500'}`}>
            "The Shinobi's GitHub — Believe it!"
          </p>

          <SearchBar onSearch={handleSearch} loading={loading} />
        </motion.div>

        {/* Quote */}
        <div className="mt-8">
          <NarutoQuote />
        </div>
      </section>

      {/* Favorites */}
      {favorites.length > 0 && (
        <section className="max-w-5xl mx-auto px-4 mb-8">
          <FavoritesList
            favorites={favorites}
            onSelect={handleSearch}
            onRemove={async (username) => {
              await removeFavorite(username);
              loadFavorites();
            }}
          />
        </section>
      )}

      <div className="section-divider max-w-5xl mx-auto px-4" />

      {/* Results */}
      <AnimatePresence mode="wait">
        {profile && (
          <motion.section
            key={profile.login}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-5xl mx-auto px-4 space-y-8 pb-12"
          >
            {/* Profile Card */}
            <ProfileCard
              profile={profile}
              isFavorite={favUsernames.has(profile.login)}
              onToggleFavorite={handleToggleFavorite}
            />

            {/* Action buttons row */}
            <div className="flex flex-wrap gap-3 justify-center">
              <AISummaryModal profile={profile} repos={repos} />
              <CompareSection />
              <NinjaGames repos={repos} />
            </div>

            {/* Quote between sections */}
            <NarutoQuote interval={6000} />

            {/* Stats */}
            {repos.length > 0 && <StatsGrid repos={repos} />}

            {/* 3D Language Chart */}
            {repos.length > 0 && <ThreeLangChart repos={repos} />}

            <div className="section-divider" />

            {/* Repos header */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <h2 className={`font-cinzel text-lg font-bold ${isDark ? 'text-white' : 'text-ninja-dark'}`}>
                📜 Ninja Scrolls{' '}
                <span className={`text-sm font-normal ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>({repos.length} repos)</span>
              </h2>

              <div className="flex items-center gap-2 flex-wrap justify-center">
                {SORT_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => handleSortChange(opt.value)}
                    className={`text-xs px-3 py-1.5 rounded-lg border font-cinzel transition-all ${
                      repoSort === opt.value
                        ? 'border-ninja-orange bg-ninja-orange/10 text-ninja-orange'
                        : isDark
                          ? 'border-ninja-navy text-ninja-muted hover:border-ninja-orange/40 hover:text-white'
                          : 'border-orange-200 text-gray-500 hover:border-ninja-orange hover:text-ninja-dark'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Repo grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <AnimatePresence>
                {displayedRepos.map((repo, i) => (
                  <RepoCard key={repo.id} repo={repo} index={i} />
                ))}
              </AnimatePresence>
            </div>

            {repos.length > 9 && (
              <div className="text-center">
                <motion.button
                  onClick={() => setShowAll((p) => !p)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="ninja-btn text-sm"
                >
                  {showAll ? '🌀 Show Less' : `⬇️ Show All ${repos.length} Scrolls`}
                </motion.button>
              </div>
            )}
          </motion.section>
        )}
      </AnimatePresence>

      {/* Empty state */}
      {!profile && !loading && (
        <div className="max-w-5xl mx-auto px-4 pb-16 text-center mt-4 space-y-8">
          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 3, repeat: Infinity }}
            className="text-7xl mb-4"
          >
            🥷
          </motion.div>
          <p className={`font-noto italic text-sm ${isDark ? 'text-ninja-muted' : 'text-gray-500'}`}>
            Enter a GitHub username to unveil their ninja scrolls...
          </p>

          {/* Show games even without a profile */}
          <div className="section-divider max-w-xs mx-auto" />
          <div className="flex flex-wrap gap-3 justify-center">
            <CompareSection />
            <NinjaGames repos={[]} />
          </div>
        </div>
      )}
    </main>
  );
}
